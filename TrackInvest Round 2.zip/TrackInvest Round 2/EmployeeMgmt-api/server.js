const express = require("express");
const multer  = require('multer');
const ejs = require('ejs');
var cors = require('cors')
const bodyParser = require("body-parser");
const uploads = multer({ dest: 'uploads/' });
const app = express();
app.set('view engine','ejs');


// parse requests of content-type - application/json
app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({ extended: true }));


app.use(cors());
// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static(process.cwd() + '/uploads'));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to bezkoder application." });
});

// const storage = multer.diskStorage({
//   destination: function (req, file, callback) {
//       //debugger;
//       //callback(null, './public/upload/');
//       callback(null, './uploads/');
//   },
//   filename: function (req, file, callback) {
//       callback(null, Date.now() + '-' + file.originalname);
//   }
// });

// const fileFilter = function (req, file, callback) {
//   // accept image only
//   if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
//       return callback(new Error('Only image files are allowed!'), false);
//   }
//   callback(null, true);
// };

// const upload = multer({ storage: storage, fileFilter: fileFilter });

// app.post("/products/images", upload.single('file'), (req, res, next) =>{
//      var file = req.file;
//      console.log(file);

// });


require("./app/routes/supplier.routes.js")(app);
require("./app/routes/employee.routes.js")(app);
require("./app/routes/warehouse.routes.js")(app);
require("./app/routes/customer.routes.js")(app);
require("./app/routes/customerAddress.routes.js")(app);
require("./app/routes/product.routes.js")(app);
// require("./app/routes/upload.routes.js")(app);
require("./app/routes/coupon.routes.js")(app);

// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, 'localhost',() => {
  console.log(`Server is running on port ${PORT}.`);
});

//192.168.0.101