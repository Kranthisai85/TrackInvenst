const Employee = require("../models/employee.model.js");

// Create and Save a new employee
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a employee
  const employee = new Employee({
    //EmployeeId: req.body.EmployeeId,
    UserId: req.body.UserId,
    FirstName: req.body.FirstName,
    MiddleName: req.body.MiddleName,
    LastName: req.body.LastName,
    JoiningDate: req.body.JoiningDate,
    TerminationDate: req.body.TerminationDate,
    DateOfBirth : req.body.DateOfBirth,
    AnniversaryDate : req.body.AnniversaryDate,
    Address1 : req.body.Address1,
    Address2 : req.body.Address2,
    CountryId : req.body.CountryId,
    StateId : req.body.StateId,
    CityId : req.body.CityId,
    HomePhoneNo : req.body.HomePhoneNo,
    WorkPhoneNo : req.body.WorkPhoneNo,
    MobilePhoneNo : req.body.MobilePhoneNo,
    IsDeleted : req.body.IsDeleted,
    IsDisabled : req.body.IsDisabled,
    CreatedDate : req.body.CreatedDate,
    CreatedBy : req.body.CreatedBy,
    UpdatedDate : req.body.UpdatedDate,
    UpdatedBy : req.body.UpdatedBy
  });

  // Save User in the database
  Employee.create(employee, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Employee."
      });
    else res.send(data);
  });
};

// Retrieve all employees from the database.
exports.findAll = (req, res) => {
  Employee.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving employees."
      });
    else res.send(data);
  });
};

// Find a single User with a UserId
exports.findOne = (req, res) => {
  Employee.findById(req.params.EmployeeId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Employee with id ${req.params.EmployeeId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Emloyee with id " + req.params.EmployeeId
        });
      }
    } else res.send(data);
  });
};

// Update a User identified by the UserId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  Employee.updateById(
    req.params.EmployeeId,
    new Employee(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Employee with id ${req.params.EmployeeId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Employee with id " + req.params.EmployeeId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a User with the specified UserId in the request
exports.delete = (req, res) => {
  Employee.remove(req.params.EmployeeId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Employee with id ${req.params.EmployeeId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Employee with id " + req.params.EmployeeId
        });
      }
    } else res.send({ message: `Employee was deleted successfully!` });
  });
};

// Delete all employees from the database.
exports.deleteAll = (req, res) => {
  Employee.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all employees."
      });
    else res.send({ message: `All employees were deleted successfully!` });
  });
};

exports.getAllDeliveryBoy = (req, res) => {
  Employee.getAllDeliveryBoy((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving employees."
      });
    else res.send(data);
  });
};
