const Delivery = require("../models/delivery.model.js");

exports.orderListForDeliveryPerson = (req, res) => {
    Delivery.orderListForDeliveryPerson(req.query.deliveryPersonId, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.getOrderItemByOrderId = (req, res) => {
    Delivery.getOrderItemByOrderId(req.query.orderId, req.query.deliveryPersonId, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.getCancelationReason = (req, res) => {
    Delivery.getCancelationReason((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.onOrderDelivered = (req, res) => {
    Delivery.onOrderDelivered(req, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

