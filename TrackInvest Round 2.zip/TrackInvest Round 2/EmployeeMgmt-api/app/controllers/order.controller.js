const Order = require("../models/order.model.js");
// Create and Save a new Product
exports.create = (req, res) => {

    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }


    const order = new Order({
        customerId: req.body.customerId,
        products: req.body.products,
        customerAddressId: req.body.customerAddressId,
        cartId: req.body.cartId,
        paymentMode: req.body.paymentMode,
        transactionCode: req.body.transactionCode,
        totalAmount: req.body.totalAmount,
        userId: req.body.userId,
        walletAmountUsed: req.body.walletAmountUsed,
        walletAmount: req.body.walletAmount,
    });


    // Save Product in the database
    Order.placeOrder(order, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Product."
            });
        else res.send(data);
    });
};

// Retrieve all Products from the database.
exports.getOrdersByCustomer = (req, res) => {
    Order.getOrdersByCustomer(req.query.customerId, req.query.count, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.getOrderItems = (req, res) => {
    Order.getOrderItems(req.params.orderId, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.cancelOrder = (req, res) => {
    Order.cancelOrder(req.body.orderId, req.body.userId, (err, data) => {
        if (err) res.status(500).send({
            message:
                err.message || "Some error occurred while retrieving Products."
        });
        else res.send(data);
    });

};