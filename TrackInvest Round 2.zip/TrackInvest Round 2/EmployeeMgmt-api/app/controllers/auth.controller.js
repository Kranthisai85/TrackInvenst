const Auth = require("../models/auth.model.js");

// Create and Save a new User
exports.signIn = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    // Create a User
    const user = new Auth({
        username: req.body.username,
        userpassword: req.body.userpassword
    });


    // Retrieve all Customers from the database.
    Auth.signIn(user, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving customers."
            });
        else res.send(data);
    });

}
