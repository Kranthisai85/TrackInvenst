const Supplier = require("../models/supplier.model.js");

// Create and Save a new supplier
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a supplier
  const supplier = new Supplier({
    //UserId: req.body.UserId,
    SupplierName: req.body.SupplierName,
    Address1 : req.body.Address1,
    Address2 : req.body.Address2,
    CountryId : req.body.CountryId,
    StateId : req.body.StateId,
    CityId : req.body.CityId,
    PostCode : req.body.PostCode,
    ContactName : req.body.ContactName,
    ContactPhone : req.body.ContactPhone,
    Website : req.body.Website,
    Email : req.body.Email
  });

  // Save supplier in the database
  Supplier.create(supplier, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Supplier."
      });
    else res.send(data);
  });
};

// Retrieve all suppliers from the database.
exports.findAll = (req, res) => {
  Supplier.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving supplier."
      });
    else res.send(data);
  });
};

// Find a single User with a  supplierId
exports.findOne = (req, res) => {
    Supplier.findById(req.params.supplierId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Supplier with id ${req.params.supplierId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Supplier with id " + req.params.supplierId
        });
      }
    } else res.send(data);
  });
};

// Update a User identified by the SupplierId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  Supplier.updateById(
    req.params.supplierId,
    new Supplier(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Supplier with id ${req.params.supplierId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Supplier with id " + req.params.supplierId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a User with the specified supplierId in the request
exports.delete = (req, res) => {
    Supplier.remove(req.params.supplierId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Supplier with id ${req.params.supplierId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Supplier with id " + req.params.supplierId
        });
      }
    } else res.send({ message: `Supplier was deleted successfully!` });
  });
};

// Delete all suppliers from the database.
exports.deleteAll = (req, res) => {
    Supplier.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all suppliers."
      });
    else res.send({ message: `All suppliers were deleted successfully!` });
  });
};