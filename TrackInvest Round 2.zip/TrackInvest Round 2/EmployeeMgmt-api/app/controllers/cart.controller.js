const Cart = require("../models/cart.model.js");

// Create and Save a new Cart
exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    const cart = new Cart({
        customerId: req.body.customerId,
        products: req.body.products,
        amount: req.body.amount,
        customerAddressId: req.body.customerAddressId,
        notes: req.body.notes,
        product: req.body.product,
    });

    // Save Cart in the database
    Cart.create(cart, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Cart."
            });
        else res.send(data);
    });
};

exports.edit = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    const cart = new Cart({
        customerId: req.body.customerId,
        products: req.body.products,
        amount: req.body.amount,
        customerAddressId: req.body.customerAddressId,
        notes: req.body.notes,
        product: req.body.product,
    });

    // Save Cart in the database
    Cart.edit(cart, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Cart."
            });
        else res.send(data);
    });
};


// Retrieve all Carts from the database.
exports.findAll = (req, res) => {
    Cart.getAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

// Find a cart item by customer id
exports.findOne = (req, res) => {
    Cart.findById(req.params.customerId, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `Not found Product with id ${req.params.customerId}.`
                });
            } else {
                res.status(500).send({
                    message: "Error retrieving Product with id " + req.params.customerId
                });
            }
        } else res.send(data);
    });
};

exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    Cart.updateById(
        req.body,
        (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: "Product Not found"
                    });
                } else {
                    res.status(500).send({
                        message: "Error updating Cart"
                    });
                }
            } else res.send(data);
        }
    );
};

// Delete a Product with the specified productId in the request
exports.delete = (req, res) => {
    Cart.remove(req.body, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `Item not found.`
                });
            } else {
                res.status(500).send({
                    message: "Could not delete cart item"
                });
            }
        } else res.send(data);
    });
};

// Delete all Products from the database.
exports.deleteAll = (req, res) => {
    Cart.removeAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while removing all cart item."
            });
        else res.send({ message: `All Cart item were deleted successfully!` });
    });
};