const Wallet = require("../models/wallet.model.js");

exports.getAllDetails = (req, res) => {
    //Validate request 
    if (!req.body) {
        res.status(400).send({
            message: "Content cannot be empty!"
        });
    }
    //create a warehouse
    const wallet = new Wallet();

    //save warehouse in the database
    Wallet.getAllDetails(req.query.customerId, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the warehouse."
            });
        else res.send(data);
    });
};