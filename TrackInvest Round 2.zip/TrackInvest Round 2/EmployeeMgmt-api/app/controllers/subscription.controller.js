const Subscription = require("../models/subscription.model.js");

// Create and Save a new Subscription
exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    if (!req.body.products) {
        res.status(400).send({
            message: "Products not be empty!"
        });
    }

    // Create a Product
    const subscription = new Subscription({
        customerId: req.body.customerId,
        subscriptionTypeId: req.body.subscriptionTypeId,
        products: req.body.products,
        noOfDeliveries: req.body.noOfDeliveries,
        amount: req.body.amount,
        startDate: req.body.startDate,
        orderDate: req.body.orderDate,
        subscriptionId: req.body.subscriptionId,
        product: req.body.product,
        isCancel: req.body.isCancel,
        subscriptionEditDate: req.body.subscriptionEditDate,
        initialDeliveries: req.body.initialDeliveries,
        endDate: req.body.endDate,
        addressId: req.body.addressId
    });

    // Save Product in the database
    Subscription.create(subscription, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Subscription."
            });
        else res.send(data);
    });
};

// Retrieve all Products from the database.
exports.findAll = (req, res) => {
    Subscription.getAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

// Find a single Subscription with a SubscriptionId
exports.findOne = (req, res) => {
    var customerId = req.params.customerId;
    var customerAddressId = req.params.addressId;
    var subscriptionTypeId = req.params.subscriptionTypeId;
        Subscription.findById(customerId, customerAddressId, subscriptionTypeId, (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: `Not found Product with id ${req.params.customerId}.`
                    });
                } else {
                    res.status(500).send({
                        message: "Error retrieving Product with id " + req.params.customerId
                    });
                }
            } else res.send(data);
        });
};

// Update a Product identified by the productId in the request
exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    Subscription.updateById(
        req.params.subscriptionId,
        req.body,
        (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: `Not found Subscription with id ${req.params.subscriptionId}.`
                    });
                } else {
                    res.status(500).send({
                        message: "Error updating Subscription with id " + req.params.subscriptionId
                    });
                }
            } else res.send(data);
        }
    );
};

// Delete a Product with the specified productId in the request
exports.delete = (req, res) => {
    Subscription.remove(req.params.subscriptionId, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `Not found Subscription with id ${req.params.subscriptionId}.`
                });
            } else {
                res.status(500).send({
                    message: "Could not delete Subscription with id " + req.params.subscriptionId
                });
            }
        } else res.send({ message: `Subscription was deleted successfully!` });
    });
};

// Delete all Products from the database.
exports.deleteAll = (req, res) => {
    Product.removeAll((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while removing all Subscriptions."
            });
        else res.send({ message: `All Subscriptions were deleted successfully!` });
    });
};

exports.getSubscritionDetails = (req, res) => {
    Subscription.getSubscritionDetails(req.params.subscriptionId, (err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: `Not found Product with id ${req.params.customerId}.`
                });
            } else {
                res.status(500).send({
                    message: "Error retrieving Product with id " + req.params.customerId
                });
            }
        } else res.send(data);
    });
};


exports.renewSubscription = (req, res) => {
    // Validate Request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    Subscription.renewSubscription(
        req.body,
        (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: `Not found Subscription with id .`
                    });
                } else {
                    res.status(500).send({
                        message: "Error updating Subscription."
                    });
                }
            } else res.send(data);
        }
    );
};


exports.cancelSubscription = (req, res) => {
    // Validate Request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    Subscription.cancelSubscription(
        req.body,
        (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: `Not found Subscription with id.`
                    });
                } else {
                    res.status(500).send({
                        message: "Error updating Subscription with id " + req.params.subscriptionId
                    });
                }
            } else res.send(data);
        }
    );
};


exports.editSubscription = (req, res) => {
    // Validate Request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }

    Subscription.editSubscription(
        req.body,
        (err, data) => {
            if (err) {
                if (err.kind === "not_found") {
                    res.status(404).send({
                        message: `Not found Subscription with id`
                    });
                } else {
                    res.status(500).send({
                        message: "Error updating Subscription."
                    });
                }
            } else res.send(data);
        }
    );
};

exports.getSubscriptionBasket = (req, res) => {
    Subscription.getSubscriptionBasket((err, data) => {
        if (err) {
            if (err.kind === "not_found") {
                res.status(404).send({
                    message: "No subscription Basket found",
                });
            } else {
                res.status(500).send({
                    message: "No subscription Basket found",
                });
            }
        } else res.send(data);
    });
};