const Warehouse = require("../models/warehouse.models.js");

//Create and save a new Warehouse
exports.create = (req,res) => {
    //Validate request 
    if(!req.body){
        res.status(400).send({
            message: "Content cannot be empty!"
        });
    }
    //create a warehouse
    const warehouse = new Warehouse({
        WarehouseName : req.body.WarehouseName,
        WarehouseDescription : req.body.WarehouseDescription,
        Address1 : req.body.Address1,
        Address2 : req.body.Address2,
        Address3 : req.body.Address3,
        CountryId : req.body.CountryId,
        StateId : req.body.StateId,
        CityId : req.body.CityId,
        PostCode : req.body.PostCode,
        ContactName : req.body.ContactName,
        ContactPhone : req.body.ContactPhone,
        Email : req.body.Email
    });
    
    //save warehouse in the database
    Warehouse.create(warehouse, (err,data) => {
        if(err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the warehouse."
            });
        else res.send(data);
    });
};

//Retrive all warehouses from the databases
exports.findAll = (req,res) => {
    Warehouse.getAll((err,data) => {
        if(err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retriveving warehouse."
            });
        else res.send(data);
    });
};

// Find a single User with a warehouseId
exports.findOne = (req, res) => {
    Warehouse.findById(req.params.warehouseId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Warehouse with id ${req.params.warehouseId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Warehouse with id " + req.params.warehouseId
        });
      }
    } else res.send(data);
  });
};

// Update a User identified by the WarehouseId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

    Warehouse.updateById(
    req.params.warehouseId,
    new Warehouse(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Warehouse with id ${req.params.warehouseId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Warehouse with id " + req.params.warehouseId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a User with the specified WarehouseId in the request
exports.delete = (req, res) => {
    Warehouse.remove(req.params.warehouseId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Warehouse with id ${req.params.warehouseId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Warehouse with id " + req.params.warehouseId
        });
      }
    } else res.send({ message: `Warehouse was deleted successfully!` });
  });
};

// Delete all warehouses from the database.
exports.deleteAll = (req, res) => {
    Warehouse.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all warehouses."
      });
    else res.send({ message: `All warehouses were deleted successfully!` });
  });
};