const Admin = require("../models/admin.model.js");

exports.getAllPendingOrders = (req, res) => {
    Admin.getAllPendingOrders(req.query.date, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};
exports.getAllDelieveryFilter = (req, res) => {
    Admin.getAllDelieveryFilter((err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
}

exports.getOrdersByFilter = (req, res) => {
    Admin.getOrdersByFilter(req, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.assignDeliveryPerson = (req, res) => {
    Admin.assignDeliveryPerson(req, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};

exports.adminEditOrder = (req, res) => {
    Admin.adminEditOrder(req, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};


exports.orderListForDeliveryPerson = (req, res) => {
    Admin.orderListForDeliveryPerson(req.query.deliveryPersonId, req.query.count, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};