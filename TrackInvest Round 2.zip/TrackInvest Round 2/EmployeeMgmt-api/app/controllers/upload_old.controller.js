const multer = require('multer');
const sql = require("../models/db.js");
// define multer storage configuration     
const storage = multer.diskStorage({
    destination: function (req, file, callback) {
        debugger;
        //callback(null, './public/upload/');
        callback(null, './uploads/');
    },
    filename: function (req, file, callback) {
        callback(null, Date.now() + '-' + file.originalname);
    }
});

const fileFilter = function (req, file, callback) {
    // accept image only
    if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
        return callback(new Error('Only image files are allowed!'), false);
    }
    callback(null, true);
};

const upload = multer({ storage: storage, fileFilter: fileFilter });

exports.single = (req, res, next) => {
    debugger;
    upload.single('singleFile')(req, res, () => {
        try {
            debugger;
            const file = req.file;
            if (!file) {
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Please upload file"
                });
            }

            const productId = req.body.productId;

            if (productId == null) {
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Please provide product id"
                });
            }

            const response = sql.query("INSERT INTO productimage SET ProductId = ?, ImageHRPath = ?,FolderName = ?,MimeType = ?", [productId, file.path, file.destination, file.mimetype]);

            if (response[0] == null) {
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Error while stoaring image"
                });
            }
            res.status(200).json({
                "status": "success",
                "code": "200",
                "message": "file uploaded successfully",
                "data": file
            });
        } catch (err) {
            console.log(error.message);
            res.status(200).json({
                "status": "failed",
                "code": "500",
                "message": error.message
            });
        }
    })
};

exports.multiple = (req, res) => {

    upload.fields([
        { name: 'imageHR', maxCount: 1 },
        { name: 'imageLR', maxCount: 1 },
        { name: 'imageThumbNail', maxCount: 1 }
    ])(req, res, () => {
        try {
            const files = req.files;

            const imageHr = req.files.imageHR;
            const imageLr = req.files.imageLR;
            const imageThumbNail = req.files.imageThumbNail;

            var hrPath = null;
            var lrPath = null;
            var tnPath = null;
            var destination = null;
            var mimeType = null;
            if (imageHr) {
                hrPath = imageHr[0].path;
                destination = imageHr[0].destination;
                mimetype = imageHr[0].mimetype;
            }else{
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Please upload High resolution file"
                });
            }

            if (imageLr) {
                lrPath = imageLr[0].path;
                if (destination == null) {
                    destination = imageLr[0].destination;
                    mimetype = imageLr[0].mimetype;
                }
            }


            if (imageThumbNail) {
                tnPath = imageThumbNail[0].path;
                if (destination == null) {
                    destination = imageThumbNail[0].destination;
                    mimetype = imageThumbNail[0].mimetype;
                }
            }
            if (!files) {
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Please upload file"
                });
            }


            const productId = req.body.productId;

            if (productId == null) {
                res.status(400).json({
                    "status": "failed",
                    "code": "400",
                    "message": "Please provide product id"
                });
            }

            sql.query("INSERT INTO productimage SET ProductId = ?, ImageHRPath = ?,ImageLRPath = ? ,ImageThumbNailPath = ?, FolderName = ?,MimeType = ?", [productId, hrPath, lrPath, tnPath, destination, mimetype]);


            res.status(200).json({
                "status": "success",
                "code": "200",
                "message": "file uploaded successfully",
                "data": files
            });
        } catch (err) {
            console.log(err.message);
            res.status(200).json({
                "status": "failed",
                "code": "500",
                "message": err.message
            });
        }
    })
};