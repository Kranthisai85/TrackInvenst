const { request } = require("express");
const CustomerAddress = require("../models/customerAddress.model.js");

// Create and Save a new CustomerAddress
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a Customer Address
  const customerAddress = new CustomerAddress({
    pincode: req.body.pincode,
    addressTypeId: req.body.addressTypeId,
    customerId: req.body.customerId,
    address1: req.body.address1,
    address2: req.body.address2,
    landmark: req.body.landmark,
    area: req.body.area,
    prefredDeliveryDays: req.body.prefredDeliveryDays,
    isDefault: req.body.isDefault,
    city: req.body.city,
    cityId: req.body.cityId,
    otherAddressType: req.body.otherAddressType,
    contactName: req.body.contactName,
    contactPhone: req.body.contactPhone,
  });

  // Save customerAddress in the database
  CustomerAddress.create(customerAddress, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the customerAddress."
      });
    else res.send(data);
  });
};

// Retrieve all Customers Address from the database.
exports.findAll = (req, res) => {
  CustomerAddress.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers Address."
      });
    else res.send(data);
  });
};

// Find a single User with a customerAddressId
exports.findOne = (req, res) => {
  CustomerAddress.findById(req.params.customerId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found User with id ${req.params.customerAddressId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving User with id " + req.params.customerAddressId
        });
      }
    } else res.send(data);
  });
};

// Update a User identified by the customerAddressId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  console.log(req.body);

  CustomerAddress.updateById(
    req.params.customerAddressId,
    new CustomerAddress(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Customer Address with id ${req.params.customerAddressId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating Customer Address with id " + req.params.customerAddressId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a User with the specified customerAddressId in the request
exports.delete = (req, res) => {
  CustomerAddress.remove(req.params.customerAddressId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Address with id ${req.params.customerAddressId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Address with id " + req.params.customerAddressId
        });
      }
    } else res.send({ message: `Address was deleted successfully!` });
  });
};

// Delete all Customers Address from the database.
exports.deleteAll = (req, res) => {
  CustomerAddress.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all customers Address."
      });
    else res.send({ message: `All Customers Address were deleted successfully!` });
  });
};

exports.registerCustomer = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }


  // Save customerAddress in the database
  CustomerAddress.registerCustomer(req, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the customerAddress."
      });
    else res.send(data);
  });
};

exports.getAllCities = (req, res) => {
  CustomerAddress.getAllCities(req, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers Address."
      });
    else res.send(data);
  });
};

exports.checkPincode = (req, res) => {
  CustomerAddress.checkPincode(req.query.pincode, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customers Address."
      });
    else res.send(data);
  });
};

