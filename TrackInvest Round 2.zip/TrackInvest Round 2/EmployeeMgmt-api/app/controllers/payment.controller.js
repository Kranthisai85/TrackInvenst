const Payment = require("../models/payment.model.js");

exports.makeOutStandingPayment = (req, res) => {
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
    }


    const payment = new Payment({
        customerId: req.body.customerId,
        orders: req.body.orders,
        transactionCode: req.body.transactionCode,
        userId: req.body.userId,
        totalAmount: req.body.totalAmount,
    });


    Payment.makeOutStandingPayment(payment, (err, data) => {
        if (err)
            res.status(500).send({
                message:
                    err.message || "Some error occurred while retrieving Products."
            });
        else res.send(data);
    });
};
