const { DATETIME } = require("mysql2/lib/constants/types");
const sql = require("./db.js");
const https = require('https');
var constants = require('../lib/constants');

// constructor
const Customer = function (customer) {
  this.UserId = customer.UserId,
    this.FirstName = customer.FirstName,
    this.MiddleName = customer.MiddleName,
    this.LastName = customer.LastName,
    this.CustomerAddressId = customer.CustomerAddressId,
    this.ContactPhone = customer.ContactPhone,
    this.ContactMobile = customer.ContactMobile,
    this.ContactEmail = customer.ContactEmail,
    this.IsActive = customer.IsActive,
    this.CreatedDate = customer.CreatedDate,
    this.CreatedBy = customer.CreatedBy,
    this.UpdatedDate = customer.UpdatedDate,
    this.UpdatedBy = customer.UpdatedBy
  //this.isadmin = user.isadmin;
};

Customer.create = async (newCustomer, result) => {

  var createCustomer = await sql.query("INSERT INTO customer SET UserId = ?,FirstName = ?,MiddleName = ?,LastName = ?,CustomerAddressId = ?,ContactPhone = ?,ContactMobile = ?,ContactEmail = ?,IsActive = ?, CreatedDate = ?,CreatedBy = ?,UpdatedDate = ?,UpdatedBy= ?", [newCustomer.UserId, newCustomer.FirstName, newCustomer.MiddleName, newCustomer.LastName, newCustomer.CustomerAddressId, newCustomer.ContactPhone, newCustomer.ContactMobile, newCustomer.ContactEmail, newCustomer.IsActive, newCustomer.CreatedDate, newCustomer.CreatedBy, newCustomer.UpdatedDate, newCustomer.UpdatedBy]);
  if (!createCustomer[0]) {
    console.log("error: ", createCustomer[0]);
    result(createCustomer[0], null);
    return;
  }

  console.log("Created Customer: ", { CustomerId: createCustomer[0].insertId, ...newCustomer });
  result(null, {
    message: "Customer added successfully",
    code: 0,
    CustomerId: createCustomer[0].insertId, ...newCustomer
  });

}

Customer.findById = async (customerId, result) => {
  var findByIdCustomer = await sql.query(`SELECT CustomerId,UserId,FirstName,MiddleName,LastName,CustomerAddressId,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE CustomerId = ${customerId}`);

  if (!findByIdCustomer[0]) {
    console.log("error: ", findByIdCustomer[0]);
    result(findByIdCustomer[0], null);
    return;
  }

  if (findByIdCustomer[0].length) {
    console.log("found Customer: ", findByIdCustomer[0]);
    result(null, findByIdCustomer[0]);
    return;
  }

  // not found customer with the id
  result({ kind: "not_found" }, null);
};


Customer.getAll = async result => {
  var getAllCustomer = await sql.query("SELECT CustomerId,UserId,FirstName,MiddleName,LastName,CustomerAddressId,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer");
  if (!getAllCustomer[0]) {
    console.log("error: ", getAllCustomer[0]);
    result(null, getAllCustomer[0]);
    return;
  }

  console.log("Customer: ", getAllCustomer[0]);
  result(null, getAllCustomer[0]);
};

Customer.updateById = async (customerId, customer, result) => {
  const resultOne = await sql.query(
    "UPDATE customer SET UserId = ?,FirstName = ?,MiddleName = ?,LastName = ?,CustomerAddressId = ?,ContactPhone = ?,ContactMobile = ?,ContactEmail = ?,IsActive = ?, CreatedDate = ?,CreatedBy = ?,UpdatedDate = ?,UpdatedBy= ?",
    [customer.UserId, customer.FirstName, customer.MiddleName, customer.LastName, customer.CustomerAddressId, customer.ContactPhone, customer.ContactMobile, customer.ContactEmail, customer.IsActive, customer.CreatedDate, customer.CreatedBy, customer.UpdatedDate, customer.UpdatedBy]);

  console.log("result ", resultOne[0]);


  if (resultOne[0] == null) {
    console.log("error: ", "err");
    result(null, { "message": "error" });
    return;
  }

  if (resultOne[0].affectedRows == 0) {
    // not found customer with the id
    result({ kind: "not_found" }, null);
    return;
  }

  console.log("updated customer: ", { Customerid: customerId, ...customer });
  result(null, {
    message: "Customer Updated successfully",
    code: 0,
    Customerid: customerId, ...customer
  });
  //   Customerid: CustomerId, ...customer
};

Customer.remove = async (customerId, result) => {
  var removeCustomer = await sql.query("DELETE FROM customer WHERE CustomerId = ?", customerId);
  if (!removeCustomer[0]) {
    console.log("error: ", removeCustomer[0]);
    result(null, removeCustomer[0]);
    return;
  }

  console.log("deleted customer with CustomerId: ", customerId);
  result(null, removeCustomer[0]);

};

Customer.removeAll = async result => {
  var removeAllCustomer = await sql.query("DELETE FROM customer");
  if (!removeAllCustomer[0]) {
    console.log("error: ", removeAllCustomer[0]);
    result(null, removeAllCustomer[0]);
    return;
  }

  console.log(`deleted ${removeAllCustomer[0].affectedRows} customers`);
  result(null, removeAllCustomer[0]);

};

Customer.checkMobileNumber = async (mobileNumber, result) => {
  try {
    // var customer = await sql.query("SELECT CustomerId,UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE ContactMobile =?", mobileNumber);
    // if (customer[0][0]) {

    //   var userId = customer[0][0].UserId;
    //   var otp = await sql.query("SELECT OtpPassword from userOtp where userId = ?", userId);
    //   var userOtp;
    //   if (otp[0][0]) {
    //     userOtp = await sql.query("Update UserOtp set OtpPassword = ?, CreatedDate = ?", ['123123', new Date()]);
    //   } else {
    //     userOtp = await sql.query("Insert INTO USEROTP SET UserId = ?,OtpPassword = ?,CreatedDate = ?", [
    //       userId, '123123', new Date()
    //     ]);
    //   }

    //   if (userOtp[0]) {
    //     result(null, {
    //       customer: customer[0][0],
    //       message: "Otp send",
    //       code: 0

    //     });
    //     return;
    //   }
    // }

    // var inviteeCustomer = await sql.query("Select ProspectCustomerId,FirstName,LastName,ContactEmail,ContactPhone,ContactMobile,CustomerId from prospectcustomer where ContactMobile = ?", mobileNumber);
    // if (inviteeCustomer[0][0]) {
    //   if (inviteeCustomer[0][0].CustomerId == null) {
    //     result(null, {
    //       message: "You need to be invited by one of our existing users to use eSatvik application. Unfortunately, we could not find your name in the invitee list. We will contact you soon to assist you in registration",
    //       code: 2,
    //     });
    //     return;
    //   } else {
    //     const connection = await sql.getConnection();
    //     //Enter in user then customer and then send otp
    //     await connection.beginTransaction();
    //     var password = "";
    //     const userResponse = await connection.query("INSERT INTO users SET username = ?, userpassword = ?, usertypeid = 1, CreatedBy = 1", [mobileNumber, password]);

    //     if (userResponse[0] == null) {
    //       await connection.rollback();
    //       result(null, {
    //         message: "Error While creating user",
    //         code: 2,
    //       });
    //       return;
    //     }
    //     var userId = userResponse[0].insertId;

    //     const customerResp = await connection.query("INSERT INTO customer SET userId = ?,firstname = '',contactMobile = ?", [userId, mobileNumber]);
    //     if (customerResp[0] == null) {
    //       result(null, {
    //         message: "Error while creating user",
    //         code: 3
    //       })
    //     }

    //     const custResponse = await connection.query("SELECT CustomerId,UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE CustomerId =?", customerResp[0].insertId);
    //     //Delete from ProspectCustomer;
    //     const deleteProspectCust = await connection.query("Delete from prospectcustomer where ContactMobile = ?", mobileNumber);

    //     var otp = await connection.query("SELECT OtpPassword from userOtp where userId = ?", userId);
    //     var userOtp;
    //     if (otp[0][0]) {
    //       userOtp = await connection.query("Update UserOtp set OtpPassword = ?, CreatedDate = ?", ['123123', new Date()]);
    //     } else {
    //       userOtp = await connection.query("Insert INTO USEROTP SET UserId = ?,OtpPassword = ?,CreatedDate = ?", [
    //         userId, '123123', new Date()
    //       ]);
    //     }


    //     connection.commit();
    //     if (userOtp[0]) {
    //       result(null, {
    //         customer: custResponse[0][0],
    //         message: "Otp send",
    //         code: 0
    //       });

    //       return;
    //     }
    //   }

    // }

    // var insertInvetee = await sql.query("Insert into prospectcustomer SET ContactMobile = ?", mobileNumber);
    // if (!insertInvetee[0]) {
    //   console.log("error: ", createCustomer[0]);
    //   result(createCustomer[0], null);
    //   return;
    // }
    // result(null, {
    //   message: "You need to be invited by one of our existing users to use eSatvik application. Unfortunately, we could not find your name in the invitee list. We will contact you soon to assist you in registration",
    //   code: 2,
    // });

    var otp = generateOTP();

    if (constants.SEND_SMS)
      var response = await sendOTP(mobileNumber, otp);
    else {
      var newResponse = {};
      newResponse.Status = 'Success';
      var response = newResponse;
    }

    console.log(otp);

    if (response.Status == 'Success') {
      var checkNumber = await sql.query("Select PhoneNumber from USEROTP where PhoneNumber = ?", mobileNumber);
      var userOtp;
      if (!checkNumber[0][0]) {
        userOtp = await sql.query("Insert INTO USEROTP SET UserOtpId = UUID_TO_BIN(UUID()), PhoneNumber = ?,OtpPassword = ?,CreatedDate = ?,UpdatedDate = ?", [mobileNumber, otp, new Date(), new Date()]);
      } else {
        userOtp = await sql.query("UPDATE USEROTP SET OtpPassword = ?,CreatedDate = ?,UpdatedDate = ? where PhoneNumber = ?", [otp, new Date(), new Date(), mobileNumber]);
      }

      if (userOtp[0]) {
        result(null, {
          //customer: custResponse[0][0],
          message: "Otp send",
          code: 0
        });
        return;
      }
    } else {
      result(null, {
        //customer: custResponse[0][0],
        message: "Error in sending Otp. Try again later",
        code: 2
      });
      return;
    }

  } catch (err) {
    console.log(err);
    result(err, null);
  }
};

Customer.verifyOtp = async (mobileNumber, otp, result) => {
  try {


    var verify = await sql.query("Select BIN_TO_UUID(UserOtpId) as UserOtpId from userotp where PhoneNumber = ? AND OtpPassword = ? AND TIMESTAMPDIFF(MINUTE,UpdatedDate,NOW()) < 5", [parseInt(mobileNumber), parseInt(otp)]);

    if (verify[0][0]) {

      const deleteOtp = await sql.query("Delete from userOtp where PhoneNumber = ? AND OtpPassword = ?", [mobileNumber, otp]);

      //check if this user is admin or DELIVERY_BOY
      const userResp = await sql.query("SELECT BIN_TO_UUID(UserId) As UserId,BIN_TO_UUID(UserTypeId) As UserTypeId,UserName from users where UserName = ?", mobileNumber);

      if (userResp[0][0]) {
        var loggedInUser = userResp[0][0];
        if (loggedInUser.UserTypeId == constants.DELIVERY_BOY) {
          loggedInUser.IsAdmin = false;
          loggedInUser.IsDeliveryBoy = true;
          result(null, {
            customer: loggedInUser,
            message: "Otp send",
            code: 0
          });

          return;

        } else if (loggedInUser.UserTypeId == constants.ADMIN) {
          loggedInUser.IsAdmin = true;
          loggedInUser.IsDeliveryBoy = false;
          result(null, {
            customer: loggedInUser,
            message: "Otp send",
            code: 0
          });
          return;
        }
      }

      var customer = await sql.query("SELECT BIN_TO_UUID(CustomerId) as CustomerId,BIN_TO_UUID(UserId) as UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate, BIN_TO_UUID(CreatedBy) as CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE ContactMobile =?", mobileNumber);
      if (customer[0][0]) {
        var customerAddress = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) as CustomerAddressId, BIN_TO_UUID(ca.AddressTypeId) as AddressTypeId,BIN_TO_UUID(ca.CustomerId) as CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, ca.IsDefault, a.AddressType FROM customerAddress ca inner join AddressType a  on ca.AddressTypeId = a.AddressTypeId WHERE CustomerId = UUID_TO_BIN(?)", customer[0][0].CustomerId);
        customer[0][0].IsAdmin = false;
        customer[0][0].IsDeliveryBoy = false;
        result(null, {
          customer: customer[0][0],
          customerAddress: customerAddress[0],
          message: "success",
          code: 0
        });
        return;
      } else {
        var inviteeCustomer = await sql.query("Select BIN_TO_UUID(ProspectCustomerId) as ProspectCustomerId,FirstName,LastName,ContactEmail,ContactPhone,ContactMobile,BIN_TO_UUID(CustomerId) as CustomerId from prospectcustomer where ContactMobile = ?", mobileNumber);
        if (inviteeCustomer[0][0]) {
          if (inviteeCustomer[0][0].CustomerId == null) {
            result(null, {
              message: "You need to be invited by one of our existing users to use eSatvik application. Unfortunately, we could not find your name in the invitee list. We will contact you soon to assist you in registration",
              code: 2,
            });
            return;
          } else {
            const connection = await sql.getConnection();
            //Enter in user then customer and then send otp
            await connection.beginTransaction();
            var password = "";
            const UserUuid = await connection.query("Select UUID() as UserId");
            const UserId = UserUuid[0][0].UserId;
            const userResponse = await connection.query("INSERT INTO users SET UserId = UUID_TO_BIN(?), username = ?, userpassword = ?, usertypeid = UUID_TO_BIN(?), CreatedBy = UUID_TO_BIN(?)", [UserId, mobileNumber, password, constants.USER_TYPE_UUID, constants.USER_UUID]);

            if (userResponse[0] == null) {
              await connection.rollback();
              result(null, {
                message: "Error While creating user",
                code: 2,
              });
              return;
            }
            const CustomerUuid = await connection.query("Select UUID() as CustomerId");
            const CustomerId = CustomerUuid[0][0].CustomerId;
            const customerResp = await connection.query("INSERT INTO customer SET CustomerId= UUID_TO_BIN(?), userId = UUID_TO_BIN(?),firstname = '',contactMobile = ?", [CustomerId, UserId, mobileNumber]);
            if (customerResp[0] == null) {
              result(null, {
                message: "Error while creating user",
                code: 3
              })
            }

            const custResponse = await connection.query("SELECT BIN_TO_UUID(CustomerId) as CustomerId,BIN_TO_UUID(UserId) as UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE CustomerId =UUID_TO_BIN(?)", CustomerId);
            //Delete from ProspectCustomer;
            const deleteProspectCust = await connection.query("Delete from prospectcustomer where ContactMobile = ?", mobileNumber);

            if (custResponse[0][0]) {
              await connection.commit();
              await connection.release();
              custResponse[0][0].IsAdmin = false;
              custResponse[0][0].IsDeliveryBoy = false;
              result(null, {
                customer: custResponse[0][0],
                message: "Otp send",
                code: 0
              });

              return;
            }

          }
        } else {

          var user = await sql.query("SELECT BIN_TO_UUID(UserId) as UserId from users");
          if (user[0][0]) {
            var insertInvetee = await sql.query("Insert into prospectcustomer SET ProspectCustomerId =  UUID_TO_BIN(UUID()), CreatedBy = UUID_TO_BIN(?),ContactMobile = ?", [user[0][0].UserId, mobileNumber]);
            if (!insertInvetee[0]) {
              result(insertInvetee[0], null);
              return;
            }
          }
          result(null, {
            message: "You need to be invited by one of our existing users to use eSatvik application. Unfortunately, we could not find your name in the invitee list. We will contact you soon to assist you in registration",
            code: 2,
          });
          return;
        }
      }

    } result(null, {
      customer: null,
      customerAddress: null,
      message: "Invalid OTP",
      code: 1
    });
  } catch (err) {
    console.log(err);
    result(err, null);
  }
};

Customer.updateCustomer = async (customer, result) => {
  var user = await sql.query("update customer set firstName= ?,lastName = ?,ContactEmail = ? where userId = UUID_TO_BIN(?)", [customer.FirstName, customer.LastName, customer.EmailId, customer.UserId]);

  if (user[0] == null) {
    console.log("error: ", "err");
    result(null, { "message": "error" });
    return;
  }

  var customer = await sql.query("SELECT BIN_TO_UUID(CustomerId) as CustomerId,BIN_TO_UUID(UserId) as UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE userId = UUID_TO_BIN(?)", customer.UserId);

  result(null, {
    message: "Customer added successfully",
    code: 0,
    customer: customer[0][0],
  });
};

function generateOTP() {

  var digits = '0123456789';

  var otpLength = 6;

  var otp = '';

  for (let i = 1; i <= otpLength; i++) {

    var index = Math.floor(Math.random() * (digits.length));

    otp = otp + digits[index];

  }

  return otp;

}

async function sendOTP(mobileNumber, otp) {
  const data = JSON.stringify({
    'From': "eStvik",
    'To': mobileNumber,
    'TemplateName': "OTP_NEW",
    'VAR1': otp
  })

  const options = {
    host: '2factor.in',
    path: '/API/V1/9dd7b6d6-2713-11eb-83d4-0200cd936042/ADDON_SERVICES/SEND/TSMS',
    method: 'POST',
    port: null,
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  }
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      console.log('Status Code:', res.statusCode);
      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        console.log('Body: ', JSON.parse(data));
        resolve(JSON.parse(data));
      });
    });

    req.on('error', (err) => {
      console.log("Error: ", err.message);
      reject(err);
    });

    req.write(data)
    req.end();
  });
}

module.exports = Customer;
