const sql = require("./db.js");
const e = require("express");
const moment = require('moment');

// constructor
// Create a Subscription
const Cart = function (cart) {
    this.customerId = cart.customerId,
        this.products = cart.products,
        this.amount = cart.amount,
        this.customerAddressId = cart.customerAddressId,
        this.notes = cart.notes,
        this.product = cart.product
};

Cart.create = async (cart, result) => {
    console.log(cart);
    var connection;

    var connection = await sql.getConnection();

    try {
        await connection.beginTransaction();
        var cartId;

        var cartResponse = await connection.query("SELECT BIN_TO_UUID(CartId) AS CartId from cart where CustomerId = UUID_TO_BIN(?)", cart.customerId);
        if (!cartResponse[0][0]) {
            const cartUUID = await connection.query("SELECT UUID() as CartId");
            cartId = cartUUID[0][0].CartId;
            var cartInsertResponse = await connection.query("INSERT INTO CART SET CartId = UUID_TO_BIN(?),CustomerId = UUID_TO_BIN(?),CustomerAddressId = UUID_TO_BIN(?),Notes = ?", [cartId, cart.customerId, cart.customerAddressId, cart.notes]);

            if (!cartInsertResponse[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While adding item to cart",
                    code: 2,
                });
                return;
            }


        } else {
            //cart id already present enter/update products only.
            cartId = cartResponse[0][0].CartId;
        }
        if (cartId != null) {
            //Take server time;
            var deliveryDate = new Date();
            deliveryDate.setHours(0, 0, 0, 0);
            if (cart.product.deliveryDate == null) {
                var time = new Date();
                var hour = time.getHours();
                var min = time.getMinutes();
                if (hour >= 10 && min > 00) {
                    deliveryDate.setDate(deliveryDate.getDate() + 2);
                } else {
                    deliveryDate.setDate(deliveryDate.getDate() + 1);
                }
            } else {
                deliveryDate = product.deliveryDate;
            }

            var product = cart.product;
            var cartItem = await connection.query("SELECT ProductId from CARTITEM where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId]);
            var cartItemResponse;
            if (!cartItem[0][0]) {
                cartItemResponse = await connection.query("INSERT INTO CARTITEM SET CartItemId =  UUID_TO_BIN(UUID()), cartId = UUID_TO_BIN(?),productId = UUID_TO_BIN(?),productWarehousePricingId = UUID_TO_BIN(?), quantity = ?, productPrice = ?, DeliveryDate = ? ", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId, product.selectedQuantity.cartQuantity, product.selectedQuantity.price, deliveryDate])
            } else if (product.selectedQuantity.cartQuantity == 0) {
                cartItemResponse = await connection.query("DELETE FROM CARTITEM where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId])
            } else {
                cartItemResponse = await connection.query("UPDATE CARTITEM set quantity = ?, productPrice = ?,DeliveryDate = ? where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [product.selectedQuantity.cartQuantity, product.selectedQuantity.price, deliveryDate, cartId, product.productId, product.selectedQuantity.productWarehousePricingId])
            }

            if (!cartItemResponse[0]) {
                await connection.rollback();
                result(null, {
                    message: "Error While adding item to cart",
                    code: 2,
                });
                return;
            }
            await connection.commit();

            var cartDetails = await sql.query("Select c.cartId ,Count(ci.CartItemId) as CartItemCount, sum(ProductPrice * Quantity) as CartTotal from cart c inner join cartitem ci on c.CartId = ci.CartId where c.CustomerId = UUID_TO_BIN(?)", cart.customerId);
            var cartItemCount = 0;
            var cartItemTotal = 0.0;
            if (cartDetails[0][0]) {
                cartItemCount = cartDetails[0][0].CartItemCount;
                cartItemTotal = cartDetails[0][0].CartTotal;
            }

            result(null, {
                message: "Product added",
                code: 0,
                cartItemCount: cartItemCount,
                cartItemTotal: cartItemTotal,
            });
        } else {
            result(null, {
                message: "Error while updating cart",
                code: 2,
            });

        }

    } catch (e) {
        await connection.rollback();
        console.log(e);
        result(null, {
            message: "Error while updating cart",
            code: 2,
        });
    } finally {
        await connection.release();
    }
}


Cart.edit = async (cart, result) => {

    var connection;

    var connection = await sql.getConnection();

    try {
        await connection.beginTransaction();
        var cartId;

        var cartResponse = await connection.query("SELECT BIN_TO_UUID(CartId) AS CartId from cart where CustomerId = UUID_TO_BIN(?)", cart.customerId);
        if (!cartResponse[0][0]) {
            const cartUUID = await connection.query("SELECT UUID() as CartId");
            cartId = cartUUID[0][0].CartId;
            var cartInsertResponse = await connection.query("INSERT INTO CART SET CartId = UUID_TO_BIN(?),CustomerId = UUID_TO_BIN(?),CustomerAddressId = UUID_TO_BIN(?),Notes = ?", [cartId, cart.customerId, cart.customerAddressId, cart.notes]);

            if (!cartInsertResponse[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While adding item to cart",
                    code: 2,
                });
                return;
            }


        } else {
            //cart id already present enter/update products only.
            cartId = cartResponse[0][0].CartId;
        }
        if (cartId != null) {
            //Take server time;
            var deliveryDate = new Date();
            deliveryDate.setHours(0, 0, 0, 0);
            var productDeliveryDate = new Date(cart.product.deliveryDate);
            productDeliveryDate.setHours(0, 0, 0, 0);
            var diffDays = parseInt((deliveryDate - productDeliveryDate) / (1000 * 60 * 60 * 24));
            if (productDeliveryDate == null) {
                var time = new Date();
                var hour = time.getHours();
                var min = time.getMinutes();
                if (hour >= 10 && min > 00) {
                    deliveryDate.setDate(deliveryDate.getDate() + 2);
                } else {
                    deliveryDate.setDate(deliveryDate.getDate() + 1);
                }
            } else if (diffDays >= -1) {
                var time = new Date();
                var hour = time.getHours();
                var min = time.getMinutes();
                if (hour >= 10 && min > 00) {
                    deliveryDate.setDate(deliveryDate.getDate() + 2);

                } else {
                    deliveryDate.setDate(deliveryDate.getDate() + 1);
                }
            } else {
                deliveryDate = productDeliveryDate;
            }

            var product = cart.product;
            var cartItem = await connection.query("SELECT ProductId from CARTITEM where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId]);
            var cartItemResponse;
            if (!cartItem[0][0]) {
                cartItemResponse = await connection.query("INSERT INTO CARTITEM SET CartItemId =  UUID_TO_BIN(UUID()), cartId = UUID_TO_BIN(?),productId = UUID_TO_BIN(?),productWarehousePricingId = UUID_TO_BIN(?), quantity = ?, productPrice = ?, DeliveryDate = ? ", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId, product.selectedQuantity.cartQuantity, product.selectedQuantity.price, deliveryDate])
            } else if (product.selectedQuantity.cartQuantity == 0) {
                cartItemResponse = await connection.query("DELETE FROM CARTITEM where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [cartId, product.productId, product.selectedQuantity.productWarehousePricingId])
            } else {
                cartItemResponse = await connection.query("UPDATE CARTITEM set quantity = ?, productPrice = ?,DeliveryDate = ? where cartId = UUID_TO_BIN(?) AND productId = UUID_TO_BIN(?) AND productWarehousePricingId = UUID_TO_BIN(?)", [product.selectedQuantity.cartQuantity, product.selectedQuantity.price, deliveryDate, cartId, product.productId, product.selectedQuantity.productWarehousePricingId])
            }

            if (!cartItemResponse[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While adding item to cart",
                    code: 2,
                });
                return;
            }
            await connection.commit();

            var cartResponse = await connection.query("SELECT BIN_TO_UUID(p.ProductId) As ProductId ,p.ProductName,p.ProductNameHindi,p.Description, BIN_TO_UUID(p.ProductStatusId) As ProductStatusId ,p.MaxPriceRange, p.MinPriceRange,BIN_TO_UUID(p.ProductCategoryId) As ProductCategoryId,p.MinSubscriptionQty,p.MinOrderQty,p.SeasonStartDate,p.SeasonEndDate, p.IsOrganic,p.IsTaxable,BIN_TO_UUID(p.ProductTypeId) As ProductTypeId, p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId, BIN_TO_UUID(pi.ProductImageId) AS ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, BIN_TO_UUID(c.CartId) As CartId, BIN_TO_UUID(ci.ProductWarehousePricingId) As ProductWarehousePricingId,ci.Quantity as CartQty,ci.DeliveryDate,BIN_TO_UUID(c.CustomerAddressId) As CustomerAddressId from product as p left join productimage as pi on (p.productid = pi.productid) inner join cart as c left join cartitem as ci on (c.CartId =ci.CartId) where ci.ProductId = p.productId AND c.CustomerId = UUID_TO_BIN(?) AND ci.Quantity > 0", cart.customerId);



            if (!cartResponse[0]) {
                result(null, {
                    message: "No cart item available",
                    code: 1,
                });
                return;
            }


            var product = cartResponse[0];
            var totalAmount = 0.0;
            if (product.length == 0) {
                result(null, {
                    message: "success",
                    code: 0,
                    cartItem: product,
                    address: null,
                    cartIdResponse: cartId,
                    creditAmount: creditAmount,
                });
                return;
            }
            for (i in product) {

                var quanity = await connection.query("Select BIN_TO_UUID(pwi.ProductWarehousePricingId) As ProductWarehousePricingId, BIN_TO_UUID(pwi.UnitOfMeasurementId) AS UnitOfMeasurementId ,pwi.ProductUnit,pwi.ProductUnitPrice,u.UnitOfMeasurementCode from productwarehouepricing pwi inner join unitofmeasurement u on pwi.UnitOfMeasurementId = u.UnitOfMeasurementId  inner join productinventory pi on pi.ProductId = pwi.ProductId where pwi.ProductId = UUID_TO_BIN(?) AND pwi.ProductWarehousePricingId=UUID_TO_BIN(?)  AND (pi.InventoryOnHand < pi.InventoryRestockQty) = 0", [product[i].ProductId, product[i].ProductWarehousePricingId]);
                var quanity = quanity[0][0];
                if (quanity.length == 0) {
                    product[i].isOutOfStock = true;
                    quanity.CartQuantity = parseInt(product[i].CartQty);

                } else {
                    quanity.CartQuantity = parseInt(product[i].CartQty);
                    product[i].isOutOfStock = false;
                    product[i].SelectedQuantity = quanity;
                }

                totalAmount = totalAmount + (quanity.CartQuantity * quanity.ProductUnitPrice);
            }
            var deliveryChargesResponse = [];
            var distDeliveryDate = await connection.query("select distinct(Date(DeliveryDate)) as DD from cartitem ci where ci.cartId = UUID_TO_BIN(?) group by date(ci.DeliveryDate)", cartId);
            if (distDeliveryDate[0][0]) {
                var distDD = distDeliveryDate[0];
                for (i in distDD) {
                    var orderDeliveries = await sql.query("select sum(DeliveryCharges) As DeliveryCharges,DeliveryDate from orderdeliveries where customerId = UUID_TO_BIN(?) AND DeliveryDate = Date(?) group by customerId, Date(DeliveryDate)", [cart.customerId, distDD[i].DD]);
                    if (orderDeliveries[0][0]) {
                        deliveryChargesResponse.push({
                            DeliveryDate: orderDeliveries[0][0].DeliveryDate,
                            DeliveryCharges: 0,
                        });
                    } else {
                        var deliveryChargesResp = await sql.query("SELECT DeliveryDate,CASE WHEN sum(ProductPrice * Quantity) < 100 THEN 39 WHEN sum(ProductPrice * Quantity)>= 100 and sum(ProductPrice * Quantity) < 200 THEN 29 WHEN sum(ProductPrice * Quantity) >= 200 and sum(ProductPrice * Quantity) < 300  THEN 19     WHEN sum(ProductPrice * Quantity) >= 300 and sum(ProductPrice * Quantity) < 400  THEN 10 ELSE 0 END as DeliveryCharges FROM cartitem  where cartId = UUID_TO_BIN(?) AND DeliveryDate = Date(?) group by date(DeliveryDate)", [cartId, distDD[i].DD]);
                        if (deliveryChargesResp[0][0]) {
                            deliveryChargesResponse.push({
                                DeliveryDate: deliveryChargesResp[0][0].DeliveryDate,
                                DeliveryCharges: parseInt(deliveryChargesResp[0][0].DeliveryCharges),
                            });
                        }
                    }
                }
            }

            // var deliveryChargesResponse = await sql.query("SELECT DeliveryDate,CASE WHEN sum(ProductPrice * Quantity) < 100 THEN 40 WHEN sum(ProductPrice * Quantity)>= 100 and sum(ProductPrice * Quantity) < 200 THEN 30 WHEN sum(ProductPrice * Quantity) >= 200 and sum(ProductPrice * Quantity) < 300  THEN 20     WHEN sum(ProductPrice * Quantity) >= 300 and sum(ProductPrice * Quantity) < 400  THEN 10 ELSE 0 END as DeliveryCharges FROM cartitem  where cartId = UUID_TO_BIN(?) group by date(DeliveryDate)", cartId);

            var address = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) As CustomerAddressId,ca.IsDefault,BIN_TO_UUID(ca.AddressTypeId) As AddressTypeId,BIN_TO_UUID(ca.CustomerId) As CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, at.AddressType FROM customerAddress ca inner join AddressType at on ca.addressTypeId = at. addressTypeId WHERE CustomerAddressId = UUID_TO_BIN(?)", cartResponse[0][0].CustomerAddressId);


            const customerCreditResponse = await sql.query("SELECT CreditLimit, CreditUsed from CustomerCredits where CustomerId = UUID_TO_BIN(?)", cart.customerId);

            var creditAmount = 00;
            if (!customerCreditResponse[0][0]) {
                creditAmount = 0;
            } else {
                creditAmount = customerCreditResponse[0][0].CreditLimit - customerCreditResponse[0][0].CreditUsed;
            }

            const walletAmountResponse = await sql.query("SELECT WalletBalance from customerwallet where CustomerId = UUID_TO_BIN(?)", cart.customerId);
            var walletAmount = 00;
            if (walletAmountResponse[0][0]) {
                walletAmount = parseInt(walletAmountResponse[0][0].WalletBalance);
            }

            result(null, {
                message: "success",
                code: 0,
                cartItem: product,
                deliveryCharges: deliveryChargesResponse,
                address: address[0][0],
                cartIdResponse: cartId,
                creditAmount: creditAmount,
                walletAmount: walletAmount,
            });

        } else {
            result(null, {
                message: "Error while updating cart",
                code: 2,
            });

        }

    } catch (e) {
        await connection.rollback();
        console.log(e);
        result(null, {
            message: "Error while updating cart",
            code: 2,
        });
    } finally {
        await connection.release();
    }
}

Cart.findById = async (customerId, result) => {
    try {
        var updateCartItem = await sql.query("SELECT SQL_NO_CACHE c.CartId,ci.CartItemId, ci.DeliveryDate from cart as c left join cartitem as ci on (c.CartId = ci.CartId) where c.CustomerId = UUID_TO_BIN(?)", customerId);

        if (updateCartItem[0][0]) {
            //console.log(updateCartItem[0]);
            var cartItem = updateCartItem[0];
            for (i in cartItem) {
                var deliveryDate = new Date();
                deliveryDate.setHours(0, 0, 0, 0);
                var productDeliveryDate = new Date(cartItem[i].DeliveryDate);
                productDeliveryDate.setHours(0, 0, 0, 0);
                var diffDays = parseInt((deliveryDate - productDeliveryDate) / (1000 * 60 * 60 * 24));
                var isUpdateDate = false;
                if (productDeliveryDate == null) {
                    var time = new Date();
                    var hour = time.getHours();
                    var min = time.getMinutes();
                    if (hour >= 10 && min > 00) {
                        deliveryDate.setDate(deliveryDate.getDate() + 2);
                        isUpdateDate = true;
                    } else {
                        deliveryDate.setDate(deliveryDate.getDate() + 1);
                        isUpdateDate = true;
                    }
                } else if (diffDays >= -1) {
                    var time = new Date();
                    var hour = time.getHours();
                    var min = time.getMinutes();
                    if (hour >= 10 && min > 00) {
                        deliveryDate.setDate(deliveryDate.getDate() + 2);
                        isUpdateDate = true;
                    } else {
                        deliveryDate.setDate(deliveryDate.getDate() + 1);
                        isUpdateDate = true;
                    }
                } else {
                    isUpdateDate = false;
                }
                if (isUpdateDate) {
                    var cartItemResponse = await sql.query("UPDATE CARTITEM set DeliveryDate = ? where cartItemId = ?", [deliveryDate, cartItem[i].CartItemId]);
                }
            }
        }

        var cartResponse = await sql.query("SELECT SQL_NO_CACHE BIN_TO_UUID(p.ProductId) As ProductId ,p.ProductName,p.ProductNameHindi,p.Description, BIN_TO_UUID(p.ProductStatusId) As ProductStatusId ,p.MaxPriceRange, p.MinPriceRange,BIN_TO_UUID(p.ProductCategoryId) As ProductCategoryId,p.MinSubscriptionQty,p.MinOrderQty,p.SeasonStartDate,p.SeasonEndDate, p.IsOrganic,p.IsTaxable,BIN_TO_UUID(p.ProductTypeId) As ProductTypeId, p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId, BIN_TO_UUID(pi.ProductImageId) AS ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, BIN_TO_UUID(c.CartId) As CartId, BIN_TO_UUID(ci.ProductWarehousePricingId) As ProductWarehousePricingId,ci.Quantity as CartQty,ci.DeliveryDate,BIN_TO_UUID(c.CustomerAddressId) As CustomerAddressId from product as p left join productimage as pi on (p.productid = pi.productid) inner join cart as c left join cartitem as ci on (c.CartId =ci.CartId) where ci.ProductId = p.productId AND c.CustomerId = UUID_TO_BIN(?) AND ci.Quantity > 0", customerId);

        if (!cartResponse[0][0]) {
            result(null, {
                message: "No cart item available",
                code: 1,
            });
            return;
        }
        var cartId = cartResponse[0][0].CartId;

        var product = cartResponse[0];
        var totalAmount = 0.0;
        for (i in product) {

            var quanity = await sql.query("Select SQL_NO_CACHE BIN_TO_UUID(pwi.ProductWarehousePricingId) As ProductWarehousePricingId, BIN_TO_UUID(pwi.UnitOfMeasurementId) AS UnitOfMeasurementId ,pwi.ProductUnit,pwi.ProductUnitPrice,u.UnitOfMeasurementCode from productwarehouepricing pwi inner join unitofmeasurement u on pwi.UnitOfMeasurementId = u.UnitOfMeasurementId  inner join productinventory pi on pi.ProductId = pwi.ProductId where pwi.ProductId = UUID_TO_BIN(?) AND pwi.ProductWarehousePricingId=UUID_TO_BIN(?)  AND (pi.InventoryOnHand < pi.InventoryRestockQty) = 0", [product[i].ProductId, product[i].ProductWarehousePricingId]);
            var quanity = quanity[0][0];
            if (quanity.length == 0) {
                product[i].isOutOfStock = true;
                quanity.CartQuantity = parseInt(product[i].CartQty);

            } else {
                quanity.CartQuantity = parseInt(product[i].CartQty);
                product[i].isOutOfStock = false;
                product[i].SelectedQuantity = quanity;
            }

            totalAmount = totalAmount + (quanity.CartQuantity * quanity.ProductUnitPrice);
        }

        var deliveryChargesResponse = [];
        var distDeliveryDate = await sql.query("select distinct(Date(DeliveryDate)) as DD from cartitem ci where ci.cartId = UUID_TO_BIN(?) group by date(ci.DeliveryDate)", cartId);
        if (distDeliveryDate[0][0]) {
            var distDD = distDeliveryDate[0];
            for (i in distDD) {
                var orderDeliveries = await sql.query("select sum(DeliveryCharges) As DeliveryCharges,DeliveryDate from orderdeliveries where customerId = UUID_TO_BIN(?) AND DeliveryDate = Date(?) group by customerId, Date(DeliveryDate)", [customerId, distDD[i].DD]);
                if (orderDeliveries[0][0]) {
                    deliveryChargesResponse.push({
                        DeliveryDate: orderDeliveries[0][0].DeliveryDate,
                        DeliveryCharges: 0,
                    });
                } else {
                    var deliveryChargesResp = await sql.query("SELECT DeliveryDate,CASE WHEN sum(ProductPrice * Quantity) < 100 THEN 39 WHEN sum(ProductPrice * Quantity)>= 100 and sum(ProductPrice * Quantity) < 200 THEN 29 WHEN sum(ProductPrice * Quantity) >= 200 and sum(ProductPrice * Quantity) < 300  THEN 19     WHEN sum(ProductPrice * Quantity) >= 300 and sum(ProductPrice * Quantity) < 400  THEN 10 ELSE 0 END as DeliveryCharges FROM cartitem  where cartId = UUID_TO_BIN(?) AND DeliveryDate = date(?) group by date(DeliveryDate)", [cartId, distDD[i].DD]);

                    if (deliveryChargesResp[0][0]) {
                        deliveryChargesResponse.push({
                            DeliveryDate: deliveryChargesResp[0][0].DeliveryDate,
                            DeliveryCharges: parseInt(deliveryChargesResp[0][0].DeliveryCharges),
                        });
                    }
                }
            }
        }
        // var deliveryChargesResponse = await sql.query("SELECT DeliveryDate,CASE WHEN sum(ProductPrice * Quantity) < 100 THEN 40 WHEN sum(ProductPrice * Quantity)>= 100 and sum(ProductPrice * Quantity) < 200 THEN 30 WHEN sum(ProductPrice * Quantity) >= 200 and sum(ProductPrice * Quantity) < 300  THEN 20     WHEN sum(ProductPrice * Quantity) >= 300 and sum(ProductPrice * Quantity) < 400  THEN 10 ELSE 0 END as DeliveryCharges FROM efarms.cartitem  where cartId = UUID_TO_BIN(?) group by date(DeliveryDate)", cartId);

        var address = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) As CustomerAddressId,ca.IsDefault,BIN_TO_UUID(ca.AddressTypeId) As AddressTypeId,BIN_TO_UUID(ca.CustomerId) As CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, at.AddressType FROM customerAddress ca inner join AddressType at on ca.addressTypeId = at. addressTypeId WHERE CustomerAddressId = UUID_TO_BIN(?)", cartResponse[0][0].CustomerAddressId);


        const customerCreditResponse = await sql.query("SELECT CreditLimit, CreditUsed from CustomerCredits where CustomerId = UUID_TO_BIN(?)", customerId);

        var creditAmount = 00;
        if (!customerCreditResponse[0][0]) {
            creditAmount = 0;
        } else {
            creditAmount = customerCreditResponse[0][0].CreditLimit - customerCreditResponse[0][0].CreditUsed;
        }

        const walletAmountResponse = await sql.query("SELECT WalletBalance from customerwallet where CustomerId = UUID_TO_BIN(?)", customerId);
        var walletAmount = 00;
        if (walletAmountResponse[0][0]) {
            walletAmount = parseInt(walletAmountResponse[0][0].WalletBalance);
        }

        result(null, {
            message: "success",
            code: 0,
            cartItem: product,
            deliveryCharges: deliveryChargesResponse,
            address: address[0][0],
            cartIdResponse: cartId,
            creditAmount: creditAmount,
            walletAmount: walletAmount,
        });
    } catch (e) {
        console.log(e);
        result(null, {
            message: "No cart item available",
            code: 1,
        });
        return;
    }

};

Cart.remove = async (cartItem, result) => {

    var cartItemResponse = await sql.query("DELETE FROM cartItem where cartId = ? and productId = ?", [cartItem.cartId, cartItem.productId]);
    if (!cartItemResponse[0]) {
        result(null, {
            message: "Error while removing item from cart",
            code: 3,
        })
        return;
    }

    var count = await sql.query("SELECT cartId from cartItem where cartid = ?", cartItem.cartId);

    if (count[0].length == 0) {
        var cartResponse = await sql.query("DELETE FROM Cart where cartId = ?", cartItem.cartId);
        if (!cartResponse[0]) {
            result(null, {
                message: "Error while removing item from cart",
                code: 3,
            })
            return;
        }
    }

    Cart.findById(cartItem.customerId, result);
};

Cart.removeAll = result => {
    sql.query("DELETE FROM Cart", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }

        console.log(`deleted ${res.affectedRows} Cart`);
        result(null, res);
    });
};

Cart.updateById = async (cartItem, result) => {

    if (cartItem.quantity == 0) {
        //Remove item from the list
        Cart.remove(cartItem, result);
    } else {

        var cartItemResponse = await sql.query("Update CartItem set Qunatity = ?, where cartId = ? AND productId = ?", [cartItem.quantity, cartItem.cartId, cartItem.productId])
        if (!cartItemResponse[0]) {

            result(null, {
                message: "Error while updating product",
                code: 2,
            });
            return;
        }
        Cart.findById(cartItem.customerId, result);
    }

};

module.exports = Cart;

