const sql = require("./db.js");

//constructor
const Warehouse = function (warehouse) {
    //this.WarehouseId = warehouse.WarehouseId,
    this.WarehouseName = warehouse.WarehouseName,
    this.WarehouseDescription = warehouse.WarehouseDescription,
    this.Address1= warehouse.Address1,
    this.Address2 = warehouse.Address2,
    this.Address3 = warehouse.Address3,
    this.CountryId = warehouse.CountryId,
    this.StateId = warehouse.StateId,
    this.CityId = warehouse.CityId,
    this.PostCode = warehouse.PostCode,
    this.ContactName = warehouse.ContactName,
    this.ContactPhone = warehouse.ContactPhone,
    this.Email = warehouse.Email;
};

Warehouse.create = async (newWarehouse, result) => {
  
    var createWarehouse = await sql.query("INSERT INTO warehouse SET WarehouseName = ?, WarehouseDescription = ?, Address1 = ?, Address2 = ?, Address3 = ?, CountryId = ?, StateId = ?, CityId = ?, PostCode = ?, ContactName = ?, ContactPhone = ?, Email = ?", [newWarehouse.WarehouseName, newWarehouse.WarehouseDescription, newWarehouse.Address1, newWarehouse.Address2, newWarehouse.Address3, newWarehouse.CountryId, newWarehouse.StateId, newWarehouse.CityId, newWarehouse.PostCode, newWarehouse.ContactName, newWarehouse.ContactPhone, newWarehouse.Email]);
      if (!createWarehouse[0]) {
        console.log("error: ", createWarehouse[0]);
        result(createWarehouse[0], null);
        return;
      }
  
      console.log("Created Warehouse: ", { WarehouseId: createWarehouse[0].insertId, ...newWarehouse });
      result(null, { message:"Warehouse added successfully",
                    code:0,
                    WarehouseId: createWarehouse[0].insertId, ...newWarehouse });
    
};

Warehouse.findById = async (warehouseId, result) => {
    var findByIdWarehouse = await sql.query(`SELECT WarehouseId,WarehouseName,WarehouseDescription,Address1,Address2,Address3,CountryId,StateId,CityId,PostCode,ContactName,ContactPhone,Email FROM warehouse WHERE WarehouseId = ${warehouseId}`);
  
   if (!findByIdWarehouse[0]) {
        console.log("error: ", findByIdWarehouse[0]);
        result(findByIdWarehouse[0], null);
        return;
      } 
  
      if (findByIdWarehouse[0].length) {
        console.log("found Warehouse: ", findByIdWarehouse[0]);
        result(null, findByIdWarehouse[0]);
        return;
      }
  
      // not found Warehouse with the id
      result({ kind: "not_found" }, null);
};

Warehouse.getAll = async result => {
    var getAllWarehouse = await sql.query("SELECT WarehouseId,WarehouseName,WarehouseDescription,Address1,Address2,Address3,CountryId,StateId,CityId,PostCode,ContactName,ContactPhone,Email FROM warehouse");
      if (!getAllWarehouse[0]) {
        console.log("error: ", getAllWarehouse[0]);
        result(null, getAllWarehouse[0]);
        return;
      }
  
      console.log("Warehouse: ", getAllWarehouse[0]);
      result(null, getAllWarehouse[0]);
};

Warehouse.updateById = async (warehouseId, warehouse, result) => {
    const resultOne = await sql.query(
      "UPDATE warehouse SET WarehouseName = ?, WarehouseDescription = ?, Address1 = ?, Address2 = ?, Address3 = ?, CountryId = ?, StateId = ?, CityId = ?, PostCode = ?, ContactName = ?, ContactPhone = ?, Email = ? WHERE WarehouseId = ?",
      [warehouse.WarehouseName, warehouse.WarehouseDescription, warehouse.Address1, warehouse.Address2, warehouse.Address3, warehouse.CountryId, warehouse.StateId, warehouse.CityId, warehouse.PostCode, warehouse.ContactName, warehouse.ContactPhone, warehouse.Email, warehouseId]);
  
    console.log("result ", resultOne[0]);
  
  
    if (resultOne[0] == null) {
      console.log("error: ", "err");
      result(null, { "message": "error" });
      return;
    }
  
    if (resultOne[0].affectedRows == 0) {
      // not found warehouse with the id
      result({ kind: "not_found" }, null);
      return;
    }
  
    console.log("updated warehouse: ", { Warehouseid: warehouseId, ...warehouse });
    result(null, { message:"Warehouse Updated successfully",
    code:0,
    Warehouseid: warehouseId, ...warehouse });
};
  
Warehouse.remove = async (warehouseId, result) => {
    var removeWarehouse = await sql.query("DELETE FROM warehouse WHERE WarehouseId = ?",warehouseId);
    if (removeWarehouse[0].affectedRows==0) {
      console.log("error: ", removeWarehouse[0]);
      result("not_found",null);
      return;
    }

    console.log("deleted warehouse with WarehouseId: ", warehouseId);
    result(null, removeWarehouse[0]);
 
};

Warehouse.removeAll = async result => {
    var removeAllWarehouse = await sql.query("DELETE FROM warehouse");
      if (!removeAllWarehouse[0]) {
        console.log("error: ", removeAllWarehouse[0]);
        result(null, removeAllWarehouse[0]);
        return;
      }
  
      console.log(`deleted ${removeAllWarehouse[0].affectedRows} warehouses`);
      result(null, removeAllWarehouse[0]);
  
};
  
module.exports = Warehouse;