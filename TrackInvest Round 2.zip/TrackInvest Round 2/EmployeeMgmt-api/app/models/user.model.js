const sql = require("./db.js");

// constructor
const User = function (user) {
  this.username = user.username;
  this.userpassword = user.userpassword;
  this.FirstName = user.FirstName;
  this.MiddleName = user.MiddleName;
  this.LastName = user.LastName;
  this.ContactPhone = user.ContactPhone;
  this.ContactMobile = user.ContactMobile;
  this.ContactEmail = user.ContactEmail;
  //this.isadmin = user.isadmin;
};

User.create = async (newUser, result) => {

  const userData = await sql.query("SELECT UserId,UserTypeId,UserName,UserPassword,IsActive FROM users WHERE username = ?", newUser.ContactMobile);
  console.log("user data", userData[0][0]);

  if (userData[0][0] != null) {
    const customerData = await sql.query("SELECT CustomerId,UserId,FirstName,MiddleName,LastName,CustomerAddressId,ContactPhone,ContactMobile,ContactEmail,IsActive FROM customer WHERE userid = ?", userData[0][0].UserId);
    console.log("user already exists ", customerData[0]);
    result(null, { ...customerData[0][0] })
    return;
  }


  const connection = await sql.getConnection();

  try {
    await connection.beginTransaction();
    var password = newUser.userpassword != null ? newUser.userpassword : "";
    const responseOne = await connection.query("INSERT INTO users SET username = ?, userpassword = ?, usertypeid = 1, CreatedBy = 1", [newUser.ContactMobile, password]);

    if (responseOne[0] == null) {
      result(null, {
        message: "Error While creating user",
        code: 2,
      });
      return;
    }

    console.log("created user: ", { userId: responseOne[0].insertId, ...newUser });

    var customer = {
      userId: responseOne[0].insertId,
      FirstName: newUser.FirstName,
      LastName: newUser.LastName,
      MiddleName: newUser.MiddleName,
      ContactEmail: newUser.ContactEmail,
      ContactMobile: newUser.ContactMobile,
      ContactPhone: newUser.ContactPhone
    };
    //sql.query("INSERT INTO customer SET userId = ?,firstname = ?,lastname = ?,contactPhone = ?,contactMobile = ?,contactEmail = ?", [newUser.userId, newUser.firstname, newUser.lastname, newUser.contactPhone, newUser.contactMobile, newUser.contactEmail], (err, resultw) => {
    const responseTwo = await connection.query("INSERT INTO customer SET userId = ?,firstname = '',lastname = ?,contactPhone = ?,contactMobile = ?,contactEmail = ?", [customer.userId,  customer.LastName, customer.ContactPhone, customer.ContactMobile, customer.ContactEmail]);
    if (responseTwo[0] == null) {
      result(null, {
        message: "Error while creating user",
        code: 3
      })
    }
    connection.commit();
    console.log("created Customer: ", responseTwo[0]);
    customer.CustomerId = responseTwo[0].insertId;
    result(null, { ...customer });
  } catch (err) {
    await connection.rollback();
    result("Error", null);
  };
}

User.findById = (userId, result) => {
  sql.query(`SELECT UserId,UserTypeId,UserName,UserPassword,IsActive FROM users WHERE userId = ${userId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found User with the id
    result({ kind: "not_found" }, null);
  });
};

User.getAll = result => {
  sql.query("SELECT UserId,UserTypeId,UserName,UserPassword,IsActive FROM users", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("users: ", res);
    result(null, res);
  });
};

User.updateById = (userId, user, result) => {
  sql.query(
    "UPDATE users SET username = ?, userpassword = ? WHERE userId = ?",
    [user.username, user.userpassword, userId],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found User with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated user: ", { id: userId, ...user });
      result(null, { id: userId, ...user });
    }
  );
};

User.remove = (userId, result) => {
  sql.query("DELETE FROM users WHERE userId = ?", userId, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found User with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted user with userId: ", userId);
    result(null, res);
  });
};

User.removeAll = result => {
  sql.query("DELETE FROM users", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} users`);
    result(null, res);
  });
};

module.exports = User;
