const sql = require("./db.js");
const e = require("express");
const moment = require('moment');
const https = require('https');
var constants = require('../lib/constants');

// constructor
const Order = function (order) {
    this.customerId = order.customerId,
        this.products = order.products,
        this.customerAddressId = order.customerAddressId,
        this.cartId = order.cartId,
        this.paymentMode = order.paymentMode,
        this.transactionCode = order.transactionCode,
        this.totalAmount = order.totalAmount,
        this.userId = order.userId,
        this.walletAmount = order.walletAmount,
        this.walletAmountUsed = order.walletAmountUsed;
};


Order.placeOrder = async (order, result) => {
    console.log(order);
    var connection = await sql.getConnection();

    try {
        await connection.beginTransaction();

        if (order.paymentMode == 2) {
            const customerCreditResponse = await connection.query("SELECT CreditLimit, CreditUsed from CustomerCredits where CustomerId = UUID_TO_BIN(?)", order.customerId);

            if (!customerCreditResponse[0][0]) {
                await connection.rollback();
                result(null, {
                    message: "Your credit is exhausted. Please select other payment type",
                    code: 3,
                });
                return;
            }


            var availbleCredit = customerCreditResponse[0][0].CreditLimit - customerCreditResponse[0][0].CreditUsed;
            if (availbleCredit < order.totalAmount) {
                await connection.rollback();
                result(null, {
                    message: "Your do not have enough credit. Please select other payment type",
                    code: 3,
                });
                return;
            }
        }

        var invoiceMasterId;
        var paymentMasterId;

        var walletAmount = order.walletAmount;
        var walletAmountUsed = order.walletAmountUsed;

        if (order.paymentMode == 1) {
            var invoiceMaster = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 7);

            var paymentMaster = await connection.query("SELECT BIN_TO_UUID(PaymentTypeMasterId) As PaymentTypeMasterId from paymenttypemaster where PaymentTypeEnumId = ?", 2);

            invoiceMasterId = invoiceMaster[0][0].AppStatusMasterId;//Paid
            paymentMasterId = paymentMaster[0][0].PaymentTypeMasterId;//RazorPay
        } else if (order.paymentMode == 2) {
            var invoiceMaster = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 13);

            var paymentMaster = await connection.query("SELECT BIN_TO_UUID(PaymentTypeMasterId) As PaymentTypeMasterId from paymenttypemaster where PaymentTypeEnumId = ?", 4);

            invoiceMasterId = invoiceMaster[0][0].AppStatusMasterId;//Pay Later
            paymentMasterId = paymentMaster[0][0].PaymentTypeMasterId;//Credit
        } else if (order.paymentMode == 3) {
            var invoiceMaster = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 8);

            var paymentMaster = await connection.query("SELECT BIN_TO_UUID(PaymentTypeMasterId) As PaymentTypeMasterId from paymenttypemaster where PaymentTypeEnumId = ?", 1);

            invoiceMasterId = invoiceMaster[0][0].AppStatusMasterId;//COD
            paymentMasterId = paymentMaster[0][0].PaymentTypeMasterId;//Cash
        } else {
            var invoiceMaster = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 7);

            var paymentMaster = await connection.query("SELECT BIN_TO_UUID(PaymentTypeMasterId) As PaymentTypeMasterId from paymenttypemaster where PaymentTypeEnumId = ?", 5);

            invoiceMasterId = invoiceMaster[0][0].AppStatusMasterId;//Paid
            paymentMasterId = paymentMaster[0][0].PaymentTypeMasterId;//wallet
        }


        const OrderUUID = await connection.query("SELECT UUID() as OrderId");
        const orderId = OrderUUID[0][0].OrderId;

        const orderNum = Math.floor(Math.random() * (9 * (Math.pow(10, 5)))) + (Math.pow(10, 5));
        const orderNumber = 'O' + new Date().getFullYear() + orderNum;

        const invNum = Math.floor(Math.random() * (9 * (Math.pow(10, 5)))) + (Math.pow(10, 5));
        const invoiceNumber = 'I' + new Date().getFullYear() + invNum;

        var orderStatus = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 9);
        var OrderStatusId = orderStatus[0][0].AppStatusMasterId;

        var orderResponse = await connection.query("Insert into ordermaster set orderId = UUID_TO_BIN(?), OrderNumber = ?, customerId = UUID_TO_BIN(?), CustomerAddressId = UUID_TO_BIN(?), orderDate = ?,OrderStatusId = UUID_TO_BIN(?),InvoiceNumber = ?, InvoiceAmount = ?, PaymentStatusId = UUID_TO_BIN(?),CreatedBy = UUID_TO_BIN(?)", [orderId, orderNumber, order.customerId, order.customerAddressId, new Date(), OrderStatusId, invoiceNumber, order.totalAmount, invoiceMasterId, order.userId]);
        if (!orderResponse[0]) {
            connection.rollback();
            result(null, {
                message: "Error While placing order",
                code: 2,
            });
            return;
        }

        var orderItemStatus = await connection.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 1);
        var orderItemStatusId = orderItemStatus[0][0].AppStatusMasterId;

        var warehouse = await connection.query("SELECT BIN_TO_UUID(WarehouseId) AS WarehouseId from warehouse");
        var WarehouseId = warehouse[0][0].WarehouseId;
        for (i in order.products) {
            var product = order.products[i];

            var deliveryDate = new Date();
            deliveryDate.setHours(0, 0, 0, 0);
            var productDeliveryDate = new Date(product.deliveryDate);
            productDeliveryDate.setHours(0, 0, 0, 0);
            var diffDays = parseInt((deliveryDate - productDeliveryDate) / (1000 * 60 * 60 * 24));
            if (productDeliveryDate == null) {
                var time = new Date();
                var hour = time.getHours();
                var min = time.getMinutes();
                if (hour >= 10 && min > 00) {
                    deliveryDate.setDate(deliveryDate.getDate() + 2);

                } else {
                    deliveryDate.setDate(deliveryDate.getDate() + 1);

                }
            } else if (diffDays >= -1) {
                var time = new Date();
                var hour = time.getHours();
                var min = time.getMinutes();
                if (hour >= 10 && min > 00) {
                    deliveryDate.setDate(deliveryDate.getDate() + 2);

                } else {
                    deliveryDate.setDate(deliveryDate.getDate() + 1);

                }
            } else {
                deliveryDate = productDeliveryDate;
            }
            var orderItem = await connection.query("Insert into orderitem set OrderItemId = UUID_TO_BIN(UUID()), orderId = UUID_TO_BIN(?),productId = UUID_TO_BIN(?),ProductWarehousePricingId = UUID_TO_BIN(?),OrderQty = ?, WarehouseId = UUID_TO_BIN(?), UnitPrice = ?, DeliveryDate = ?, InitialDeliveries = ?, TotalDeliveries = ? , PendingDeliveries = ?,OrderItemStatusId = UUID_TO_BIN(?),CreatedBy = UUID_TO_BIN(?)", [orderId, product.productId, product.selectedQuantity.productWarehousePricingId, product.selectedQuantity.cartQuantity, WarehouseId, product.selectedQuantity.price, deliveryDate, 0, 0, 0, orderItemStatusId, order.userId]);

            if (!orderItem[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While placing order",
                    code: 2,
                });
                return;
            }
            var uom = product.selectedQuantity.unitOfMeasurementId;
            var selectedQty = product.selectedQuantity.cartQuantity;
            var unit = product.selectedQuantity.productUnit;
            var subscractQty = unit * selectedQty;
            if (uom == '11eb295d-0bf6-5bce-bd6b-c49deda8deaf') { //UUID for grams
                subscractQty = subscractQty / 1000;
            }

            var ProductInventoryId;
            var prodInvn = await connection.query("Select ProductInventoryId from productwarehouepricing where ProductWarehousePricingId = UUID_TO_BIN(?)", product.selectedQuantity.productWarehousePricingId);
            if (!prodInvn[0][0]) {
                connection.rollback();
                result(null, {
                    message: "Error While Placing Order",
                    code: 2,
                });
                return;
            } else {
                ProductInventoryId = prodInvn[0][0].ProductInventoryId;
            }

            var productInventory = await connection.query("update productinventory set InventoryOnHand = (InventoryOnHand - ?) where ProductInventoryId = ?", [subscractQty, ProductInventoryId]);
            if (!productInventory[0]) {
                await connection.rollback();
                result(null, {
                    message: "Error while updating product",
                    code: 2,
                });
                return;
            }
            //await connection.commit();
        }

        const PaymentUUID = await connection.query("SELECT UUID() as PaymentId");
        const paymentId = PaymentUUID[0][0].PaymentId;
        var paymentInfo;
        if (order.paymentMode != 4) {
            if (walletAmount > 0) {

                paymentInfo = await connection.query("Insert Into payments set PaymentId=UUID_TO_BIN(?), OrderId = UUID_TO_BIN(?),PaymentDate = ?,PaymentAmount = ?,PaymentTypeMasterId = UUID_TO_BIN(?),TransactionCode = ?,CreatedBy = UUID_TO_BIN(?)", [paymentId, orderId, new Date(), walletAmountUsed, constants.WALLET, order.transactionCode, order.userId]);//Wallet

                var amount = order.totalAmount - walletAmountUsed;
                paymentInfo = await connection.query("Insert Into payments set PaymentId=UUID_TO_BIN(UUID()), OrderId = UUID_TO_BIN(?),PaymentDate = ?,PaymentAmount = ?,PaymentTypeMasterId = UUID_TO_BIN(?),TransactionCode = ?,CreatedBy = UUID_TO_BIN(?)", [orderId, new Date(), amount, paymentMasterId, order.transactionCode, order.userId]);

            } else {
                paymentInfo = await connection.query("Insert Into payments set PaymentId=UUID_TO_BIN(?), OrderId = UUID_TO_BIN(?),PaymentDate = ?,PaymentAmount = ?,PaymentTypeMasterId = UUID_TO_BIN(?),TransactionCode = ?,CreatedBy = UUID_TO_BIN(?)", [paymentId, orderId, new Date(), order.totalAmount, paymentMasterId, order.transactionCode, order.userId]);
            }

        } else {
            paymentInfo = await connection.query("Insert Into payments set PaymentId=UUID_TO_BIN(?), OrderId = UUID_TO_BIN(?),PaymentDate = ?,PaymentAmount = ?,PaymentTypeMasterId = UUID_TO_BIN(?),TransactionCode = ?,CreatedBy = UUID_TO_BIN(?)", [paymentId, orderId, new Date(), order.totalAmount, paymentMasterId, order.transactionCode, order.userId]);
        }
        if (!paymentInfo[0]) {
            await connection.rollback();
            result(null, {
                message: "Error while updating invoice",
                code: 2,
            });
            return;
        }
        //Code for pay later/ Credit
        if (order.paymentMode == 2) {

            const updateCutomerCreditResponse = await connection.query("Update CustomerCredits set CreditUsed = (CreditUsed + ?) where CustomerId = UUID_TO_BIN(?)", [order.totalAmount, order.customerId]);

            const CreditUUID = await connection.query("SELECT UUID() as CreditUsageId");
            const CreditUsageId = CreditUUID[0][0].CreditUsageId;

            const creditUsageResponse = await connection.query("Insert into customercreditsusageaudit set CustomerCreditsUsageAuditId = UUID_TO_BIN(?), CustomerId = UUID_TO_BIN(?),OrderId = UUID_TO_BIN(?),CreditsUsed = ?,CreatedBy = UUID_TO_BIN(?)", [CreditUsageId, order.customerId, orderId, order.totalAmount, order.userId])

        }

        if (order.walletAmountUsed > 0) {
            await connection.query("Update customerwallet set WalletBalance = (WalletBalance - ?) where CustomerId = UUID_TO_BIN(?)", [order.walletAmountUsed, order.customerId]);

        }
        await connection.query("Delete from cartitem where cartId = UUID_TO_BIN(?)", order.cartId);
        //connection.commit();
        await connection.query("Delete from cart where cartId = UUID_TO_BIN(?)", order.cartId);

        //await connection.commit();

        var deliveryCharges = await connection.query("SELECT DeliveryDate,CASE WHEN sum(UnitPrice * OrderQty) < 100 THEN 39 WHEN sum(UnitPrice * OrderQty)>= 100 and sum(UnitPrice * OrderQty) < 200 THEN 29 WHEN sum(UnitPrice * OrderQty) >= 200 and sum(UnitPrice * OrderQty) < 300  THEN 19 WHEN sum(UnitPrice * OrderQty) >= 300 and sum(UnitPrice * OrderQty) < 400  THEN 10 ELSE 0 END as DeliveryCharges FROM efarms.orderitem  where orderId= UUID_TO_BIN(?) group by date(DeliveryDate) ", orderId);
        if (deliveryCharges[0][0]) {
            var charges = deliveryCharges[0];
            for (i in charges) {

                var orderDeliveries = await connection.query("Select OrderDeliveryId from orderdeliveries where customerId = UUID_TO_BIN(?) and DeliveryDate = ?", [order.customerId, charges[i].DeliveryDate]);
                if (!orderDeliveries[0][0]) {
                    //var AppStatusMasterId = '11eb2987-5f1f-cba8-bd6b-c49deda8deaf';
                    var deliveries = await connection.query("INSERT into orderdeliveries set OrderDeliveryId = UUID_TO_BIN(UUID()), OrderId = UUID_TO_BIN(?),CustomerId = UUID_TO_BIN(?),DeliveryDate = ?, DeliveryCharges = ?,DeliveryStatusId = UUID_TO_BIN(?)", [orderId, order.customerId, charges[i].DeliveryDate, charges[i].DeliveryCharges, constants.DELIVERY_PENDING]);
                } else {
                    // as we have already charge delivery for this date so now it is zero
                    var deliveries = await connection.query("INSERT into orderdeliveries set OrderDeliveryId = UUID_TO_BIN(UUID()), OrderId = UUID_TO_BIN(?),CustomerId = UUID_TO_BIN(?),DeliveryDate = ?, DeliveryCharges = ?,DeliveryStatusId = UUID_TO_BIN(?)", [orderId, order.customerId, charges[i].DeliveryDate, 0, constants.DELIVERY_PENDING]);
                }
            }

        }

        await connection.commit();
        const custResponse = await connection.query("SELECT ContactMobile FROM customer WHERE CustomerId = UUID_TO_BIN(?)", order.customerId);

        if (custResponse[0][0]) {
            var mobileNumber = custResponse[0][0].ContactMobile;
            var productName = order.products[0].productName;
            var productCount = (order.products.length - 1).toString();

            if (constants.SEND_SMS) {
                if (order.paymentMode == 1) {
                    //online
                    if (order.products.length == 1) {
                        sendOrderPlaceSMS(1, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    } else {
                        sendOrderPlaceSMS(2, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    }
                } else if (order.paymentMode == 2) {
                    //pay later
                    //online
                    if (order.products.length == 1) {
                        sendOrderPlaceSMS(3, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    } else {
                        sendOrderPlaceSMS(4, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    }
                } else if (order.paymentMode == 3) {
                    //COD
                    //online
                    if (order.products.length == 1) {
                        sendOrderPlaceSMS(5, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    } else {
                        sendOrderPlaceSMS(6, mobileNumber, productName, productCount, orderNumber, order.totalAmount);
                    }
                }
            }
        }
        result(null, {
            message: "Order placed",
            code: 0,
        });

    } catch (e) {
        await connection.rollback();
        console.log(e);
        result(null, {
            message: "Error while updating cart",
            code: 2,
        });
    } finally {
        await connection.release();
    }
}

Order.getOrdersByCustomer = async (customerId, count, result) => {

    try {

        console.log(count);
        var itemCount = parseInt(count);
        const maxRecord = 10;
        //var 
        var orderDetails = await sql.query("Select BIN_TO_UUID(om.OrderId) As OrderId,BIN_TO_UUID(om.customerId), om.OrderNumber,om.CustomerAddressId, ad.AddressType, om.OrderDate,om.InvoiceNumber, BIN_TO_UUID(om.OrderStatusId) AS OrderStatusId,  SUM(od.DeliveryCharges), om.InvoiceAmount,BIN_TO_UUID(PaymentStatusId),assm.AppStatusMasterEnumId as OrderEnumId, asm.AppStatusMasterEnumId as PaymentEnumId, asm.StatusDescription as PaymentStatus, assm.StatusDescription as OrderStatus from orderdeliveries od, Ordermaster om, appstatusmaster asm , appstatusmaster assm,customeraddress ca, addresstype ad where om.PaymentStatusId = asm.AppStatusMasterId and od.OrderId = om.OrderId and ca.CustomerAddressId = om.CustomerAddressId and ca.AddressTypeId = ad.AddressTypeId and om.OrderStatusId = assm.AppStatusMasterId AND om.CustomerId = UUID_TO_BIN(?) group by om.orderId order by OrderDate desc limit ?,?", [customerId, itemCount, maxRecord]);


        var outStanding = await sql.query("Select BIN_TO_UUID(OrderId) As OrderId,OrderNumber,  InvoiceAmount from ordermaster where PaymentStatusId = UUID_TO_BIN(?) AND CustomerId = UUID_TO_BIN(?) AND OrderStatusId != UUID_TO_BIN(?)", [constants.PAY_LATER_STATUS, customerId, constants.ORDER_CANCELLED])


        var totalOutStanding = 0;
        if (outStanding[0][0]) {
            var res = outStanding[0];
            for (i in res) {
                totalOutStanding += res[i].InvoiceAmount;
            }
        }

        if (!orderDetails[0][0]) {
            result(null, { code: 2, message: "No orders availble", orders: [], isAllRecord: true });
        } else {
            var isAllRecord = orderDetails[0].length != maxRecord;
            result(null, { code: 0, message: "Success", orders: orderDetails[0], isAllRecord: isAllRecord, totalOutStanding: totalOutStanding, outStandingAmount: outStanding[0] })
        }
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "No orders availble", orders: [] });
    }
}


Order.getOrderItems = async (orderId, result) => {

    try {
        var orderDetails = await sql.query("SELECT BIN_TO_UUID(p.ProductId) AS ProductId,p.ProductName,p.ProductNameHindi,BIN_TO_UUID(p.ProductCategoryId) AS ProductCategoryId, p.IsOrganic,BIN_TO_UUID(pia.ProductImageId) AS ProductImageId,pia.ImageHRPath,pia.ImageLRPath,pia.ImageThumbNailPath, BIN_TO_UUID(om.OrderId) As OrderId, BIN_TO_UUID(om.CustomerAddressId) As CustomerAddressId,BIN_TO_UUID(oi.OrderItemId) as OrderItemId, BIN_TO_UUID(oi.ProductWarehousePricingId) As ProductWarehousePricingId, oi.DeliveryDate,oi.OrderQty as CartQty, oi.UnitPrice, BIN_TO_UUID(oi.OrderItemStatusId) As OrderItemStatusMasteId, asm.StatusDescription As OrderItemStatusCode, BIN_TO_UUID(pwp.UnitOfMeasurementId) As UnitOfMeasurementId, pwp.ProductUnit, um.UnitOfMeasurementCode from product p inner join productimage pia on p.ProductId = pia.ProductId inner join orderitem oi on oi.ProductId = p.ProductId inner join ordermaster om on om.OrderId = oi.OrderId inner join productwarehouepricing pwp on pwp.ProductWarehousePricingId = oi.ProductWarehousePricingId inner join unitofmeasurement um on pwp.UnitOfMeasurementId = um.UnitOfMeasurementId inner join appstatusmaster asm on asm.AppStatusMasterId = oi.OrderItemStatusId where om.orderId = UUID_TO_BIN(?)", orderId);

        if (!orderDetails[0][0]) {
            result(null, { code: 2, message: "No orders items", orderItem: [] });
            return;
        }

        result(null, {
            message: "success",
            code: 0,
            orderItem: orderDetails[0],
        });

    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "No orders availble", orders: [] });
    }
}


Order.cancelOrder = async (orderId, userId, result) => {
    var connection = await sql.getConnection();

    try {
        await connection.beginTransaction();
        var orderDetails = await connection.query("SELECT BIN_TO_UUID(OrderId) as OrderId,OrderNumber,BIN_TO_UUID(CustomerId) as CustomerId ,BIN_TO_UUID(PaymentStatusId) as PaymentStatusId,InvoiceAmount from ordermaster where OrderId = UUID_TO_BIN(?) and OrderStatusId = UUID_TO_BIN(?)", [orderId, constants.ORDER_PENDING]);

        if (!orderDetails[0][0]) {
            result(null, {
                message: "Cannot cancel this order",
                code: 2,
            });

            return;
        }

        var updateOrderMaster = await connection.query("Update ordermaster set OrderStatusId=UUID_TO_BIN(?),IsCanceled = 1 where orderid = UUID_TO_BIN(?)", [constants.ORDER_CANCELLED, orderId]);

        var paymentType = orderDetails[0][0].PaymentStatusId;

        var paymentResponse = await connection.query("SELECT PaymentAmount, BIN_TO_UUID(PaymentTypeMasterId) as PaymentTypeMasterId from payments where OrderId = UUID_TO_BIN(?)", orderId);

        if (paymentResponse[0][0]) {
            var res = paymentResponse[0];
            for (i in res) {
                paymentType = res[i].PaymentTypeMasterId;
                if (paymentType == constants.CASH) {

                    var response = await connection.query("SELECT BIN_TO_UUID(OrderId) as OrderId from ordercancelations where orderId = UUID_TO_BIN(?)", orderId);
                    //COD
                    if (!response[0][0]) {
                        var cancelOrder = await connection.query("Insert into ordercancelations set OrderCancelationId = UUID_TO_BIN(UUID()), orderId = UUID_TO_BIN(?),UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 0,CreatedBy= UUID_TO_BIN(?)", [orderId, constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId]);
                    }
                    else {
                        var cancelOrder = await connection.query("Update ordercancelations set UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 0,CreatedBy= UUID_TO_BIN(?),UpdatedBy =  UUID_TO_BIN(?), UpdatedDate = (?) where orderId = UUID_TO_BIN(?)", [constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId, userId, new Date(), orderId]);
                    }
                } else if (paymentType == constants.RAZOR_PAY || paymentType == constants.WALLET) {
                    //Update customer wallet/
                    var response = await connection.query("SELECT BIN_TO_UUID(OrderId) as OrderId from ordercancelations where orderId = UUID_TO_BIN(?)", orderId);


                    var wallet = await connection.query("Select BIN_TO_UUID(CustomerWalletId) from customerwallet where CustomerId = UUID_TO_BIN(?)", orderDetails[0][0].CustomerId);

                    if (!wallet[0][0]) {
                        var walletResponse = await connection.query("INSERT into customerwallet set CustomerWalletId = UUID_TO_BIN(UUID()), CustomerId = UUID_TO_BIN(?), PaymentTypeMasterId = UUID_TO_BIN(?), WalletBalance = (?),CreatedBy = UUID_TO_BIN(?)", [orderDetails[0][0].CustomerId, paymentType, res[i].PaymentAmount, userId]);
                    } else {
                        var walletResponse = await connection.query("Update customerwallet set  WalletBalance = (WalletBalance + ?),UpdatedBy = UUID_TO_BIN(?),UpdatedDate = (?)", [res[i].PaymentAmount, userId, new Date()]);
                    }

                    if (!response[0][0]) {
                        var cancelOrder = await connection.query("Insert into ordercancelations set OrderCancelationId = UUID_TO_BIN(UUID()), orderId = UUID_TO_BIN(?),UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 1,CreatedBy= UUID_TO_BIN(?)", [orderId, constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId]);
                    }
                    else {
                        var cancelOrder = await connection.query("Update ordercancelations set UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 1,CreatedBy= UUID_TO_BIN(?),UpdatedBy =  UUID_TO_BIN(?), UpdatedDate = (?)  where orderId = UUID_TO_BIN(?)", [constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId, userId, new Date(), orderId]);
                    }

                } else if (paymentType == constants.CREDIT) {
                    var response = await connection.query("SELECT BIN_TO_UUID(OrderId) as OrderId from ordercancelations where orderId = UUID_TO_BIN(?)", orderId);

                    if (!response[0][0]) {
                        var cancelOrder = await connection.query("Insert into ordercancelations set OrderCancelationId = UUID_TO_BIN(UUID()), orderId = UUID_TO_BIN(?),UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 0,CreatedBy= UUID_TO_BIN(?)", [orderId, constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId]);
                    }
                    else {
                        var cancelOrder = await connection.query("Update ordercancelations set UserTypeId = UUID_TO_BIN(?),CancelationReasonId= UUID_TO_BIN(?),IsWalletCredited = 0,CreatedBy= UUID_TO_BIN(?),UpdatedBy =  UUID_TO_BIN(?), UpdatedDate = (?) where orderId = UUID_TO_BIN(?)", [constants.USER_TYPE_UUID, constants.CANCELATION_REASON, userId, userId, new Date(), orderId]);
                    }
                    //restore credit used.
                    const updateCutomerCreditResponse = await connection.query("Update CustomerCredits set CreditUsed = (CreditUsed + ?) where CustomerId = UUID_TO_BIN(?)", [orderDetails[0][0].InvoiceAmount, orderDetails[0][0].CustomerId]);
                }
                await connection.commit();
            }
        }

        var deliveryCharges = await connection.query("DELETE FROM orderdeliveries where  OrderId =UUID_TO_BIN(?) and CustomerId = UUID_TO_BIN(?)", [orderId, orderDetails[0][0].CustomerId]);
        var orderItem = await connection.query("UPDATE orderitem set OrderItemStatusId = UUID_TO_BIN(?) where OrderId =UUID_TO_BIN(?)", [constants.ORDER_ITEM_CANCEL, orderId])

        await connection.commit();
        Order.getOrderItems(orderId, result);

    } catch (e) {
        await connection.rollback();
        console.log(e);
        result(null, {
            message: "Error while updating order",
            code: 2,
        });
    } finally {
        await connection.release();
    }

}

async function sendOrderPlaceSMS(orderType, mobileNumber, productName, count, orderId, price) {
    var TemplateName = getTemplateNameForOrderPlace(orderType);
    const data = getBodyParametersForOrderPlace(orderType, mobileNumber, TemplateName, productName, count, orderId, price)

    const options = {
        host: '2factor.in',
        path: '/API/V1/9dd7b6d6-2713-11eb-83d4-0200cd936042/ADDON_SERVICES/SEND/TSMS',
        method: 'POST',
        port: null,
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    }

    const req = https.request(options, (res) => {
        let data = '';

        console.log('Status Code:', res.statusCode);

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Body: ', JSON.parse(data));
        });

    }).on("error", (err) => {
        console.log("Error: ", err.message);
    });

    req.write(data);
    req.end();

}

function getTemplateNameForOrderPlace(typeId) {
    switch (typeId) {
        case 1:
            return 'OrdSingPrdPaid';
        case 2:
            return 'OrdMulPrdPaid';
        case 3:
            return 'OrdSingPrdPayLtr';
        case 4: return 'OrdMulPrdPayLtr';
        case 5: return 'OrdSingPrdCOD';
        case 6: return 'OrdMulPrdCOD';
    }
}

function getBodyParametersForOrderPlace(typeId, mobileNumber, TemplateName, englishName, count, orderId, price) {
    switch (typeId) {
        case 1: return getBodySingleProductPaid(mobileNumber, TemplateName, englishName, orderId);
        case 2: return getBodyMultipleProductPaid(mobileNumber, TemplateName, englishName, count, orderId);
        case 3: return getBodySingleProductPayLater(mobileNumber, TemplateName, englishName, orderId);
        case 4: return getBodyMultipleProductPaidPayLater(mobileNumber, TemplateName, englishName, count, orderId);
        case 5: return getBodySingleProductCOD(mobileNumber, TemplateName, englishName, orderId, price);
        case 6: return getBodyMultipleProductCOD(mobileNumber, TemplateName, englishName, count, orderId, price);
    }
}


function getBodySingleProductPaid(mobileNumber, TemplateName, var1, var2) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': var1,//English Name
        'VAR2': var2,//OrderID
    });
    console.log(data);
    return data;
}
function getBodyMultipleProductPaid(mobileNumber, TemplateName, var1, var2, var3) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order multiple Product Paid
        'VAR1': var1,//English Name
        'VAR2': var2,//Product count
        'VAR3': var3,//OrderID
    });

    console.log(data);
    return data;
}
function getBodySingleProductPayLater(mobileNumber, TemplateName, var1, var2) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Pay Later
        'VAR1': var1,//English Name
        'VAR2': var2,//OrderID
    });

    console.log(data);
    return data;
}
function getBodyMultipleProductPaidPayLater(mobileNumber, TemplateName, var1, var2, var3) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order multiple Product Pay Later
        'VAR1': var1,//English Name
        'VAR2': var2,//Product count
        'VAR3': var3,//OrderID
    });
    console.log(data);
    return data;
}
function getBodySingleProductCOD(mobileNumber, TemplateName, var1, var2, var3) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product COD
        'VAR1': var1,//English Name
        'VAR2': var2,//OrderID
        'VAR3': var3,//price
    });
    console.log(data);
    return data;
}
function getBodyMultipleProductCOD(mobileNumber, TemplateName, english, var2, var3, var4) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Multiple Product COD
        'VAR1': english,//English Name
        'VAR2': var2,//Product Count
        'VAR3': var3,//OrderID
        'VAR4': var4,//Price
    });
    console.log(data);
    return data;
}

module.exports = Order;
