const sql = require("./db.js");

// constructor
const Auth = function (user) {
    this.username = user.username;
    this.userpassword = user.userpassword;
    this.displayname = user.firstname + ' ' + user.middlename + ' ' + user.lastname;
    this.isadmin = user.isadmin;
    //
};

Auth.signIn = async (user, result) => {
    const responseOne = await sql.query("SELECT userid, username FROM users WHERE username = ?", user.username);

    console.log("response ", responseOne[0]);
    if (responseOne[0][0] == null) {
        console.log("error: ", responseOne[1]);
        result(null,{
            message: "Invalid User",
            code: 2,
            user:"sad"
        });
        return;
    }

    const responseTwo = await sql.query("SELECT u.userid, r.roleid, u.username, r.rolename, rt.roletype FROM userroles ur Inner Join users u ON u.userid = ur.userid Inner Join roles r ON r.roleid = ur.roleid Inner Join roletype rt ON rt.roletypeid = r.roleid Where u.username = ?", user.username);

    console.log("response ", responseTwo[0]);

    var authorities = []
    for (let i = 0; i < responseTwo[0].length; i++) {
        authorities.push("ROLE_" + responseTwo[0][i].rolename.toUpperCase());
        console.log("response ", responseTwo[0][i].rolename.toUpperCase());
    }

    result(null, {
        userid: responseOne[0][0].userid,
        username: responseOne[0][0].username,
        roles: authorities,
    });

    // sql.query("SELECT userid, username, FROM users WHERE username = ?", user.username, (err, res) => {
    //     if (err) {///
    //         console.log("error: ", err);
    //         result(err, null);
    //         return;
    //     }
    //     console.log('REs', res);
    //     var authorities = [];
    //     sql.query("SELECT u.userid, r.roleid, u.username, r.rolename, rt.roletype FROM userroles ur Inner Join users u ON u.userid = ur.userid Inner Join roles r ON r.roleid = ur.roleid Inner Join roletype rt ON rt.roletypeid = r.roletypeid Where u.username = ?", user.username, (err, resRoles) => {
    //         if (err) {
    //             console.log("error: ", err);
    //             result(err, null);
    //             return;
    //         }
    //         console.log('REs', resRoles);
    //         for (let i = 0; i < resRoles.length; i++) {
    //             authorities.push("ROLE_" + resRoles[i].rolename.toUpperCase());
    //         }
    //         console.log("created user: ", { userId: resRoles });
    //         console.log("sadhksh: ", { userId: res.insertId });
    //         result(null, {
    //             userid: res[0].userid,
    //             username: res[0].username,
    //             email: res[0].email,
    //             roles: authorities,
    //         });
    //     });
    // });
};


module.exports = Auth;