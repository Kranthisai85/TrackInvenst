const { response } = require("express");
const sql = require("./db.js");

//constructor
const Wallet = function (warehouse) {

};

Wallet.getAllDetails = async (customerId, result) => {


    var walletResp = await sql.query("Select WalletBalance from customerwallet where CustomerId = UUID_TO_BIN(?)", customerId);
    if (walletResp[0][0]) {
        var payment = await sql.query("select BIN_TO_UUID(o.orderid) AS orderid,o.OrderNumber,p.PaymentDate as transcationDate,p.PaymentAmount as transcationAmount, false as isAdded from ordermaster o, payments p where  o.OrderId = p.OrderId and o.CustomerId =UUID_TO_BIN(?) and p.PaymentTypeMasterId = UUID_TO_BIN('4fd71ce0-3ad6-11eb-ae77-c85b76c8d1d8')", customerId);

        var orderCancelation = await sql.query("select BIN_TO_UUID(o.orderid) AS orderid,o.OrderNumber,o.invoiceamount as transcationAmount,oc.CreatedDate as transcationDate, true as isAdded from ordermaster o, ordercancelations oc where o.OrderId = oc.OrderId and o.CustomerId =UUID_TO_BIN(?) and oc.IsWalletCredited=1", customerId)

        var response = [];

        if (payment[0][0])
            for (i in payment[0]) {
                var wallet = {};
                console.log(payment[0][i]);
                wallet.orderid = payment[0][i].orderid;
                wallet.orderNumber = payment[0][i].OrderNumber;
                wallet.transcationDate = payment[0][i].transcationDate;
                wallet.transcationAmount = payment[0][i].transcationAmount;
                wallet.isAdded = false;
                response.push(wallet);
            }

        if (orderCancelation[0][0])
            for (j in orderCancelation[0]) {
                var wallet = {};
                wallet.orderid = orderCancelation[0][j].orderid;
                wallet.orderNumber = orderCancelation[0][j].OrderNumber;
                wallet.transcationDate = orderCancelation[0][j].transcationDate;
                wallet.transcationAmount = orderCancelation[0][j].transcationAmount;
                wallet.isAdded = true;
                response.push(wallet);

            }


        if (response.length > 0) {
            response.sort((a, b) => b.transcationDate - a.transcationDate)
        }
        result(null, {
            message: "Success",
            code: 0,
            walletItem: response,
            walletAmount: parseInt(walletResp[0][0].WalletBalance),
        });
    } else {
        result(null, {
            message: "Failed",
            code: 2,

        });
    }
};

module.exports = Wallet;