const sql = require("./db.js");
const e = require("express");
const moment = require('moment');
const https = require('https');
var constants = require('../lib/constants');

const Payment = function (payment) {
    this.customerId = payment.customerId,
        this.orders = payment.orders,
        this.transactionCode = payment.transactionCode,
        this.userId = payment.userId,
        this.totalAmount = payment.totalAmount
};

Payment.makeOutStandingPayment = async (payment, result) => {
    try {
        var invoiceMaster = await sql.query("SELECT BIN_TO_UUID(AppStatusMasterId) As AppStatusMasterId from appstatusmaster where AppStatusMasterEnumId = ?", 7);

        var paymentMaster = await sql.query("SELECT BIN_TO_UUID(PaymentTypeMasterId) As PaymentTypeMasterId from paymenttypemaster where PaymentTypeEnumId = ?", 2);

        invoiceMasterId = invoiceMaster[0][0].AppStatusMasterId;//Paid
        paymentMasterId = paymentMaster[0][0].PaymentTypeMasterId;//RazorPay


        if (payment.orders != null && payment.orders.length > 0) {
            for (i in payment.orders) {
                var order = payment.orders[i];
                var orderResponse = await sql.query("Update ordermaster set PaymentStatusId = UUID_TO_BIN(?),UpdatedDate = ?, UpdatedBy = UUID_TO_BIN(?) where OrderId = UUID_TO_BIN(?)", [invoiceMasterId, new Date(), payment.userId, order.orderId]);

                var paymentInfo = await sql.query("Update payments set PaymentTypeMasterId = UUID_TO_BIN(?),TransactionCode = ?,UpdatedDate = ?, UpdatedBy = UUID_TO_BIN(?) where OrderId = UUID_TO_BIN(?)", [paymentMasterId, payment.transactionCode, new Date(), payment.userId, order.orderId]);
            }

            const updateCutomerCreditResponse = await sql.query("Update CustomerCredits set CreditUsed = (CreditUsed - ?) where CustomerId = UUID_TO_BIN(?)", [payment.totalAmount, payment.customerId]);

            result(null, {
                message: "Success",
                code: 0,
            });
            return;
        }
        result(null, {
            message: "Error while making payment",
            code: 2,
        });
    } catch (e) {
        console.log(e);
        result(null, {
            message: "Error while making payment",
            code: 2,
        });
    }
}

module.exports = Payment;