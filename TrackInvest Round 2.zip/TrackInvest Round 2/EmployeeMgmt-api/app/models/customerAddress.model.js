const { request } = require("express");
const sql = require("./db.js");

// constructor
const CustomerAddress = function (customerAddress) {

  this.addressTypeId = customerAddress.addressTypeId,
    this.customerId = customerAddress.customerId,
    this.address1 = customerAddress.address1,
    this.address2 = customerAddress.address2,
    //this.countryId = customerAddress.countryId,
    //this.stateId = customerAddress.stateId,
    this.cityId = customerAddress.cityId,
    //this.areaId = customerAddress.areaId,
    this.area = customerAddress.area,
    this.isDefault = customerAddress.isDefault,
    this.prefredDeliveryDays = customerAddress.prefredDeliveryDays,
    this.pincode = customerAddress.pincode,
    this.landmark = customerAddress.landmark,
    this.city = customerAddress.city,
    this.contactName = customerAddress.contactName,
    this.contactPhone = customerAddress.contactPhone,
    this.otherAddressType = customerAddress.otherAddressType;
  //this.isadmin = user.isadmin;
};

CustomerAddress.create = async (newCustomer, result) => {


  var connection = await sql.getConnection();
  try {
    await connection.beginTransaction();

    var pincodeDetails = await connection.query("SELECT WarehouseId from warehousepincodefences where DeliveryPinCode= ?", newCustomer.pincode);

    if (!pincodeDetails[0][0]) {
      result(null, {
        message: "We do not service this location right now. We shall contact you as soon as we start delivering in your area",
        code: 3
      });
      return;
    }

    var addressType = await connection.query("Select AddressTypeId from addressType where AddressEnumTypeId = ?", newCustomer.addressTypeId);
    if (!addressType[0][0]) {
      addressType = await connection.query("Select AddressTypeId from addressType");
    }

    var addTypeId = addressType[0][0].AddressTypeId;

    const customerAddressUUID = await connection.query("Select UUID() as CustomerAddressUUID");
    const CustomerAddressId = customerAddressUUID[0][0].CustomerAddressUUID;


    var createCustomerAddress = await connection.query("INSERT INTO customerAddress SET CustomerAddressId =  UUID_TO_BIN(?), AddressTypeId = ?,AddressTypeAnnotation = ?,CustomerId = UUID_TO_BIN(?), ContactPhone = ?, CotactName = ?, Address1 = ?,Address2 = ?,CountryId = ?,StateId = ?,CityId = ?,AreaId = ?,IsActive = 1,Landmark = ?, Postcode = ?, AreaDescription = ?, IsDefault = ?", [CustomerAddressId, addTypeId, newCustomer.otherAddressType, newCustomer.customerId, newCustomer.contactPhone, newCustomer.contactName, newCustomer.address1, newCustomer.address2, 1, 1, newCustomer.cityId, 1, newCustomer.landmark, newCustomer.pincode, newCustomer.area, newCustomer.isDefault]);
    if (!createCustomerAddress[0]) {
      await connection.rollback();
      result({
        message: "Error while updating details",
        code: 2
      }, null);
      return;
    }

    await connection.commit();

    if (newCustomer.prefredDeliveryDays != null) {
      for (i in newCustomer.prefredDeliveryDays) {
        var day = newCustomer.prefredDeliveryDays[i];
        const PrefUUID = await connection.query("Select UUID() as Pref");
        const PrefId = PrefUUID[0][0].Pref;
        var preDays = await connection.query("insert into preferreddeliverydays set PreferedDeliveryDaysId = UUID_TO_BIN(?), customerAddressId = UUID_TO_BIN(?),weekdayId = ?", [PrefId, CustomerAddressId, day]);
        if (!preDays[0]) {
          await connection.rollback();
          result({
            message: "Error while updating details",
            code: 2
          }, null);
          return;
        }
      }
    }

    var customerAddress = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) AS CustomerAddressId, BIN_TO_UUID(ca.AddressTypeId) As AddressTypeId,ca.AddressTypeAnnotation,ca.ContactPhone,ca.CotactName, BIN_TO_UUID(ca.CustomerId) As CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, ca.IsDefault, a.AddressType,ca.AreaDescription,ci.City FROM customerAddress ca inner join AddressType a  on ca.AddressTypeId = a.AddressTypeId inner join cities ci on ca.CityId = ci.CityId WHERE ca.CustomerId = UUID_TO_BIN(?) ", newCustomer.customerId);

    if (!customerAddress[0][0]) {
      await connection.rollback();
      result({
        message: "Error while updating details",
        code: 2
      }, null);
      return;
    }
    await connection.commit();
    result(null, {
      message: "Customer Address added successfully",
      code: 0,
      customerAddress: customerAddress[0],
    });
  } catch (err) {
    console.log(err);
    await connection.rollback();
    result({
      message: "Something went wrong",
      code: 2
    }, null);
    return;
  } finally {
    await connection.release();
  }
}

CustomerAddress.findById = async (customerId, result) => {
  var customerAddress = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) AS CustomerAddressId, BIN_TO_UUID(ca.AddressTypeId) As AddressTypeId,ca.AddressTypeAnnotation,ca.ContactPhone,ca.CotactName, BIN_TO_UUID(ca.CustomerId) As CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, ca.IsDefault, a.AddressType,ca.AreaDescription,ci.City FROM customerAddress ca inner join AddressType a  on ca.AddressTypeId = a.AddressTypeId inner join cities ci on ca.CityId = ci.CityId WHERE ca.CustomerId = UUID_TO_BIN(?) ", customerId);

  if (!customerAddress[0]) {
    console.log("error: ", customerAddress[0]);
    result(null, {
      code: 2,
      message: "failed",
      customerAddress: customerAddress[0]
    });
    return;
  }

  if (customerAddress[0].length > 0) {
    console.log("found Customer Address: ", customerAddress[0]);
    result(null, {
      code: 0,
      message: "success",
      customerAddress: customerAddress[0]
    });
    return;
  }

  // not found customer with the id
  result(null, {
    code: 2,
    message: "failed",
    customerAddress: customerAddress[0]
  });
};


CustomerAddress.getAll = async result => {
  var getAllCustomerAddress = await sql.query("SELECT CustomerAddressId,AddressTypeId,CustomerId,Address1,Address2,CountryId,StateId,CityId,AreaId,IsActive FROM customerAddress");
  if (!getAllCustomerAddress[0]) {
    console.log("error: ", getAllCustomerAddress[0]);
    result(null, getAllCustomerAddress[0]);
    return;
  }

  console.log("Customers Address: ", getAllCustomerAddress[0]);
  result(null, getAllCustomerAddress[0]);
};

CustomerAddress.updateById = async (customerAddressId, customerAddress, result) => {
  const resultOne = await sql.query(
    "UPDATE customerAddress SET AddressTypeId = ?,CustomerId = ?,Address1 = ?,Address2 = ?,CountryId = ?,StateId = ?,CityId = ?,AreaId = ?,IsActive = ?",
    [customerAddress.AddressTypeId, customerAddress.CustomerId, customerAddress.Address1, customerAddress.Address2, customerAddress.CountryId, customerAddress.StateId, customerAddress.CityId, customerAddress.AreaId, customerAddress.IsActive]);

  console.log("result ", resultOne[0]);


  if (resultOne[0] == null) {
    console.log("error: ", "err");
    result(null, { "message": "error" });
    return;
  }

  if (resultOne[0].affectedRows == 0) {
    // not found customer with the id
    result({ kind: "not_found" }, null);
    return;
  }

  console.log("updated customer: ", { CustomerAddressid: customerAddressId, ...customerAddress });
  result(null, {
    message: "Customer Updated successfully",
    code: 0,
    CustomerAddressid: customerAddressId, ...customerAddress
  });
};

CustomerAddress.remove = async (customerAddressId, result) => {
  var removeCustomerAddress = await sql.query("DELETE FROM customer WHERE CustomerAddressId = ?", customerAddressId);
  if (!removeCustomerAddress[0]) {
    console.log("error: ", removeCustomerAddress[0]);
    result(null, removeCustomerAddress[0]);
    return;
  }

  console.log("deleted customer Address with CustomerAddressId: ", customerAddressId);
  result(null, removeCustomerAddress[0]);

};

CustomerAddress.removeAll = async result => {
  var removeAllCustomerAddress = await sql.query("DELETE FROM customerAddress");
  if (!removeAllCustomerAddress[0]) {
    console.log("error: ", removeAllCustomerAddress[0]);
    result(null, removeAllCustomerAddress[0]);
    return;
  }

  console.log(`deleted ${removeAllCustomerAddress[0].affectedRows} customers Address`);
  result(null, removeAllCustomerAddress[0]);

};

CustomerAddress.registerCustomer = async (req, result) => {
  var customerId = req.body.customerId;
  var address1 = req.body.address1;
  var address2 = req.body.address2;
  var landmark = req.body.landmark;
  var pincode = req.body.pincode;
  var firstName = req.body.firstName;
  var lastName = req.body.lastName;
  var addressTypeId = req.body.addressTypeId;
  var area = req.body.area;
  var mobileNumber = req.body.mobileNumber;
  var CountryId = 1;
  var StateId = 1;
  var cityId = req.body.cityId;
  var areaId = 1;
  var prefredDeliveryDays = req.body.prefredDeliveryDays;
  var modeOfCommunication = req.body.modeOfCommunication;
  var userId = req.body.userId;
  var isDefault = req.body.isDefault;
  var emailId = req.body.emailId;
  var otherAddressType = req.body.otherAddressType;

  const connection = await sql.getConnection();
  try {
    await connection.beginTransaction();

    var pincodeDetails = await connection.query("SELECT WarehouseId from warehousepincodefences where DeliveryPinCode = ?", pincode);

    if (!pincodeDetails[0][0]) {
      result(null, {
        message: "eSatvik services are not available at this location yet.",
        code: 3
      });
      return;
    }


    var user = await connection.query("update customer set firstName= ?,lastName = ?,ContactEmail = ? where userId = UUID_TO_BIN(?)", [firstName, lastName, emailId, userId]);
    if (!user[0]) {
      await connection.rollback();
      result({
        message: "Error while updating details",
        code: 2
      }, null);
      return;
    }
    var fullName = firstName + " " + lastName;

    var userDetails = await connection.query("Select ContactMobile from  customer where userId = UUID_TO_BIN(?)", [userId]);
    
    mobileNumber = userDetails[0][0].ContactMobile;

    var addressType = await connection.query("Select AddressTypeId from addressType where AddressEnumTypeId = ?", addressTypeId);
    if (!addressType[0][0]) {
      addressType = await connection.query("Select AddressTypeId from addressType");
    }

    var addTypeId = addressType[0][0].AddressTypeId;

    const customerAddressUUID = await connection.query("Select UUID() as CustomerAddressUUID");
    const CustomerAddressId = customerAddressUUID[0][0].CustomerAddressUUID;

    var createCustomerAddress = await connection.query("INSERT INTO customerAddress SET CustomerAddressId =  UUID_TO_BIN(?), AddressTypeId = ?,AddressTypeAnnotation = ?, CustomerId = UUID_TO_BIN(?), ContactPhone = ?, CotactName = ?, Address1 = ?,Address2 = ?,CountryId = ?,StateId = ?,CityId = ?,AreaId = ?,IsActive = 1,Landmark = ?, Postcode = ?, AreaDescription = ?, IsDefault = ?", [CustomerAddressId, addTypeId, otherAddressType, customerId, mobileNumber, fullName, address1, address2, CountryId, StateId, cityId, areaId, landmark, pincode, area, isDefault]);
    if (!createCustomerAddress[0]) {
      await connection.rollback();
      result({
        message: "Error while updating details",
        code: 2
      }, null);
      return;
    }

    await connection.commit();

    if (prefredDeliveryDays != null) {
      for (i in prefredDeliveryDays) {
        var day = prefredDeliveryDays[i];
        const PrefUUID = await connection.query("Select UUID() as Pref");
        const PrefId = PrefUUID[0][0].Pref;
        var preDays = await connection.query("insert into preferreddeliverydays set PreferedDeliveryDaysId = UUID_TO_BIN(?), customerAddressId = UUID_TO_BIN(?),weekdayId = ?", [PrefId, CustomerAddressId, day]);
        if (!preDays[0]) {
          await connection.rollback();
          result({
            message: "Error while updating details",
            code: 2
          }, null);
          return;
        }
      }
    }
    await connection.commit();

    var customer = await sql.query("SELECT BIN_TO_UUID(CustomerId) As CustomerId,BIN_TO_UUID(UserId) As UserId,FirstName,MiddleName,LastName,ContactPhone,ContactMobile,ContactEmail,IsActive, CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM customer WHERE CustomerId = UUID_TO_BIN(?)", customerId);


    var customerAddress = await sql.query("SELECT BIN_TO_UUID(ca.CustomerAddressId) AS CustomerAddressId, BIN_TO_UUID(ca.AddressTypeId) As AddressTypeId,ca.AddressTypeAnnotation,ca.ContactPhone,ca.CotactName, BIN_TO_UUID(ca.CustomerId) As CustomerId,ca.Address1,ca.Address2,ca.CountryId,ca.StateId,ca.CityId,ca.AreaId,ca.IsActive,ca.Landmark,ca.Postcode, ca.IsDefault, a.AddressType,ca.AreaDescription,ci.City FROM customerAddress ca inner join AddressType a  on ca.AddressTypeId = a.AddressTypeId inner join cities ci on ca.CityId = ci.CityId WHERE ca.CustomerId = UUID_TO_BIN(?) ", customerId);

    if (!customerAddress[0][0]) {
      await connection.rollback();
      result({
        message: "Error while updating details",
        code: 2
      }, null);
      return;
    }
    await connection.commit();
    result(null, {
      message: "Customer Address added successfully",
      code: 0,
      customer: customer[0][0],
      customerAddress: customerAddress[0],
    });
  } catch (err) {
    console.log(err);
    await connection.rollback();
    result({
      message: "Something went wrong",
      code: 2
    }, null);
    return;
  } finally {
    await connection.release();
  }
}

CustomerAddress.getAllCities = async (req, result) => {
  var getAllCitites = await sql.query("SELECT CityId,City,StateId FROM Cities where CityId = 337");
  if (!getAllCitites[0]) {
    console.log("error: ", getAllCitites[0]);
    result(null, {
      code: 1,
      message: "Failed",
      cities: getAllCitites[0]
    });
    return;
  }

  console.log("Cities: ", getAllCitites[0]);
  result(null, {
    code: 0,
    message: "success",
    cities: getAllCitites[0]
  });
};

CustomerAddress.checkPincode = async (pincode, result) => {
  var pincodeDetails = await sql.query("SELECT WarehouseId from warehousepincodefences where DeliveryPinCode = ?", pincode);

  if (!pincodeDetails[0][0]) {
    result(null, {
      message: "eSatvik services are not available at this location yet.",
      code: 3
    });
    return;
  } else {
    result(null, {
      message: "Success",
      code: 0
    });
    return;
  }
}

module.exports = CustomerAddress;
