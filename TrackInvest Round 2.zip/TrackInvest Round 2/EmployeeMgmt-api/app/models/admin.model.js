const sql = require("./db.js");
const e = require("express");
const https = require('https');
var constants = require('../lib/constants');
var order = require('./order.model');

const Admin = function (admin) {
};

Admin.getAllPendingOrders = async (deliveryDate, result) => {
    try {
        var order
        if (deliveryDate != null && deliveryDate != "null") {
            var date = new Date(deliveryDate);
            date.setHours(0, 0, 0, 0);
        }
        if (deliveryDate == null || deliveryDate == "null") {
            order = await sql.query("select BIN_TO_UUID( om.orderId) as OrderId,Count(oi.OrderItemId) as OrderItemCount,om.OrderNumber,concat(c.FirstName,' ',c.LastName) as CustomerName,ca.Postcode,asm.StatusDescription as PaymentStatus,oi.DeliveryDate from ordermaster om, orderItem oi,customer c,customeraddress ca, appstatusmaster asm where oi.OrderId = om.OrderId and om.CustomerId = c.CustomerId and om.PaymentStatusId = asm.AppStatusMasterId  and om.CustomerAddressId = ca.CustomerAddressId and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f1f-cba8-bd6b-c49deda8deaf') group by  om.orderId order by DeliveryDate");
        } else {
            order = await sql.query("select BIN_TO_UUID( om.orderId) as OrderId,Count(oi.OrderItemId) as OrderItemCount,om.OrderNumber,concat(c.FirstName,' ',c.LastName) as CustomerName,ca.Postcode,asm.StatusDescription as PaymentStatus,oi.DeliveryDate from ordermaster om, orderItem oi,customer c,customeraddress ca, appstatusmaster asm where oi.OrderId = om.OrderId and oi.DeliveryDate = date(?) and om.CustomerId = c.CustomerId and om.PaymentStatusId = asm.AppStatusMasterId  and om.CustomerAddressId = ca.CustomerAddressId and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f1f-cba8-bd6b-c49deda8deaf') group by  om.orderId order by DeliveryDate", date);
        }
        result(null, { code: 0, message: "Success", orders: order[0] });
    } catch (err) {
        console.log(err);
        result(null, { code: 2, message: "Something went wrong" })
    }

}

Admin.getAllDelieveryFilter = async (result) => {
    try {
        var deliveryDateResponse = await sql.query("Select distinct(DeliveryDate) from orderitem where OrderItemStatusId = UUID_TO_BIN('11eb2987-5f1f-cba8-bd6b-c49deda8deaf') or OrderItemStatusId = UUID_TO_BIN('31d17dbd-353f-11eb-8bea-c85b76c8d1d8') order by DeliveryDate desc");


        var pincodeResponse = await sql.query("Select distinct(BIN_TO_UUID(om.CustomerAddressId)) as CustomerAddressId, ca.postCode as pincode from ordermaster om,customerAddress ca where om.CustomerAddressId = ca.CustomerAddressId and (om.OrderStatusId = UUID_TO_BIN('11eb298e-c1f2-ce2e-bd6b-c49deda8deaf') or om.OrderStatusId = UUID_TO_BIN('11eb298e-c1f6-bcf5-bd6b-c49deda8deaf'))");

        var customerNameResponse = await sql.query("Select distinct(BIN_TO_UUID(om.customerId)) as CustomerId, concat(c.firstName,' ' ,c.LastName) as CustomerName from ordermaster om,customer c where om.CustomerId = c.CustomerId and (om.OrderStatusId = UUID_TO_BIN('11eb298e-c1f2-ce2e-bd6b-c49deda8deaf') or om.OrderStatusId = UUID_TO_BIN('11eb298e-c1f6-bcf5-bd6b-c49deda8deaf'))");

        var deliveryPersonResponse = await sql.query("Select distinct(BIN_TO_UUID(om.DeliveryPersonId)) as DeliveryPersonId,concat(e.FirstName,' ',e.LastName) as EmployeeName from orderitem om, Employee e where om.DeliveryPersonId = e.UserId and (OrderItemStatusId = UUID_TO_BIN('11eb2987-5f1f-cba8-bd6b-c49deda8deaf') or OrderItemStatusId = UUID_TO_BIN('31d17dbd-353f-11eb-8bea-c85b76c8d1d8')) and om.DeliveryPersonId is not null");
        result(null, {
            code: 0,
            message: "Success",
            deliveryDate: deliveryDateResponse[0],
            pincode: pincodeResponse[0],
            customerName: customerNameResponse[0],
            deliveryPerson: deliveryPersonResponse[0],
        });
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Error" });
    }
}

Admin.getOrdersByFilter = async (req, result) => {
    try {

        console.log(req.body);
        var deliveryDate = req.body.date;
        var pincode = req.body.pincode;
        var deliveryBoy = req.body.deliveryPerson;
        var customerName = req.body.customerName;
        var formatedDate = [];
        if (deliveryDate != null && deliveryDate.length > 0) {
            for (i in deliveryDate) {
                var selectedDate = new Date(deliveryDate[i]);
                selectedDate.setHours(0, 0, 0, 0);
                formatedDate.push(selectedDate);
            }
        }
        //first customerid
        //Second pincode
        //Third Delivery boy
        //Fourth Delivery Date;
        if (formatedDate.length == 0) {
            formatedDate = null;
        }
        console.log(formatedDate);
        console.log(pincode);
        console.log(deliveryBoy);
        console.log(customerName);

        var newDate = deliveryDate == null ? null : JSON.stringify(deliveryDate);
        var newCustomerName = customerName == null ? null : JSON.stringify(customerName);
        var newPincode = pincode == null ? null : JSON.stringify(pincode);
        var newDeliveryBoy = deliveryBoy == null ? null : JSON.stringify(deliveryBoy);


        console.log(newDate);

        const order = await sql.query("Call GetOrdersFilterData_sp(?,?,?,?)", [newCustomerName, newPincode, newDeliveryBoy, newDate]);
        result(null, { code: 0, message: "Success", orders: order[0][0] });
    } catch (err) {
        console.log(err);
        result(null, { code: 2, message: "Something went wrong" })
    }
}

Admin.assignDeliveryPerson = async (req, result) => {
    try {
        var deliveryPersonId = req.body.deliveryPersonId;
        var orders = req.body.orders;
        var UserId = req.body.userId;
        var date = new Date();
        date.setHours(0, 0, 0, 0);

        if (orders != null && orders.length > 0) {
            for (i in orders) {
                var deliveryPersonResponse = await sql.query("update orderitem set DeliveryPersonId = UUID_TO_BIN(?),OrderItemStatusId = UUID_TO_BIN(?), UpdatedDate = ?,UpdatedBy = UUID_TO_BIN(?) where orderId = UUID_TO_BIN(?) and DeliveryDate = (?) and (OrderItemStatusId = UUID_TO_BIN(?) or OrderItemStatusId = UUID_TO_BIN(?))", [deliveryPersonId, constants.ORDER_ITEM_OUT_FOR_DEL, new Date(), UserId, orders[i], date, constants.ORDER_ITEM_OUT_FOR_DEL, constants.DELIVERY_PENDING])

                if (!deliveryPersonResponse[0][0]) {
                    var orderItemRespose = await sql.query("select om.OrderNumber,BIN_TO_UUID(om.PaymentStatusId) as PaymentStatusId,oi.ProductId,oi.OrderQty, oi.UnitPrice,p.productName,om.InvoiceAmount,ca.ContactPhone as CustomerMobile,concat(e.FirstName,' ' ,e.LastName) as EmployeeName, e.MobilePhoneNo from ordermaster om,orderitem oi,product p,employee e,customeraddress ca where oi.OrderId = om.orderId and om.CustomerAddressId = ca.CustomerAddressId and oi.ProductId = p.ProductId and oi.DeliveryPersonId = e.UserId and oi.OrderId =UUID_TO_BIN(?)", orders[i]);

                    var deliveryCharges = await sql.query("Select SUM(DeliveryCharges) as DeliveryCharges from orderdeliveries where orderId = UUID_TO_BIN(?) and DeliveryDate = (?)", [orders[i], date]);
                    var charges = 0;
                    if (deliveryCharges[0][0] && deliveryCharges[0][0].DeliveryCharges) {
                        charges = deliveryCharges[0][0].DeliveryCharges
                    }

                    var totalDeliveryCharge = 0.0;
                    if (orderItemRespose[0][0]) {
                        var orderItem = orderItemRespose[0];
                        for (i in orderItem) {
                            totalDeliveryCharge = totalDeliveryCharge + (orderItem[i].OrderQty * orderItem[i].UnitPrice);
                        }

                        totalDeliveryCharge = totalDeliveryCharge + charges;
                        var isOneItem;
                        if (orderItemRespose[0].length == 1) {
                            //send message for single product;
                            isOneItem = true;
                        } else {
                            //send message for mulitple product;
                            isOneItem = false;
                        }
                        var delType;
                        if (orderItemRespose[0][0].PaymentStatusId == constants.PAYMENT_PAID) {
                            if (isOneItem)
                                delType = 1;
                            else
                                delType = 2

                        } else if (orderItemRespose[0][0].PaymentStatusId == constants.PAYMENT_COD) {
                            if (isOneItem)
                                delType = 5;
                            else
                                delType = 6;
                        } else {

                            if (isOneItem)
                                delType = 3;
                            else
                                delType = 4;
                        }

                        var mobileNumber = orderItemRespose[0][0].CustomerMobile;
                        var orderNumber = orderItemRespose[0][0].OrderNumber;
                        var prdName = orderItemRespose[0][0].productName;
                        var count = orderItemRespose[0].length - 1;
                        var deliveryPersonName = orderItemRespose[0][0].EmployeeName;
                        var deliveryPersonMobile = orderItemRespose[0][0].MobilePhoneNo;
                        var amount = totalDeliveryCharge;
                        if (constants.SEND_SMS)
                            sendOutForDelMessage(delType, mobileNumber, orderNumber, prdName, count, deliveryPersonName, deliveryPersonMobile, amount);
                    }

                }

            }
        }
        result(null, { code: 0, message: "Success" });
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Something went wrong" })
    }
}


Admin.adminEditOrder = async (req, result) => {

    const deliveryDate = req.body.deliveryDate;
    const isCancel = req.body.isCancel;
    const orderItemId = req.body.orderItemId;
    const orderId = req.body.orderId;
    const userId = req.body.userId;
    var date = new Date(deliveryDate);
    date.setHours(0, 0, 0, 0);
    if (isCancel) {
        const editOrder = await sql.query("Update orderItem set OrderItemStatusId = UUID_TO_BIN(?), DeliveryPersonId = NULL, UpdatedDate = ?,UpdatedBy = UUID_TO_BIN(?) where orderId = UUID_TO_BIN(?) and OrderItemId = UUID_TO_BIN(?)", [constants.ORDER_ITEM_CANCEL, new Date(), userId, orderId, orderItemId]);
    } else {
        const editOrder = await sql.query("Update orderItem set DeliveryDate = ?,UpdatedDate = ?,UpdatedBy = UUID_TO_BIN(?) where orderId = UUID_TO_BIN(?) and OrderItemId = UUID_TO_BIN(?)", [date, new Date(), userId, orderId, orderItemId]);
    }

    var orderMasterStatus = await sql.query("Select TblTotalOrders.TotalOrders, TblCanceledOrders.CanceledOrders,TblDeliveredOrders.DeliveredOrders From (select  om.OrderID, count(oi.OrderId) AS TotalOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) group by oi.OrderId) TblTotalOrders Left join  (select om.OrderID, count(oi.OrderId) AS CanceledOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f23-7e32-bd6b-c49deda8deaf') group by oi.OrderId) AS TblCanceledOrders ON TblTotalOrders.OrderId = TblCanceledOrders.OrderId Left Join  (select om.OrderID, count(oi.OrderId) AS DeliveredOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f22-6c45-bd6b-c49deda8deaf') group by oi.OrderId) AS TblDeliveredOrders ON TblTotalOrders.OrderId = TblDeliveredOrders.OrderId", [orderId, orderId, orderId]);

    if (orderMasterStatus[0][0]) {
        var TotalOrders = orderMasterStatus[0][0].TotalOrders == null ? 0 : orderMasterStatus[0][0].TotalOrders;
        var CanceledOrders = orderMasterStatus[0][0].CanceledOrders == null ? 0 : orderMasterStatus[0][0].CanceledOrders;
        var DeliveredOrders = orderMasterStatus[0][0].DeliveredOrders == null ? 0 : orderMasterStatus[0][0].DeliveredOrders;

        var status = constants.ORDER_PENDING;

        var orders = TotalOrders - CanceledOrders;
        if (orders == 0) {
            status = constants.ORDER_CANCELLED;
        } else if (DeliveredOrders == 0) {
            status = constants.ORDER_PENDING;
        } else if (orders == DeliveredOrders) {
            status = constants.ORDER_DELIVERED
        } else if (DeliveredOrders > 0 && DeliveredOrders < TotalOrders) {
            status = constants.ORDER_PD;
        }
    }

    var orderStatus = await sql.query("UPDATE ORDERMASTER SET OrderStatusId = UUID_TO_BIN(?),UpdatedDate=(?),updatedBy=UUID_TO_BIN(?) where orderId = UUID_TO_BIN(?)", [status, new Date(), userId, orderId]);

    order.getOrderItems(orderId, result);
}

async function sendOutForDelMessage(delType, mobileNumber, orderNumber, productName, count, deliveryPersonName, deliveryPersonMobile, price) {
    var TemplateName = getTemplateNameForOrderPlace(delType);
    const data = getBodyParametersForOrderPlace(delType, mobileNumber, TemplateName, orderNumber, productName, count, deliveryPersonName, deliveryPersonMobile, price);

    const options = {
        host: '2factor.in',
        path: '/API/V1/9dd7b6d6-2713-11eb-83d4-0200cd936042/ADDON_SERVICES/SEND/TSMS',
        method: 'POST',
        port: null,
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    }

    const req = https.request(options, (res) => {
        let data = '';

        console.log('Status Code:', res.statusCode);

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Body: ', JSON.parse(data));
        });

    }).on("error", (err) => {
        console.log("Error: ", err.message);
    });

    req.write(data);
    req.end();

}

function getTemplateNameForOrderPlace(typeId) {
    switch (typeId) {
        case 1:
            return 'OFD_PN_SING';
        case 2:
            return 'OFD_PN_ONE';
        case 3:
            return 'OFD_PL_SING';
        case 4: return 'OFD_PL_MUL';
        case 5: return 'OFD_COD_SING';
        case 6: return 'OFD_COD_MUL';
    }
}

function getBodyParametersForOrderPlace(delType, mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile, price) {
    switch (delType) {
        case 1: return getBodySingleProductPaid(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile);

        case 2: return getBodyMultipleProductPaid(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile);

        case 3: return getBodySingleProductPayLater(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile);

        case 4: return getBodyMultipleProductPaidPayLater(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile);

        case 5: return getBodySingleProductCOD(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile, price);

        case 6: return getBodyMultipleProductCOD(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile, price);
    }
}

function getBodySingleProductPaid(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR4': deliveryPersonName,//deliveryPersonName
        'VAR5': deliveryPersonMobile//deliveryPersonMobile
    });
    console.log(data);
    return data;
}

function getBodyMultipleProductPaid(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': count,//Item Count
        'VAR4': deliveryPersonName,//deliveryPersonName
        'VAR5': deliveryPersonMobile//deliveryPersonMobile
    });
    console.log(data);
    return data;
}

function getBodySingleProductPayLater(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': deliveryPersonName,//deliveryPersonName
        'VAR4': deliveryPersonMobile//deliveryPersonMobile
    });
    console.log(data);
    return data;
}

function getBodyMultipleProductPaidPayLater(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': count,//Item Count
        'VAR4': deliveryPersonName,//deliveryPersonName
        'VAR5': deliveryPersonMobile//deliveryPersonMobile
    });
    console.log(data);
    return data;
}

function getBodySingleProductCOD(mobileNumber, TemplateName, orderNumber, englishName, deliveryPersonName, deliveryPersonMobile, price) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': deliveryPersonName,//deliveryPersonName
        'VAR4': deliveryPersonMobile,//deliveryPersonMobile
        'VAR5': price//Amount
    });
    console.log(data);
    return data;
}

function getBodyMultipleProductCOD(mobileNumber, TemplateName, orderNumber, englishName, count, deliveryPersonName, deliveryPersonMobile, price) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': count,//Item Count
        'VAR4': deliveryPersonName,//deliveryPersonName
        'VAR5': deliveryPersonMobile,//deliveryPersonMobile
        'VAR6': price
    });

    console.log(data);
    return data;
}
module.exports = Admin;