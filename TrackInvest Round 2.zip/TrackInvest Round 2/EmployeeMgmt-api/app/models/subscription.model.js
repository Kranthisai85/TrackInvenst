const sql = require("./db.js");
const Product = require("./product.model.js");
const { end } = require("./db.js");
const e = require("express");
const { connect } = require("mysql2");
const { DATETIME } = require("mysql2/lib/constants/types");
const moment = require('moment');

// constructor
// Create a Subscription
const Subscription = function (subscription) {
    this.customerId = subscription.customerId,
        this.subscriptionTypeId = subscription.subscriptionTypeId,
        this.products = subscription.products,
        this.noOfDeliveries = subscription.noOfDeliveries,
        this.amount = subscription.amount,
        this.startDate = subscription.startDate,
        this.endDate = subscription.endDate,
        this.orderDate = subscription.orderDate,
        this.product = subscription.product,
        this.isCancel = subscription.isCancel,
        this.customerAddressId = subscription.addressId,
        this.subscriptionEditDate = subscription.subscriptionEditDate,
        this.subscriptionId = subscription.subscriptionId,
        this.initialDeliveries = subscription.initialDeliveries

};

Subscription.create = async (subscription, result) => {
    const connection = await sql.getConnection();
    try {

        await connection.beginTransaction();

        // var orderResponse = await connection.query("INSERT INTO ORDERMASTER SET CustomerId = ?,OrderDate = ? ", [subscription.customerId, subscription.orderDate]);

        // if (!orderResponse[0]) {
        //     connection.rollback();
        //     result(null, {
        //         message: "Error While creating Order",
        //         code: 2,
        //     });
        //     return;
        // }

        // console.log("created Order: ", { orderId: orderResponse[0].insertId });
        // var orderId = orderResponse[0].insertId;
        if (subscription.products) {
            for (i in subscription.products) {
                var product = subscription.products[i];
                // var orderItemResponse = await connection.query("INSERT INTO ORDERITEM SET OrderId = ?, ProductId = ?, OrderQty = ?, UnitPrice = ?, InitialDeliveries = ?,TotalDeliveries = ?, PendingDeliveries = ? ", [orderId, product.productId, product.quantity, product.price, subscription.initialDeliveries, subscription.noOfDeliveries, subscription.noOfDeliveries]);

                // if (!orderItemResponse[0]) {
                //     connection.rollback();
                //     result(null, {
                //         message: "Error While creating Order",
                //         code: 2,
                //     });
                //     return;
                // }

                // var orderItemId = orderItemResponse[0].insertId;

                //const startDate = new Date(subscription.startDate);
                //console.log("StartDate  " + startDate);
                var endDate = null;
                if (subscription.endDate != null) {
                    endDate = new Date(subscription.endDate);
                }
                // if (subscription.endDate != null)
                //     endDate = new Date(subscription.endDate);

                // var noOfDeliveries = subscription.noOfDeliveries;

                // switch (subscription.subscriptionTypeId) {
                //     case 1://day
                //         endDate.setDate(startDate.getDate() + (noOfDeliveries - 1));
                //         break;
                //     case 2://week
                //         endDate.setDate(startDate.getDate() + (noOfDeliveries - 1) * 7);
                //         break;
                //     case 3://forthnight
                //         endDate.setDate(startDate.getDate() + (noOfDeliveries - 1) * 15);
                //         break;
                //     case 4://month
                //         endDate.setMonth(startDate.getMonth() + (noOfDeliveries - 1));
                //         break;
                // }
                //console.log("EndDate  " + endDate);

                var subStartDate = new Date(subscription.startDate);
                var subscriptionResponse = await connection.query("INSERT INTO SUBSCRIPTION SET subscriptionTypeId = ?,StartDateTime = ?,EndDateTime = ?,CustomerId = ?, CustomerAddressId = ?, InitialDeliveries = ?,TotalDeliveries = ?, PendingDeliveries = ?, notes = ?, CreatedDate = ?", [subscription.subscriptionTypeId, subStartDate, endDate, subscription.customerId, subscription.customerAddressId, subscription.initialDeliveries, subscription.noOfDeliveries, subscription.noOfDeliveries, "",
                new Date()]);

                if (!subscriptionResponse[0]) {
                    connection.rollback();
                    result(null, {
                        message: "Error While creating Order",
                        code: 2,
                    });
                    return;
                }

                var subscriptionId = subscriptionResponse[0].insertId;
                //Add record in subscriptionDeliveryScheduletable

                var productId = product.productId;
                var qty = product.subscriptionQuantity;
                var subscriptionItemResponse = await connection.query("INSERT INTO SUBSCRIPTIONITEM SET SubscriptionId = ?,ProductId = ?,Quantity = ?,Notes = ? ", [subscriptionId,
                    productId, qty, ""]);

                if (!subscriptionItemResponse[0]) {
                    connection.rollback();
                    result(null, {
                        message: "Error While creating Order",
                        code: 2,
                    });
                    return;
                }

                var scheduleStartDate = new Date(subscription.startDate);
                // for (i = 0; i < subscription.noOfDeliveries; i++) {

                //     var subscriptionDeliveriesResponse = await connection.query("INSERT INTO  subscriptiondeliveries SET subscriptionId = ?, DeliveryDateTime = ?,  DeliveryStatusId = ?, Quantity = ?", [subscriptionId, scheduleStartDate, 1, product.quantity]);

                //     switch (subscription.subscriptionTypeId) {
                //         case 1://day
                //             scheduleStartDate.setDate(scheduleStartDate.getDate() + 1);
                //             break;
                //         case 2://week
                //             scheduleStartDate.setDate(scheduleStartDate.getDate() + 7);
                //             break;
                //         case 3://forthnight
                //             scheduleStartDate.setDate(scheduleStartDate.getDate() + 15);
                //             break;
                //         case 4://month
                //             scheduleStartDate.setMonth(scheduleStartDate.getMonth() + 1);
                //             break;

                //     }
                //}

                var subscriptionDeliveriesResponse = await connection.query("INSERT INTO  subscriptiondeliveries SET subscriptionId = ?, DeliveryDateTime = ?,  DeliveryStatusId = ?, Quantity = ?", [subscriptionId, scheduleStartDate, 1, qty]);


                if (!subscriptionDeliveriesResponse[0]) {
                    connection.rollback();
                    result(null, {
                        message: "Error While creating Order",
                        code: 2,
                    });
                    return;
                }

            }

            connection.commit();
            result(null, {
                message: "Subscription Created.",
                code: 0,
            });

        }
    } catch (err) {
        console.log(err);
        await connection.rollback();
        result("Error", null);
    }

}

Subscription.findById = async (customerId, customerAddressId, subscriptionTypeId, result) => {
    var today = new moment().format('YYYY-MM-DD');

    //DATE_FORMAT(om.OrderDate, '%d/%m/%Y') AS Orderdate
    //DATE_FORMAT(s.StartDateTime, '%d/%m/%Y') AS StartDate
    //DATE_FORMAT(s.EndDateTime, '%d/%m/%Y') AS EndDate
    // var response = await sql.query("SELECT om.CustomerId,om.OrderId, om.OrderDate AS Ordatedate,oi.OrderItemId, oi.ProductId, oi.OrderQty,oi.UnitPrice,oi.TotalDeliveries,oi.PendingDeliveries,(oi.OrderQty * oi.UnitPrice * oi.TotalDeliveries) TotalAmount,(oi.OrderQty * oi.UnitPrice * oi.PendingDeliveries) RemainingAmount,oi.InitialDeliveries,s.SubscriptionId, s.SubscriptionTypeId, s.StartDateTime AS StartDate, s.EndDateTime AS EndDate, stm.BasketName, p.ProductName, p.ProductPrice, pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, (p.ProductPrice*oi.OrderQty) ItemTotal, c.FirstName, c.LastName FROM ordermaster om inner join orderitem oi on om.orderid = oi.orderid inner join subscription s on s.orderitemid = oi.orderitemid inner join subscripbaskets stm on stm.SubscriptionBasketId = s.SubscriptionTypeId  inner join product p on p.ProductId = oi.ProductId  inner join productimage pi on pi.ProductId = p.productId inner join customer c on c.CustomerId = om.CustomerId Where s.isCanceled = 0 AND c.CustomerId = ? AND s.EndDateTime > ?", [customerId, today]);
    var response;
    if (subscriptionTypeId == 0) {
        //If subscriptionTypeId is zero get all subscription for that user for that address
        response = await sql.query("SELECT s.CustomerId,si.SubscriptionItemId, si.ProductId, si.Quantity,p.ProductPrice,s.TotalDeliveries,s.PendingDeliveries,(si.Quantity * p.ProductPrice * s.TotalDeliveries) TotalAmount,(si.Quantity *p.ProductPrice * s.PendingDeliveries) RemainingAmount,s.InitialDeliveries,s.SubscriptionId, s.SubscriptionTypeId, s.StartDateTime AS StartDate, s.EndDateTime AS EndDate, stm.BasketName, p.ProductName, p.ProductPrice, pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, (p.ProductPrice*si.Quantity) ItemTotal, c.FirstName, c.LastName FROM subscription s inner join subscripbaskets stm on stm.SubscriptionBasketId = s.SubscriptionTypeId  inner join subscriptionitem si on s.subscriptionId = si.subscriptionId inner join  product p on p.ProductId = si.ProductId  inner join productimage pi on pi.ProductId = p.productId inner join customer c on c.CustomerId = s.CustomerId Where s.CancelationReasonId IS NULL AND si.CancelationReasonId IS NULL AND c.CustomerId = ? AND s.CustomerAddressId = ? AND (s.EndDateTime is null or s.EndDateTime > ?)", [customerId, customerAddressId, subscriptionTypeId, today]);
    } else {
        response = await sql.query("SELECT s.CustomerId,si.SubscriptionItemId, si.ProductId, si.Quantity,p.ProductPrice,s.TotalDeliveries,s.PendingDeliveries,(si.Quantity * p.ProductPrice * s.TotalDeliveries) TotalAmount,(si.Quantity *p.ProductPrice * s.PendingDeliveries) RemainingAmount,s.InitialDeliveries,s.SubscriptionId, s.SubscriptionTypeId, s.StartDateTime AS StartDate, s.EndDateTime AS EndDate, stm.BasketName, p.ProductName, p.ProductPrice, pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, (p.ProductPrice*si.Quantity) ItemTotal, c.FirstName, c.LastName FROM subscription s inner join subscripbaskets stm on stm.SubscriptionBasketId = s.SubscriptionTypeId  inner join subscriptionitem si on s.subscriptionId = si.subscriptionId inner join  product p on p.ProductId = si.ProductId  inner join productimage pi on pi.ProductId = p.productId inner join customer c on c.CustomerId = s.CustomerId Where s.CancelationReasonId IS NULL AND si.CancelationReasonId IS NULL AND c.CustomerId = ? AND s.CustomerAddressId = ? AND s.SubscriptionTypeId = ? AND (s.EndDateTime is null or s.EndDateTime > ?)", [customerId, customerAddressId, subscriptionTypeId, today]);
    }
    if (response[0].length == 0) {
        console.log("Subscription Product: ", response[0]);
        result(null, { code: 2, message: "No subscription available" });
        return;
    }

    var subscriptionData = response[0];
    for (i in subscriptionData) {
        //DATE_FORMAT(DeliveryDateTime, '%d/%m/%Y') AS DeliveryDate
        var sds = await sql.query("SELECT SubscriptionDeliveryId,DeliveryDateTime,DeliveryStatusId,Quantity,SubscriptionId FROM subscriptiondeliveries WHERE SubscriptionId = " + subscriptionData[i].SubscriptionId);

        var subscriptionSchedules = sds[0];
        var pastSchedules = [];
        var upComingSchedules = [];
        //var today = new moment().format('DD/MM/YYYY');
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        for (j in subscriptionSchedules) {

            var subSchedule = subscriptionSchedules[j];

            var deliveryDateTime = new Date(subSchedule.DeliveryDateTime);

            subscriptionSchedules[j].DeliveryDateTime = moment.utc(deliveryDateTime).local().format();
            var date = new Date(subscriptionSchedules[j].DeliveryDateTime);


            if (date < today) {
                pastSchedules.push(subSchedule);
            } else if (date > today && subSchedule.DeliveryStatusId == 1) {
                upComingSchedules.push(subSchedule);
            } else if (subSchedule.DeliveryStatusId == 1) {
                upComingSchedules.push(subSchedule);
            } else if (subSchedule.DeliveryStatusId == 2 || subSchedule.DeliveryStatusId == 3) {
                pastSchedules.push(subSchedule);
            }
        }

        subscriptionData[i].PastSchedules = pastSchedules;
        subscriptionData[i].UpcomingSchedules = upComingSchedules;
        subscriptionData[i].RemainingDeliveries = upComingSchedules.length;
    }
    console.log(subscriptionData);
    result(null, { code: 0, subscriptionList: subscriptionData });
};

Subscription.getAll = result => {

};

Subscription.updateById = async (subscriptionId, editSubscription, result) => {
    const connection = await sql.getConnection();
    try {
        await connection.beginTransaction();
        if (!editSubscription) {
        } else {
            if (editSubscription.IsCancel) {
                //As user cancels this delivery.
                var response = await connection.query("Update subscriptiondeliveries set DeliveryStatusId = 4 where SubscriptionDeliveryId = ?", editSubscription.SubscriptionDeliveryId);

                if (!response[0]) {
                    connection.rollback();
                    console.log("Edit Subscription: ", response[0]);
                    result(null, { message: "error while editing subscription", code: 5 });
                    return;
                }

                var endDate = new Date(editSubscription.EndDate)
                switch (editSubscription.SubscriptionTypeId) {
                    case 1://day
                        endDate.setDate(endDate.getDate() + 1);
                        break;
                    case 2://week
                        endDate.setDate(endDate.getDate() + 7);
                        break;
                    case 3://forthnight
                        endDate.setDate(endDate.getDate() + 15);
                        break;
                    case 4://month
                        endDate.setMonth(endDate.getMonth() + 1);
                        break;
                }


                var updateSubscritionResponse = await connection.query("Update subscription set EndDateTime = ? Where SubscriptionId = ?", [endDate, subscriptionId]);
                if (!updateSubscritionResponse[0]) {
                    connection.rollback();
                    console.log("Edit Subscription: ", response[0]);
                    result(null, { message: "error while editing subscription", code: 5 });
                    return;
                }

                var scheduleResponse = await connection.query("INSERT INTO  subscriptiondeliveries SET subscriptionId = ?, DeliveryDateTime = ?, DeliveryStatusId = ?, Quantity = ?", [subscriptionId, endDate, 1, editSubscription.DeliveryQty]);

                if (!scheduleResponse[0]) {
                    connection.rollback();
                    console.log("Edit Subscription: ", response[0]);
                    result(null, { message: "error while editing subscription", code: 5 });
                    return;
                }
                connection.commit();
                //result(result(null, { message: "Subscription Edited successfully", code: 5 }));
            } else {
                var editSubscriptionResponse = await sql.query("UPDATE subscriptiondeliveries Set  Quantity = ? where SubscriptionDeliveryId = ?", [editSubscription.DeliveryQty, editSubscription.SubscriptionDeliveryId])

                if (!editSubscriptionResponse[0]) {
                    console.log("Edit Subscription: ", response[0]);
                    result(null, { message: "error while editing subscription", code: 5 });
                    return;
                }

                console.log("Edit Subscription: ", editSubscriptionResponse[0]);
                connection.commit();
            }

            // var response = await connection.query("SELECT om.CustomerId,om.OrderId, om.OrderDate AS Ordatedate, (oi.OrderQty * oi.UnitPrice * oi.TotalDeliveries) TotalAmount, oi.ProductId, oi.OrderQty,s.SubscriptionId, s.SubscriptionTypeId, s.StartDateTime AS StartDate, s.EndDateTime AS EndDate, stm.BasketName, p.ProductName, p.ProductPrice, pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, (p.ProductPrice*oi.OrderQty) ItemTotal, c.FirstName, c.LastName FROM ordermaster om inner join orderitem oi on om.orderid = oi.orderid inner join subscription s on s.orderitemid = oi.orderitemid inner join subscripbaskets stm on stm.SubscriptionTypeId = s.SubscriptionBasketId  inner join product p on p.ProductId = oi.ProductId  inner join productimage pi on pi.ProductId = p.productId inner join customer c on c.CustomerId = om.CustomerId Where s.SubscriptionId = ?", subscriptionId)


            var response = await connection.query("SELECT s.CustomerId, si.ProductId, si.Quantity,p.ProductPrice,s.TotalDeliveries,s.PendingDeliveries,(si.Quantity * p.ProductPrice * s.TotalDeliveries) TotalAmount,(si.Quantity *p.ProductPrice * s.PendingDeliveries) RemainingAmount,s.InitialDeliveries,s.SubscriptionId, s.SubscriptionTypeId, s.StartDateTime AS StartDate, s.EndDateTime AS EndDate, stm.BasketName, p.ProductName, p.ProductPrice, pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath, (p.ProductPrice*si.Quantity) ItemTotal, c.FirstName, c.LastName FROM subscription s inner join subscripbaskets stm on stm.SubscriptionBasketId = s.SubscriptionTypeId  inner join subscriptionitem si on s.subscriptionId = si.subscriptionId inner join  product p on p.ProductId = si.ProductId  inner join productimage pi on pi.ProductId = p.productId inner join customer c on c.CustomerId = s.CustomerId Where  s.SubscriptionId = ?", subscriptionId);

            if (response[0].length == 0) {
                console.log("Subscription Product: ", response[0]);
                result(null, { code: 2, message: "No subscription available" });
                return;
            }

            var subscriptionData = response[0];
            var sds = await sql.query("SELECT SubscriptionDeliveryId,DeliveryDateTime,DeliveryStatusId,Quantity,SubscriptionId FROM subscriptiondeliveries WHERE SubscriptionId = " + subscriptionData[0].SubscriptionId);

            var subscriptionSchedules = sds[0];
            var pastSchedules = [];
            var upComingSchedules = [];
            //var today = new moment().format('DD/MM/YYYY');
            var today = new Date();
            today.setHours(0, 0, 0, 0);
            for (j in subscriptionSchedules) {

                var subSchedule = subscriptionSchedules[j];

                var deliveryDateTime = new Date(subSchedule.DeliveryDateTime);

                subscriptionSchedules[j].DeliveryDateTime = moment.utc(deliveryDateTime).local().format();
                var date = new Date(subscriptionSchedules[j].DeliveryDateTime);


                if (date < today) {
                    pastSchedules.push(subSchedule);
                } else if (date > today && subSchedule.DeliveryStatusId == 1) {
                    upComingSchedules.push(subSchedule);
                } else if (subSchedule.DeliveryStatusId == 1) {
                    upComingSchedules.push(subSchedule);
                } else if (subSchedule.DeliveryStatusId == 2 || subSchedule.DeliveryStatusId == 3) {
                    pastSchedules.push(subSchedule);
                }
            }

            subscriptionData[0].PastSchedules = pastSchedules;
            subscriptionData[0].UpcomingSchedules = upComingSchedules;
            subscriptionData[0].RemainingDeliveries = upComingSchedules.length;

            var responseToSend = subscriptionData[0];
            console.log(responseToSend);

            result(null, { code: 0, subsciprtion: responseToSend });
        }
    } catch (error) {
        console.log(error);
        await connection.rollback();
        result(null, { message: "Something went wrong", code: 2 });
    }

};

Subscription.remove = async (subscriptionId, result) => {

};

Subscription.removeAll = result => {
    sql.query("DELETE FROM Subscription", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }

        console.log(`deleted ${res.affectedRows} subcription`);
        result(null, res);
    });
};

Subscription.getSubscritionDetails = async (subscriptionId, result) => {

    var subsciptionDetailsResponse = await sql.query("SELECT sds.DeliveryScheduleId, sds.SubscriptionId,sds.DeliveryNotes,sds.DeliveryDateTime,ds.StatusDescription FROM subscriptiondeliveryschedule sds inner join deliverystatus ds on sds.DeliveryStatusId = ds.DeliveryStatusId where SubscriptionId = ? ", subscriptionId);

    if (!subsciptionDetailsResponse[0][0]) {
        console.log("Subscription Product: ", subsciptionDetailsResponse[0]);
        result(null, {
            message: "No data found",
            code: 6
        });
        return;
    }
    console.log("Subscription Product: ", subsciptionDetailsResponse[0]);
    result(null, subsciptionDetailsResponse[0]);
};


Subscription.cancelSubscription = async (editSubscription, result) => {

    var subscriptionItemResponse = await sql.query("Update SubscriptionItem SET CancelationReasonId = ? Where subscriptionId = ? AND SubscriptionItemId = ?", [editSubscription.cancelationReasonId, editSubscription.subscriptionId, editSubscription.subscriptionItemId]);

    // Need to addlogic about transfering remaining amount to wallet.

    if (!subscriptionItemResponse[0]) {
        result(null, {
            message: "Subscription not found",
            code: 2,
        });
        return;
    }

    result(null, {
        message: "Subscription canceled successfully",
        code: 0,
    });
    return;

}

Subscription.renewSubscription = async (renewSubscription, result) => {

    const connection = await sql.getConnection();
    try {

        await connection.beginTransaction();

        // var orderItemResponse = await connection.query("UPDATE orderitem SET TotalDeliveries = TotalDeliveries + ?, PendingDeliveries = PendingDeliveries + ? WHERE orderItemId = ?", [renewSubscription.noOfDeliveries, renewSubscription.noOfDeliveries, renewSubscription.orderItemId])

        // if (!orderItemResponse[0]) {
        //     connection.rollback();
        //     result(null, {
        //         message: "Subscription not found",
        //         code: 2,
        //     });
        //     return;
        // }

        var subscriptionData = await connection.query("SELECT EndDateTime FROM subscription where subscriptionId = ?", renewSubscription.subscriptionId);

        if (!subscriptionData[0][0]) {
            connection.rollback();
            result(null, {
                message: "Subscription not found",
                code: 2,
            });
            return;
        }

        const endDate = new Date(subscriptionData[0][0].EndDateTime);
        var noOfDeliveries = renewSubscription.noOfDeliveries;
        var startDate = new Date(renewSubscription.startDate);
        switch (renewSubscription.subscriptionTypeId) {
            case 1://day
                endDate.setDate(startDate.getDate() + (noOfDeliveries));
                break;
            case 2://week
                endDate.setDate(startDate.getDate() + (noOfDeliveries) * 7);
                break;
            case 3://forthnight
                endDate.setDate(startDate.getDate() + (noOfDeliveries) * 15);
                break;
            case 4://month
                endDate.setMonth(startDate.getMonth() + (noOfDeliveries));
                break;
        }
        var subscriptionResponse = await connection.query("Update SUBSCRIPTION SET EndDateTime = ? ,TotalDeliveries = TotalDeliveries + ?, PendingDeliveries = PendingDeliveries + ? , updatedDate = ? where subscriptionId = ?", [endDate, renewSubscription.noOfDeliveries, renewSubscription.noOfDeliveries, new Date(), renewSubscription.subscriptionId]);

        if (!subscriptionResponse[0]) {
            connection.rollback();
            result(null, {
                message: "Error While editing subscription",
                code: 2,
            });
            return;
        }

        // var customerResponse = await sql.query("Select customerAddressId from customeraddress where customerid = ?", renewSubscription.customerId);
        // if (!customerResponse[0][0]) {
        //     result(null, {
        //         message: "Customer not found",
        //         code: 2,
        //     });
        //     return;
        // }

        // var customerAddressId = customerResponse[0][0].customerAddressId;

        // //Add record in subscriptionDeliveryScheduletable

        var scheduleStartDate = new Date(startDate);
        for (i = 0; i < renewSubscription.noOfDeliveries; i++) {

            var subscriptionScheduleResponse = await connection.query("INSERT INTO  subscriptiondeliveries SET subscriptionId = ?, DeliveryDateTime = ?, DeliveryStatusId = ?, Quantity = ?", [renewSubscription.subscriptionId, scheduleStartDate, 1, renewSubscription.quantity]);


            switch (renewSubscription.subscriptionTypeId) {
                case 1://day
                    scheduleStartDate.setDate(scheduleStartDate.getDate() + 1);
                    break;
                case 2://week
                    scheduleStartDate.setDate(scheduleStartDate.getDate() + 7);
                    break;
                case 3://forthnight
                    scheduleStartDate.setDate(scheduleStartDate.getDate() + 15);
                    break;
                case 4://month
                    scheduleStartDate.setMonth(scheduleStartDate.getMonth() + 1);
                    break;

            }

            if (!subscriptionScheduleResponse[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While creating Order",
                    code: 2,
                });
                return;
            }

        }

        connection.commit();
        result(null, {
            message: "Subscription renewed.",
            code: 0,
        });

    } catch (err) {
        console.log(err);
        await connection.rollback();
        result("Error", null);
    }

}

Subscription.editSubscription = async (editSubscription, result) => {

    const connection = await sql.getConnection();
    try {

        await connection.beginTransaction();
        // var orderItemResponse = await connection.query("Update orderitem set OrderQty = ? where OrderItemId = ?", [editSubscription.DeliveryQty, editSubscription.OrderItemId])

        // var subscriptionItemResponse = await connection.query("Update subscriptionitem set Quantity = ? where SubscriptionItemId = ?", [editSubscription.DeliveryQty, editSubscription.SubscriptionItemId])

        // if (!subscriptionItemResponse[0]) {
        //     connection.rollback();
        //     console.log("Edit Subscription: ", response[0]);
        //     result(null, { message: "error while editing subscription", code: 5 });
        //     return;
        // }

        var subscriptionTypeResponse = await connection.query("SELECT SubscriptionTypeId from subscription where SubscriptionId = " + editSubscription.SubscriptionId);

        if (!subscriptionTypeResponse[0][0]) {
            connection.rollback();
            console.log("Edit Subscription: ", response[0]);
            result(null, { message: "Subscription id not found", code: 5 });
            return;
        }

        var subscripionType = subscriptionTypeResponse[0][0].SubscriptionTypeId;

        if (subscripionType == editSubscription.SubscriptionTypeId) {

            var scheduleResponse = await connection.query("Update subscriptiondeliveries set Quantity = ? where SubscriptionId = ? AND DeliveryStatusId = 1", [editSubscription.DeliveryQty, editSubscription.SubscriptionId]);

            if (!scheduleResponse[0]) {
                connection.rollback();
                console.log("Edit Subscription: ", response[0]);
                result(null, { message: "error while editing subscription", code: 5 });
                return;
            }
            connection.commit();
            result(null, {
                message: "Subscription Edited.",
                code: 0,
            });
        } else {
            var deliveryDateTimeResponse = await connection.query("SELECT DeliveryDateTime from subscriptiondeliveries where deliveryStatusId = 1 and subscriptionId = ? order by DeliveryDateTime asc limit 1", editSubscription.SubscriptionId);

            if (!deliveryDateTimeResponse[0][0]) {
                connection.rollback();
                console.log("Edit Subscription: ", response[0]);
                result(null, { message: "error while editing subscription", code: 5 });
                return;
            }
            var startDate = deliveryDateTimeResponse[0][0].DeliveryDateTime;

            var subscriptionResponse = await connection.query("SELECT PendingDeliveries from subscription where subscriptionId = " + editSubscription.SubscriptionId);

            if (!subscriptionResponse[0][0]) {
                connection.rollback();
                console.log("Edit Subscription: ", response[0]);
                result(null, { message: "error while editing subscription", code: 5 });
                return;
            }

            var noOfDeliveries = subscriptionResponse[0][0].PendingDeliveries;

            //Cancel all previous subscription for this id and insert new subscription deliveries
            var scheduleResponse = await connection.query("Update subscriptiondeliveries set DeliveryStatusId = 4 where SubscriptionId = ? AND DeliveryStatusId = 1", editSubscription.SubscriptionId);

            if (!scheduleResponse[0]) {
                connection.rollback();
                console.log("Edit Subscription: ", response[0]);
                result(null, { message: "error while editing subscription", code: 5 });
                return;
            }
            var endDate = new Date(startDate);

            switch (editSubscription.SubscriptionTypeId) {
                case 1://day
                    endDate.setDate(startDate.getDate() + (noOfDeliveries - 1));
                    break;
                case 2://week
                    endDate.setDate(startDate.getDate() + (noOfDeliveries - 1) * 7);
                    break;
                case 3://forthnight
                    endDate.setDate(startDate.getDate() + (noOfDeliveries - 1) * 15);
                    break;
                case 4://month
                    endDate.setMonth(startDate.getMonth() + (noOfDeliveries - 1));
                    break;
            }

            var subscriptionTypeResponse = await connection.query("Update subscription SET SubscriptionTypeId = ?, EndDateTime = ? where SubscriptionId = ?", [editSubscription.SubscriptionTypeId, endDate, editSubscription.SubscriptionId]);

            //Insert new schedule base on subscription type;
            var scheduleStartDate = new Date(startDate);
            for (i = 0; i < noOfDeliveries; i++) {

                var subscriptionScheduleResponse = await connection.query("INSERT INTO  subscriptiondeliveries SET subscriptionId = ?, DeliveryDateTime = ?, DeliveryStatusId = ?, Quantity = ?", [editSubscription.SubscriptionId, scheduleStartDate, 1, editSubscription.DeliveryQty]);

                switch (editSubscription.SubscriptionTypeId) {
                    case 1://day
                        scheduleStartDate.setDate(scheduleStartDate.getDate() + 1);
                        break;
                    case 2://week
                        scheduleStartDate.setDate(scheduleStartDate.getDate() + 7);
                        break;
                    case 3://forthnight
                        scheduleStartDate.setDate(scheduleStartDate.getDate() + 15);
                        break;
                    case 4://month
                        scheduleStartDate.setMonth(scheduleStartDate.getMonth() + 1);
                        break;

                }
            }
            if (!subscriptionScheduleResponse[0]) {
                connection.rollback();
                result(null, {
                    message: "Error While creating Order",
                    code: 2,
                });
                return;
            }
            connection.commit();
            result(null, {
                message: "Subscription Edited.",
                code: 0,
            });

        }
    } catch (err) {
        console.log(err);
        await connection.rollback();
        result("Error", null);
    }
}


Subscription.getSubscriptionBasket = async (result) => {
    try {
        var subscriptionBasketResponse = await sql.query("SELECT SubscriptionBasketId,BasketName,Description from subscripBaskets");
        if (!subscriptionBasketResponse[0][0]) {
            result(null, {
                message: "Subscription Basket not found",
                code: 2,
            });
        }
        result(null, {
            basket: subscriptionBasketResponse[0],
            code: 0,
        });
    } catch (err) { console.log(err); }
}

module.exports = Subscription;

