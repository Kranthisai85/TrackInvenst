const sql = require("./db.js");
const e = require("express");
const https = require('https');
var constants = require('../lib/constants');

const Delivery = function (delivery) {
};
Delivery.orderListForDeliveryPerson = async (deliveryPersonId, result) => {
    try {

        var date = new Date();
        date.setHours(0, 0, 0, 0);


        var orderItems = await sql.query("Select BIN_TO_UUID( om.orderId) as OrderId,Count(oi.OrderItemId) as OrderItemCount, om.OrderNumber,ca.CotactName, ca.ContactPhone, ca.Address1,ca.Address2,ca.Landmark,ca.AreaDescription, ci.City, ca.Postcode,BIN_TO_UUID(om.PaymentStatusId) as PaymentStatusId,asm.StatusDescription as PaymentStatus,oi.DeliveryDate from ordermaster om, orderItem oi,cities ci, customeraddress ca, appstatusmaster asm where oi.OrderId = om.OrderId and oi.DeliveryDate = date(?) and om.CustomerId = ca.CustomerId and om.PaymentStatusId = asm.AppStatusMasterId  and om.CustomerAddressId = ca.CustomerAddressId  and oi.OrderItemStatusId = UUID_TO_BIN(?)  and oi.DeliveryPersonId = UUID_TO_BIN(?) and ca.CityId = ci.CityId group by  om.orderId order by DeliveryDate", [date, constants.ORDER_ITEM_OUT_FOR_DEL, deliveryPersonId]);

        result(null, { code: 0, message: "Success", orders: orderItems[0] });
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Failed" });
    }
}

Delivery.getOrderItemByOrderId = async (orderId, deliveryPersonId, result) => {
    try {
        var orderDetails = await sql.query("SELECT BIN_TO_UUID(p.ProductId) AS ProductId,p.ProductName,p.ProductNameHindi, p.IsOrganic,pia.ImageHRPath, BIN_TO_UUID(om.OrderId) As OrderId, BIN_TO_UUID(oi.OrderItemId) as OrderItemId, oi.DeliveryDate,oi.OrderQty as CartQty, pwp.ProductUnit, um.UnitOfMeasurementCode from product p inner join productimage pia on p.ProductId = pia.ProductId inner join orderitem oi on oi.ProductId = p.ProductId inner join ordermaster om on om.OrderId = oi.OrderId inner join productwarehouepricing pwp on pwp.ProductWarehousePricingId = oi.ProductWarehousePricingId inner join unitofmeasurement um on pwp.UnitOfMeasurementId = um.UnitOfMeasurementId inner join appstatusmaster asm on asm.AppStatusMasterId = oi.OrderItemStatusId where om.orderId = UUID_TO_BIN(?) and oi.DeliveryPersonId = UUID_TO_BIN(?)", [orderId, deliveryPersonId]);


        result(null, { code: 0, message: "Success", orderItem: orderDetails[0] });
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Failed" });
    }
}

Delivery.getCancelationReason = async (result) => {

    try {
        var response = await sql.query("SELECT DeliveryChangeReasonId,DeliveryChangeReasonEnumId,ReasonDescription from deliverychangereason");
        result(null, { code: 0, message: "Success", reasons: response[0] });
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Failed" });
    }
}

Delivery.onOrderDelivered = async (req, result) => {
    try {
        var orderItems = req.body.orderItems;
        var deliveryPersonId = req.body.deliveryPersonId;
        if (orderItems != null) {
            for (i in orderItems) {
                var orderItemDetails = await sql.query("Update orderItem set OrderItemStatusId = UUID_TO_BIN(?),UpdatedDate = (?),UpdatedBy=UUID_TO_BIN(?) where OrderItemId=UUID_TO_BIN(?)", [constants.ITEM_DELIVERED, new Date(), deliveryPersonId, orderItems[i]]);
            }

            var orderIdResponse = await sql.query("SELECT BIN_TO_UUID(OrderId) as OrderId from orderItem where orderitemid = UUID_TO_BIN(?)", orderItems[0]);

            var orderId = "";
            if (orderIdResponse[0][0])
                orderId = orderIdResponse[0][0].OrderId;

            var orderMasterStatus = await sql.query("Select TblTotalOrders.TotalOrders, TblCanceledOrders.CanceledOrders,TblDeliveredOrders.DeliveredOrders From (select  om.OrderID, count(oi.OrderId) AS TotalOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) group by oi.OrderId) TblTotalOrders Left join  (select om.OrderID, count(oi.OrderId) AS CanceledOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f23-7e32-bd6b-c49deda8deaf') group by oi.OrderId) AS TblCanceledOrders ON TblTotalOrders.OrderId = TblCanceledOrders.OrderId Left Join  (select om.OrderID, count(oi.OrderId) AS DeliveredOrders  from ordermaster om inner join orderitem oi on om.OrderId = oi.OrderId where om.OrderId = UUID_TO_BIN(?) and oi.OrderItemStatusId = UUID_TO_BIN('11eb2987-5f22-6c45-bd6b-c49deda8deaf') group by oi.OrderId) AS TblDeliveredOrders ON TblTotalOrders.OrderId = TblDeliveredOrders.OrderId", [orderId, orderId, orderId]);

            if (orderMasterStatus[0][0]) {
                var TotalOrders = orderMasterStatus[0][0].TotalOrders == null ? 0 : orderMasterStatus[0][0].TotalOrders;
                var CanceledOrders = orderMasterStatus[0][0].CanceledOrders == null ? 0 : orderMasterStatus[0][0].CanceledOrders;
                var DeliveredOrders = orderMasterStatus[0][0].DeliveredOrders == null ? 0 : orderMasterStatus[0][0].DeliveredOrders;

                var status = constants.ORDER_PENDING;

                var orders = TotalOrders - CanceledOrders;
                if (DeliveredOrders == 0) {
                    status = constants.ORDER_PENDING;
                } else if (orders == DeliveredOrders) {
                    status = constants.ORDER_DELIVERED
                } else if (DeliveredOrders > 0 && DeliveredOrders < TotalOrders) {
                    status = constants.ORDER_PD;
                }
            }

            var orderStatus = await sql.query("UPDATE ORDERMASTER SET OrderStatusId = UUID_TO_BIN(?),UpdatedDate=(?),updatedBy=UUID_TO_BIN(?) where orderId = UUID_TO_BIN(?)", [status, new Date(), deliveryPersonId, orderId]);

            var orderDetails = await sql.query("Select om.OrderNumber,ca.ContactPhone,p.ProductName from ordermaster om,customeraddress ca, Product p, orderitem oi where oi.OrderId=om.OrderId and p.ProductId = oi.ProductId and  ca.CustomerAddressId = om.CustomerAddressId and oi.OrderItemId = UUID_TO_BIN(?)", orderItems[0]);

            if (orderDetails[0][0]) {
                var delType;
                if (orderItems.length > 1) {
                    delType = 2;
                } else {
                    delType = 1
                }
                var count = orderItems.length - 1;
                var supportMobile = "XXXXXXXXXX";
                var productName = orderDetails[0][0].ProductName;
                var mobileNumber = orderDetails[0][0].ContactPhone;
                var orderNumber = orderDetails[0][0].OrderNumber;
                if (constants.SEND_SMS)
                    sendOrderDeliveredMessage(delType, mobileNumber, orderNumber, productName, count, supportMobile);
            }
            result(null, { code: 0, message: "Success" });
        }
    } catch (e) {
        console.log(e);
        result(null, { code: 2, message: "Failed" });
    }
}

async function sendOrderDeliveredMessage(delType, mobileNumber, orderNumber, productName, count, supportMobile) {
    var TemplateName = getTemplateNameForOrderPlace(delType);
    const data = getBodyParametersForOrderPlace(delType, mobileNumber, TemplateName, orderNumber, productName, count, supportMobile);

    const options = {
        host: '2factor.in',
        path: '/API/V1/9dd7b6d6-2713-11eb-83d4-0200cd936042/ADDON_SERVICES/SEND/TSMS',
        method: 'POST',
        port: null,
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        }
    }

    const req = https.request(options, (res) => {
        let data = '';

        console.log('Status Code:', res.statusCode);

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Body: ', JSON.parse(data));
        });

    }).on("error", (err) => {
        console.log("Error: ", err.message);
    });

    req.write(data);
    req.end();

}

function getTemplateNameForOrderPlace(typeId) {
    switch (typeId) {
        case 1:
            return 'DEL_DONE_SING';
        case 2:
            return 'DEL_DONE_MUL';
    }
}

function getBodyParametersForOrderPlace(delType, mobileNumber, TemplateName, orderNumber, englishName, count, supportMobile) {
    switch (delType) {
        case 1: return getBodySingleProductDelivered(mobileNumber, TemplateName, orderNumber, englishName, supportMobile);

        case 2: return getBodyMultipleProductDelivered(mobileNumber, TemplateName, orderNumber, englishName, count, supportMobile);
    }
}

function getBodySingleProductDelivered(mobileNumber, TemplateName, orderNumber, englishName, supportMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': supportMobile//supportMobile
    });
    console.log(data);
    return data;
}

function getBodyMultipleProductDelivered(mobileNumber, TemplateName, orderNumber, englishName, count, supportMobile) {
    var data = JSON.stringify({
        'From': "eStvik",
        'To': mobileNumber,
        'TemplateName': TemplateName,//Order Single Product Paid
        'VAR1': orderNumber,//OrderID 
        'VAR2': englishName,//English Name
        'VAR3': count,//supportMobile
        'VAR4': supportMobile
    });
    console.log(data);
    return data;
}

module.exports = Delivery;