const sql = require("./db.js");

// constructor
const Product = function (product) {

    //this.ProductId = product.ProductId,
    this.ProductName = product.ProductName,
    this.Address1= product.Address1,
    this.Address2 = product.Address2,
    this.CountryId = product.CountryId,
    this.StateId = product.StateId,
    this.CityId = product.CityId,
    this.PostCode = product.PostCode,
    this.ContactName = product.ContactName,
    this.ContactPhone = product.ContactPhone,
    this.Website = product.Website,
    this.Email = product.Email;
    //this.isadmin = user.isadmin
};