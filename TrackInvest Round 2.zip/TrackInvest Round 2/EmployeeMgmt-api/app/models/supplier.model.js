const sql = require("./db.js");

// constructor
const Supplier = function (supplier) {

    //this.SupplierId = supplier.SupplierId,
    this.SupplierName = supplier.SupplierName,
    this.Address1= supplier.Address1,
    this.Address2 = supplier.Address2,
    this.CountryId = supplier.CountryId,
    this.StateId = supplier.StateId,
    this.CityId = supplier.CityId,
    this.PostCode = supplier.PostCode,
    this.ContactName = supplier.ContactName,
    this.ContactPhone = supplier.ContactPhone,
    this.Website = supplier.Website,
    this.Email = supplier.Email;
    //this.isadmin = user.isadmin
};

Supplier.create = async (newSupplier, result) => {
  
  var createSupplier = await sql.query("INSERT INTO supplier SET SupplierName = ?, Address1 = ?, Address2 = ?, CountryId = ?, StateId = ?, CityId = ?, PostCode = ?, ContactName = ?, ContactPhone = ?, Website = ?, Email = ?", [newSupplier.SupplierName, newSupplier.Address1, newSupplier.Address2, newSupplier.CountryId, newSupplier.StateId, newSupplier.CityId, newSupplier.PostCode, newSupplier.ContactName, newSupplier.ContactPhone, newSupplier.Website, newSupplier.Email]);
    if (!createSupplier[0]) {
      console.log("error: ", createSupplier[0]);
      result(createSupplier[0], null);
      return;
    }

    console.log("Created Supplier: ", { SupplierId: createSupplier[0].insertId, ...newSupplier });
    result(null, { message:"Supplier added successfully",
                  code:0,
                  SupplierId: createSupplier[0].insertId, ...newSupplier });
  
}

Supplier.findById = async (supplierId, result) => {
  var findByIdSupplier = await sql.query(`SELECT SupplierId,SupplierName,Address1,Address2,CountryId,StateId,CityId,PostCode,ContactName,ContactPhone,Website,Email FROM supplier WHERE SupplierId = ${supplierId}`);

 if (!findByIdSupplier[0]) {
      console.log("error: ", findByIdSupplier[0]);
      result(findByIdSupplier[0], null);
      return;
    } 

    if (findByIdSupplier[0].length) {
      console.log("found Supplier: ", findByIdSupplier[0]);
      result(null, findByIdSupplier[0]);
      return;
    }

    // not found supplier with the id
    result({ kind: "not_found" }, null);
};

Supplier.getAll = async result => {
  var getAllSupplier = await sql.query("SELECT SupplierId,SupplierName,Address1,Address2,CountryId,StateId,CityId,PostCode,ContactName,ContactPhone,Website,Email FROM supplier");
    if (!getAllSupplier[0]) {
      console.log("error: ", getAllSupplier[0]);
      result(null, getAllSupplier[0]);
      return;
    }

    console.log("Supplier: ", getAllSupplier[0]);
    result(null, getAllSupplier[0]);
};

Supplier.updateById = async (supplierId, supplier, result) => {
  const resultOne = await sql.query(
    "UPDATE supplier SET SupplierName = ?, Address1 = ?, Address2 = ?, CountryId = ?, StateId = ?, CityId = ?, PostCode = ?, ContactName = ?, ContactPhone = ?, Website = ?, Email = ? WHERE SupplierId = ?",
    [supplier.SupplierName, supplier.Address1, supplier.Address2, supplier.CountryId, supplier.StateId, supplier.CityId, supplier.PostCode, supplier.ContactName, supplier.ContactPhone, supplier.Website, supplier.Email, supplierId]);

  console.log("result ", resultOne[0]);


  if (resultOne[0] == null) {
    console.log("error: ", "err");
    result(null, { "message": "error" });
    return;
  }

  if (resultOne[0].affectedRows == 0) {
    // not found supplier with the id
    result({ kind: "not_found" }, null);
    return;
  }

  console.log("updated supplier: ", { Supplierid: supplierId, ...supplier });
  result(null, { message:"Supplier Updated successfully",
  code:0,
  Supplierid: supplierId, ...supplier });
//   Supplierid: SupplierId, ...supplier
};

Supplier.remove = async (supplierId, result) => {
    var removeSupplier = await sql.query("DELETE FROM supplier WHERE SupplierId = ?",supplierId);
    if (!removeSupplier[0]) {
      console.log("error: ", removeSupplier[0]);
      result(null, removeSupplier[0]);
      return;
    }

    console.log("deleted supplier with SupplierId: ", supplierId);
    result(null, removeSupplier[0]);
 
};

Supplier.removeAll = async result => {
  var removeAllSupplier = await sql.query("DELETE FROM supplier");
    if (!removeAllSupplier[0]) {
      console.log("error: ", removeAllSupplier[0]);
      result(null, removeAllSupplier[0]);
      return;
    }

    console.log(`deleted ${removeAllSupplier[0].affectedRows} suppliers`);
    result(null, removeAllSupplier[0]);

};

module.exports = Supplier;
