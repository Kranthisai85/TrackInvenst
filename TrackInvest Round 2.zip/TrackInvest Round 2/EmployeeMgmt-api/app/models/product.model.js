const sql = require("./db.js");
const moment = require('moment');

// constructor
// Create a Product
const Product = function (product) {
    if (!new.target) {
        return new Product(product);
    }
    this.skuNumber = product.skuNumber,
        this.productName = product.productName,
        this.productNameHindi = product.productNameHindi,
        this.isOrganic = product.isOrganic,
        this.isLotItem = product.isLotItem,
        this.productCategoryId = product.productCategoryId,
        this.seasonStartDate = ParseUndefined(product.seasonStartDate),
        this.seasonEndDate = ParseUndefined(product.seasonEndDate),
        this.description = product.description,
        this.productPrice = product.productPrice,
        this.isTaxable = product.isTaxable,
        this.productTypeId = product.productTypeId
};

function ParseUndefined(value) {

    return (typeof value === 'undefined' ? null : value);
}
Product.create = async (newProduct, req, result) => {
    try {
        const productRespone = await sql.query("INSERT INTO product SET ?", newProduct);
        if (productRespone[0] == null) {
            result(null, {
                message: "Error while creating Product",
                code: 3
            })
        }
        console.log("created Product: ", productRespone[0]);

        result(null, { msg: "Product Added Successfully", ...newProduct });
    } catch (err) {
        console.log("error", err);
        result("Error", null);
    };
}

Product.findById = (productId, result) => {

    var sqlQuery = `select BIN_TO_UUID(p.ProductId) AS ProductId,p.ProductName, p.ProductNameHindi, p.Description, BIN_TO_UUID(p.ProductStatusId) As ProductStatusId, p.ProductPrice, 
    p.MinPriceRange, p.MaxPriceRange, BIN_TO_UUID(p.ProductTypeId) AS ProductTypeId, BIN_TO_UUID(p.ProductCategoryId) AS ProductCategoryId, p.WeightRangeUpper, p.WeightRangeLower, p.Length, p.Width,
    p.Height, p.CouponId, p.MinSubscriptionQty, p.MinOrderQty, p.HSCodeId, p.SeasonStartDate, p.SeasonEndDate, BIN_TO_UUID(p.UnitOfMeasurementId) As UnitOfMeasurementId, p.IsOrganic,
    p.IsLotItem, p.CreatedDate, p.CreatedBy, p.UpdatedDate, p.UpdatedBy, pi.ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath
        from product as p  left join productimage as pi on (p.productid = pi.productid) WHERE BIN_TO_UUID(p.ProductId) = '${productId}'`
    console.log(sqlQuery);
    sql.query(sqlQuery, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            console.log("found Product: ", res[0]);
            result(null, res[0]);
            return;
        }

        // not found Product with the id
        result({ kind: "not_found" }, null);
    });
};

Product.search = (productName, result) => {

    var sqlQuery = `SELECT BIN_TO_UUID( p.ProductId) ProductId, p.ProductName, p.ProductNameHindi, p.Description, p.IsOrganic, p.SeasonStartDate, p.SeasonEndDate, p.SeasonStartDate, p.SeasonEndDate,
    uom.UnitOfMeasurementCode, pt.ProductType, pc.ProductCategory
    FROM efarms.product p inner join appstatusmaster asm on p.ProductStatusId = asm.AppStatusMasterId
    left join producttype pt on p.ProductTypeId = pt.ProductTypeId
    left join productcategory pc on p.ProductCategoryId = pc.ProductCategoryId
    inner join unitofmeasurement uom On p.UnitOfMeasurementId = uom.UnitOfMeasurementId WHERE p.ProductName like N'%${productName}%' or p.ProductNameHindi like N'%${productName}%'`;
    console.log(sqlQuery);

    sql.query(sqlQuery, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length) {
            console.log("found Product: ", res[0]);
            result(null, res);
            return;
        }

        // not found Product with the id
        result({ kind: "not_found" }, null);
    });
};


Product.getAll = async (categoryId, customerId, result) => {
    var today = new moment().format('YYYY-MM-DD');
    var products = await sql.query("SELECT SQL_NO_CACHE BIN_TO_UUID(p.ProductId) AS ProductId,p.ProductName,p.ProductNameHindi,p.Description, BIN_TO_UUID(p.ProductStatusId) AS ProductStatusId,p.MaxPriceRange,p.MinPriceRange,BIN_TO_UUID(p.ProductCategoryId) AS ProductCategoryId,p.MinSubscriptionQty,p.MinOrderQty,p.SeasonStartDate,p.SeasonEndDate,p.IsOrganic,p.IsTaxable,BIN_TO_UUID(p.ProductTypeId) AS ProductTypeId,p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId, p.IsLotItem,BIN_TO_UUID(pi.ProductImageId) AS ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath from product as p left join productimage as pi on (p.productid = pi.productid)  where ProductCategoryId = UUID_TO_BIN(?) AND (SeasonEndDate is NULL  OR SeasonEndDate >=  ?)", [categoryId, today]);
    var productList = products[0];
    if (productList.length == 0) {
        result(null, {
            message: "No Products found",
            code: 1
        });
        return;
    }

    var productTypeList = await sql.query("select distinct(BIN_TO_UUID(p.ProductTypeId)) as ProductTypeId, pt.ProductType from product p, producttype pt where p.ProductTypeId = pt.ProductTypeId and p.ProductCategoryId = UUID_TO_BIN(?) AND (SeasonEndDate is NULL  OR SeasonEndDate >=  ?)", [categoryId, today]);



    for (i in productList) {
        var product = productList[i];
        var quanity;

        quanity = await sql.query("Select ProductWarehousePricingId,UnitOfMeasurementId,ProductId, ProductName,ProductUnit,UnitOfMeasurementCode,CartQuantity,ProductUnitPrice,WarehouseId from (Select  BIN_TO_UUID(c.CartId) AS CartId, BIN_TO_UUID(ci.ProductId) AS ProductId, p.ProductName, pwp.productUnit,BIN_TO_UUID(uom.UnitOfMeasurementId) AS UnitOfMeasurementId, uom.UnitOfMeasurementCode, CAST(ci.Quantity AS SIGNED) as CartQuantity, pwp.ProductUnitPrice,BIN_TO_UUID(pwp.ProductWarehousePricingId) AS `ProductWarehousePricingId`, BIN_TO_UUID(pwp.WarehouseId) as WarehouseId from cart c inner join cartitem ci on c.CartId = ci.CartId left join product p on p.ProductId = ci.ProductId inner join productinventory pi on pi.ProductId = p.ProductId inner join productwarehouepricing pwp on pwp.ProductWarehousePricingId = ci.ProductWarehousePricingId inner join unitofmeasurement uom on uom.UnitOfMeasurementId = pwp.UnitOfMeasurementId where c.CustomerId =UUID_TO_BIN(?) AND (pi.InventoryOnHand < pi.InventoryRestockQty) = 0 Union all Select 0 as CartId, BIN_TO_UUID(p.ProductId) AS ProductId, p.ProductName, pwp.ProductUnit, BIN_TO_UUID(uom.UnitOfMeasurementId) AS UnitOfMeasurementId,uom.UnitOfMeasurementCode, CAST(0 AS SIGNED) as CartQuantity, pwp.ProductUnitPrice, BIN_TO_UUID(pwp.ProductWarehousePricingId) AS ProductWarehousePricingId,BIN_TO_UUID(pwp.WarehouseId) as WarehouseId from product p  inner join productinventory pi on pi.ProductId = p.ProductId inner join productwarehouepricing pwp on pwp.ProductInventoryId = pi.ProductInventoryId inner join unitofmeasurement uom on uom.UnitOfMeasurementId = pwp.UnitOfMeasurementId Left join (Select ci.ProductId, ci.ProductWarehousePricingId,BIN_TO_UUID(pwp.WarehouseId) as WarehouseId from cart c  inner join cartitem ci on c.CartId = ci.CartId inner join productwarehouepricing pwp on pwp.ProductWarehousePricingId = ci.ProductWarehousePricingId where c.CustomerId = UUID_TO_BIN(?)) as pcT On  pcT.ProductWarehousePricingId = pwp.ProductWarehousePricingId Where pct.ProductWarehousePricingId	IS NULL AND (pi.InventoryOnHand < pi.InventoryRestockQty) = 0) as product where ProductId = ?", [customerId, customerId, product.ProductId])

        var quanityList = quanity[0];

        if (quanityList.length == 0) {
            product.isOutOfStock = true;
        } else {
            product.isOutOfStock = false;
            product.Quantity = quanityList;
        }

        //product.selected = newData[0];

        var description = await sql.query("select pa.ProductAttribute,pa.ProductAttributeDesc, BIN_TO_UUID(pam.ProductAttributeId) AS ProductAttributeId from productattributes pa inner join  productattributematrix pam on pa.ProductAttributeId = pam.ProductAttributeId AND pam.ProductId = UUID_TO_BIN(?)", product.ProductId);

        product.prdDescription = description[0];
    }

    var cartDetails = await sql.query("Select c.cartId ,Count(ci.CartItemId) as CartItemCount, sum(ProductPrice * Quantity) as CartTotal from cart c inner join cartitem ci on c.CartId = ci.CartId where c.CustomerId = UUID_TO_BIN(?)", customerId);
    var cartItemCount = 0;
    var cartItemTotal = 0.0;
    if (cartDetails[0][0]) {
        cartItemCount = cartDetails[0][0].CartItemCount;
        cartItemTotal = cartDetails[0][0].CartTotal;
    }

    typeList = productTypeList[0];
    result(null, {
        message: "Success",
        code: 0,
        cartItemCount: cartItemCount,
        cartItemTotal: cartItemTotal,
        product: productList,
        typeList: typeList,

    });

};

Product.updateById = async (productId, Product, result) => {
    var sqlQuery = ("UPDATE product SET ProductName = ?, Description = ?, ProductPrice = ?, IsTaxable = ?, SeasonStartDate =?, SeasonEndDate=? WHERE BIN_TO_UUID(productId) = ?",
        [Product.productName, Product.description, Product.productPrice, Product.isTaxable, Product.seasonStartDate, Product.seasonEndDate, productId]);
    console.log(sqlQuery);

    const updateResult = await sql.query(
        "UPDATE product SET ProductName = ?, Description = ?, ProductPrice = ?, IsTaxable = ?, SeasonStartDate =STR_TO_DATE(?,'%d-%m-%Y'), SeasonEndDate=STR_TO_DATE(?,'%d-%m-%Y') WHERE BIN_TO_UUID(productId) = ?",
        [Product.productName, Product.description, Product.productPrice, Product.isTaxable, Product.seasonStartDate, Product.seasonEndDate, productId]);

    console.log("result ", updateResult[0]);

    if (updateResult[0] == null) {
        console.log("error: ", "err");
        result(null, { "message": "error" });
        return;
    }

    if (updateResult[0].affectedRows == 0) {
        // not found User with the id
        result({ kind: "not_found" }, null);
        return;
    }

    console.log("updated user: ", { id: productId, ...product });
    result(null, { id: productId, ...product });
};

Product.remove = async (productId, result) => {
    const updateResponse = await sql.query("DELETE FROM product WHERE productId = ?", productId);
    if (updateResponse[0] == null) {
        console.log("error: ", "err");
        result(null, { "message": "error" });
        return;
    }

    if (updateResponse[0].affectedRows == 0) {
        // not found Product with the id
        result({ kind: "not_found" }, null);
        return;
    }

    console.log("deleted product with productId: ", productId);
    result(null, { "message": `deleted product with productId: ${productId}` });
};

Product.removeAll = result => {
    sql.query("DELETE FROM product", (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(null, err);
            return;
        }

        console.log(`deleted ${res.affectedRows} product`);
        result(null, res);
    });
};

Product.getProductCategories = async (result) => {

    const productCategory = await sql.query("Select BIN_TO_UUID(ProductCategoryId) as ProductCategoryId, ProductCategory,ProductCategoryImage from ProductCategory");
    if (!productCategory[0]) {
        result(null, {
            message: "No Product Category found",
            code: 1
        });
        return;
    }
    console.log("found Product: ", productCategory[0]);
    result(null, { message: "Success", code: 0, categories: productCategory[0] });
    return;

};

Product.getUnitOfMeasurement = async (result) => {

    const uom = await sql.query("Select BIN_TO_UUID(UnitOfMeasurementId) as UnitOfMeasurementId, UnitOfMeasurementCode from unitofmeasurement");
    if (!uom[0]) {
        result(null, {
            message: "No Product Category found",
            code: 1
        });
        return;
    }
    console.log("Unit Of Measurement: ", uom[0]);
    result(null, { message: "Success", code: 0, uom: uom[0] });
    return;

};

Product.getProductStatus = async (result) => {

    const productStatus = await sql.query("SELECT BIN_TO_UUID(AppStatusMasterId) as AppStatusMasterId, StatusName FROM efarms.appstatusmaster where ModuleName = 'PRODUCT' ORDER BY StatusName;");
    if (!productStatus[0]) {
        result(null, {
            message: "No Product Status found",
            code: 1
        });
        return;
    }
    console.log("Product Status: ", productStatus[0]);
    result(null, { message: "Success", code: 0, status: productStatus[0] });
    return;

};


Product.getAllCatgories = async (customerId, result) => {
    try {
        const productcategoryResponse = await sql.query("Select BIN_TO_UUID(ProductCategoryId), ProductCategory,ProductCategoryImage from productcategory");
        if (productcategoryResponse[0] == null) {
            console.log("error: ", productcategory[0]);
            result(null, productcategory[0]);
            return;
        }
        var categories = [];
        var productCategory = productcategoryResponse[0];
        if (productCategory.length > 0) {
            for (var i = 0; i < productCategory.length; i++) {
                var id = productCategory[i].ProductCategoryId;
                var name = productCategory[i].ProductCategory;
                var image = productCategory[i].ProductCategoryImage;
                var types = []

                // const prodType = await sql.query("select ProductTypeId,ProductType,ProductCategoryId,ProductTypeImage from producttype WHERE ProductCategoryId = ?", id);
                // const prodType = await sql.query("select ProductTypeId,ProductType,ProductTypeImage from producttype as pt inner join product as p on pt.ProductTypeId = p.ProductTypeId where p.ProductCategoryId is not null and p.ProductCategoryId = ?", id);

                const prodType = await sql.query("select distinct pt.ProductTypeId,ProductType,ProductTypeImage from producttype as pt inner join product as p on pt.ProductTypeId = p.ProductTypeId where  p.ProductCategoryId = ? order by ProductType", id);

                if (prodType[0] == null) {
                    console.log("error: ", prodType[0]);
                    //result(null, prodType[0]);
                    return;
                }
                console.log("product type", prodType[0]);
                var productType = prodType[0];

                var productCategoryId = productCategory[i].ProductCategoryId;
                for (j in productType) {
                    var productTypeId = productType[j].ProductTypeId;
                    // var products = await sql.query("select p.ProductId,p.SkuNumber,p.ProductName,p.Description, p.ProductStatusId,p.ProductPrice,p.IsTaxable,p.ProductTypeId,p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId,pi.ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath from product as p left join productimage as pi on (p.productid = pi.productid) WHERE p.productTypeId = ? AND p.ProductCategoryId = ?", [productTypeId,ProductCategoryId]);

                    var products = await sql.query("select p.ProductId,p.SkuNumber,p.ProductName,p.Description, p.ProductStatusId,p.ProductPrice,p.MinPriceRange,p.MaxPriceRange,p.IsTaxable,p.ProductTypeId,p.ProductCategoryId,p.Length,p.Width,p.Height,p.CouponId,p.MinSubscriptionQty,p.MinOrderQty,p.HSCodeId,p.SeasonStartDate,p.SeasonEndDate,p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId,pi.ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath from product as p left join productimage as pi on (p.productid = pi.productid) WHERE p.productTypeId = ? AND p.ProductCategoryId = ? UNION select p.ProductId,p.SkuNumber,p.ProductName,p.Description, p.ProductStatusId,p.ProductPrice,p.MinPriceRange,p.MaxPriceRange,p.IsTaxable,p.ProductTypeId,p.ProductCategoryId,p.Length,p.Width,p.Height,p.CouponId,p.MinSubscriptionQty,p.MinOrderQty,p.HSCodeId,p.SeasonStartDate,p.SeasonEndDate,p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId,pi.ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath from product as p left join productimage as pi on (p.productid = pi.productid) WHERE p.productTypeId is null AND p.ProductCategoryId = ?", [productTypeId, productCategoryId, productCategoryId])

                    productType[j].Product = products[0];

                }
                const responseToSend = {
                    cagtegoryId: id,
                    categoryName: name,
                    categoryImage: image,
                    productType: productType
                }
                categories.push(responseToSend);
            }
            var subscriptionBasketResponse = await sql.query("SELECT SubscriptionBasketId,BasketName,Description from subscripBaskets");
            var basketType;
            if (!subscriptionBasketResponse[0][0]) { }
            else {
                basketType = subscriptionBasketResponse[0]
            }

            var customerAddressResponse = await sql.query("SELECT c.CustomerAddressId,c.CustomerId,c.Address1,c.Address2,c.CountryId,c.StateId,c.CityId,c.AreaId,adt.AddressType from customeraddress as c inner join addressType as adt where c.AddressTypeId = adt.AddressTypeId and CustomerId = ?", customerId);

            var customerAddress;
            if (!customerAddressResponse[0][0]) { }
            else {
                customerAddress = customerAddressResponse[0];
            }

            const response = {
                categories: categories,
                basketType: basketType,
                customerAddress: customerAddress
            }
            result(null, JSON.stringify(response));
        }
    } catch (err) {
        result(err, null);
    }
};

Product.findAllByType = (typeId, result) => {
    sql.query(`select p.ProductId,p.SkuNumber,p.ProductName,p.Description, p.ProductStatusId,p.ProductPrice,p.MinPriceRange,p.MaxPriceRange,p.IsTaxable,p.ProductTypeId,p.ProductCategoryId,p.Length,p.Width,p.Height,p.CouponId,p.MinSubscriptionQty,p.MinOrderQty,p.HSCodeId,p.SeasonStartDate,p.SeasonEndDate,p.WeightRangeLower,p.WeightRangeUpper,p.Length,p.Width,p.Height,p.CouponId,pi.ProductImageId,pi.ImageHRPath,pi.ImageLRPath,pi.ImageThumbNailPath
        from product as p
        left join productimage as pi
        on (p.productid = pi.productid) WHERE productTypeId = ${typeId}`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }


        console.log("found Product: ", res);
        result(null, res);
        return;

        // not found Product with the id
        result({ kind: "not_found" }, null);
    });
};


Product.notifyMe = async (req, result) => {
    var userId = req.body.userId;
    var customerId = req.body.customerId;
    var productId = req.body.productId;
    var warehouseId = req.body.warehouseId;

    try {
        var response = await sql.query("insert into notifyme set NotifyMeId = UUID_TO_BIN(UUID()), ProductId = UUID_TO_BIN(?),WarehouseId = UUID_TO_BIN(?), CustomerId = UUID_TO_BIN(?),CreatedById = UUID_TO_BIN(?)", [productId, warehouseId, customerId, userId]);

        result(null, {
            message: "Success",
            code: 0,
        });
    } catch (e) {
        console.log(e);
        result(null, {
            message: "Success",
            code: 0,

        });
    }
}

module.exports = Product;