const sql = require("./db.js");
const constants = require('../lib/constants');
// constructor
const Employee = function (employee) {
  //this.EmployeeId = employee.EmployeeId
  this.UserId = employee.UserId,
    this.FirstName = employee.FirstName,
    this.MiddleName = employee.MiddleName,
    this.LastName = employee.LastName,
    this.JoiningDate = employee.JoiningDate,
    this.TerminationDate = employee.TerminationDate,
    this.DateOfBirth = employee.DateOfBirth,
    this.AnniversaryDate = employee.AnniversaryDate,
    this.Address1 = employee.Address1,
    this.Address2 = employee.Address2,
    this.CountryId = employee.CountryId,
    this.CityId = employee.CityId,
    this.StateId = employee.StateId,
    this.HomePhoneNo = employee.HomePhoneNo,
    this.WorkPhoneNo = employee.WorkPhoneNo,
    this.MobilePhoneNo = employee.MobilePhoneNo,
    this.IsDeleted = employee.IsDeleted,
    this.IsDisabled = employee.IsDisabled,
    this.CreatedDate = employee.CreatedDate,
    this.CreatedBy = employee.CreatedBy,
    this.UpdatedDate = employee.UpdatedDate,
    this.UpdatedBy = employee.UpdatedBy;
  //this.isadmin = user.isadmin
};

Employee.create = async (newEmployee, result) => {

  var createEmployee = await sql.query("INSERT INTO employee SET UserId = ?, FirstName = ?, MiddleName = ?, LastName = ?, JoiningDate = ?, TerminationDate = ?, DateOfBirth = ?, AnniversaryDate = ?, Address1 = ?, Address2 = ?, CountryId = ?, StateId = ?, CityId = ?, HomePhoneNo = ?, WorkPhoneNo = ?, MobilePhoneNo = ?, IsDeleted = ?, IsDisabled = ?, CreatedDate = ?, CreatedBy = ?, UpdatedDate = ?, UpdatedBy = ?", [newEmployee.UserId, newEmployee.FirstName, newEmployee.MiddleName, newEmployee.LastName, newEmployee.JoiningDate, newEmployee.TerminationDate, newEmployee.DateOfBirth, newEmployee.AnniversaryDate, newEmployee.Address1, newEmployee.Address2, newEmployee.CountryId, newEmployee.StateId, newEmployee.CityId, newEmployee.HomePhoneNo, newEmployee.WorkPhoneNo, newEmployee.MobilePhoneNo, newEmployee.IsDeleted, newEmployee.IsDisabled, newEmployee.CreatedDate, newEmployee.CreatedBy, newEmployee.UpdatedDate, newEmployee.UpdatedBy]);
  if (!createEmployee[0]) {
    console.log("error: ", createEmployee[0]);
    result(createEmployee[0], null);
    return;
  }

  console.log("Created Employee: ", { EmployeeId: createEmployee[0].insertId, ...newEmployee });
  result(null, {
    message: "Employee added successfully",
    code: 0,
    EmployeeId: createEmployee[0].insertId, ...newEmployee
  });

}

Employee.findById = async (EmployeeId, result) => {

  var findByIdEmployee = await sql.query(`SELECT EmployeeId,UserId,FirstName,MiddleName,LastName,JoiningDate,TerminationDate,DateOfBirth,AnniversaryDate,Address1,Address2,CountryId,StateId,CityId,HomePhoneNo,WorkPhoneNo,MobilePhoneNo,IsDeleted,IsDisabled,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM employee WHERE EmployeeId = ${EmployeeId}`);
  if (!findByIdEmployee[0]) {
    console.log("error: ", findByIdEmployee[0]);
    result(findByIdEmployee[0], null);
    return;
  }

  if (findByIdEmployee[0].length) {
    console.log("found Employee: ", findByIdEmployee[0]);
    result(null, findByIdEmployee[0]);
    return;
  }

  // not found Employee with the id
  result({ kind: "not_found" }, null);
};

Employee.getAll = async result => {
  var getAllEmployee = await sql.query("SELECT UUID_TO_BIN(EmployeeId),UUID_TO_BIN(UserId),FirstName,MiddleName,LastName,JoiningDate,TerminationDate,DateOfBirth,AnniversaryDate,Address1,Address2,CountryId,StateId,CityId,HomePhoneNo,WorkPhoneNo,MobilePhoneNo,IsDeleted,IsDisabled,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy FROM employee");
  if (getAllEmployee[0]) {
    console.log("Employee: ", getAllEmployee[0]);
    result(null, getAllEmployee[0]);
    return;
  }

  console.log("Employees: ", getAllEmployee[0]);
  result(null, getAllEmployee[0]);
};

Employee.updateById = async (EmployeeId, employee, result) => {
  const resultOne = await sql.query(
    "UPDATE employee SET FirstName = ?,MiddleName = ?,LastName = ?,JoiningDate = ?,TerminationDate = ?,DateOfBirth = ?,AnniversaryDate = ?,Address1 = ?,Address2 = ?,CountryId = ?, StateId = ?, CityId = ?,HomePhoneNo = ?,WorkPhoneNo = ?,MobilePhoneNo = ?,IsDeleted = ?,IsDisabled = ?,CreatedDate = ?,CreatedBy = ?,UpdatedDate = ?,UpdatedBy = ? WHERE EmployeeId = UUID_TO_BIN(?)",
    [employee.FirstName, employee.MiddleName, employee.LastName, employee.JoiningDate, employee.TerminationDate, employee.DateOfBirth, employee.AnniversaryDate, employee.Address1, employee.Address2, employee.CountryId, employee.StateId, employee.CityId, employee.HomePhoneNo, employee.WorkPhoneNo, employee.MobilePhoneNo, employee.IsDeleted, employee.IsDisabled, employee.CreatedDate, employee.CreatedBy, employee.UpdatedDate, employee.UpdatedBy, EmployeeId]);

  console.log("result ", resultOne[0]);


  if (resultOne[0] == null) {
    console.log("error: ", "err");
    result(null, { "message": "error" });
    return;
  }

  if (resultOne[0].affectedRows == 0) {
    // not found employee with the id
    result({ kind: "not_found" }, null);
    return;
  }

  console.log("updated employee: ", { Employeeid: EmployeeId, ...employee });
  result(null, {
    message: "Employee Upadted successfully",
    code: 0,
    Employeeid: EmployeeId, ...employee
  });
};

Employee.remove = async (EmployeeId, result) => {
  var removeEmployee = await sql.query("DELETE FROM employee WHERE EmployeeId = UUID_TO_BIN(?)", EmployeeId);
  if (!removeEmployee[0]) {
    console.log("error: ", removeEmployee[0]);
    result(null, removeEmployee[0]);
    return;
  }
  // console.log("You are in deleted model");
  // if (removeEmployee[0].affectedRows) {
  //   // not found Employee with the id
  //   result({ kind: "not_found" }, null);
  //   return;
  // }

  console.log("deleted employee with EmployeeId: ", EmployeeId);
  result(null, removeEmployee[0]);

};

Employee.removeAll = async result => {
  removeAllEmployee = await sql.query("DELETE FROM employee");
  if (removeAllEmployee[0]) {
    console.log("error: ", removeAllEmployee[0]);
    result(null, removeAllEmployee[0]);
    return;
  }

  console.log(`deleted ${res.affectedRows} employees`);
  result(null, removeAllEmployee[0]);
};


Employee.getAllDeliveryBoy = async result => {
  var getAllEmployee = await sql.query("SELECT BIN_TO_UUID(EmployeeId) as EmployeeId,BIN_TO_UUID(e.UserId)as UserId, concat(FirstName,' '  ,LastName) As EmployeeName, Address1,Address2,CountryId,StateId,CityId,HomePhoneNo,WorkPhoneNo,MobilePhoneNo,IsDeleted,IsDisabled FROM employee e, users u where  e.UserId = u.UserId and u.UserTypeId = UUID_TO_BIN(?) and IsDeleted = 0 and IsDisabled= 0", constants.DELIVERY_BOY);
  if (!getAllEmployee[0][0]) {
    console.log("Employee: ", getAllEmployee[0]);
    result(null, { code: 2, message: "Failed", deliveryBoys: null })
    return;
  }

  console.log("Employees: ", getAllEmployee[0]);
  result(null, { code: 0, message: "success", deliveryBoys: getAllEmployee[0] });
};

module.exports = Employee;
