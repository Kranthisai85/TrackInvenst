module.exports = app => {
    const supplier = require("../controllers/supplier.controller.js");
  
    // Create a new Users
    app.post("/suppliers", supplier.create);
  
    // Retrieve all Users
    app.get("/suppliers", supplier.findAll);
  
    // Retrieve a single Users with supplierId
    app.get("/suppliers/:supplierId", supplier.findOne);
  
    // Update a Users with supplierId
    app.put("/suppliers/:supplierId", supplier.update);
  
    // Delete a Users with supplierId
    app.delete("/suppliers/:supplierId", supplier.delete);
  
    // Delete all the suppliers
    app.delete("/suppliers", supplier.deleteAll);
  };
  
