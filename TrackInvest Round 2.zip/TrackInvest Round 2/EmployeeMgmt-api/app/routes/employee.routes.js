module.exports = app => {
  const employee = require("../controllers/employee.controller.js");

  // Create a new Users
  app.post("/employees", employee.create);

  // Retrieve all Users
  app.get("/employees", employee.findAll);

  // Retrieve a single Users with EmployeeId
  app.get("/employees/:EmployeeId", employee.findOne);

  // Update a Users with EmployeeId
  app.put("/employees/:EmployeeId", employee.update);

  // Delete a Users with employeeId
  app.delete("/employees/:EmployeeId", employee.delete);

  // Create a new Users
  app.delete("/employees", employee.deleteAll);

  app.get("/employee/getAllDeliveryBoy", employee.getAllDeliveryBoy);
};

