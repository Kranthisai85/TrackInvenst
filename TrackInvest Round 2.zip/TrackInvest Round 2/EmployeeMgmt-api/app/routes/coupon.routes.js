module.exports = app => {
    const coupon = require("../controllers/coupon.controller.js");
  
    // Create a new coupons
    app.post("/coupons", coupon.create);
  
    // Retrieve all coupons
    app.get("/coupons", coupon.findAll);
  
    // Retrieve a single coupons with couponId
    app.get("/coupons/:couponId", coupon.findOne);
  
    // Update a coupons with couponId
    app.put("/coupons/:couponId", coupon.update);
  
    // Delete a coupons with couponId
    app.delete("/coupons/:couponId", coupon.delete);
  
    // Delete all the coupons
    app.delete("/coupons", coupon.deleteAll);
  };
  
