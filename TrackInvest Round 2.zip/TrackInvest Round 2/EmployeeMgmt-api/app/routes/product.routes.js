module.exports = app => {
  const product = require("../controllers/product.controller.js");

  // Create a new product
  app.post("/products", product.create);

  // Retrieve all product
  app.get("/products", product.findAll);

  // Retrieve a single product with productId
  app.get("/products/:productId", product.findOne);

  // Update a product with productId
  app.put("/products/:productId", product.update);

  // Delete a product with productId
  app.delete("/products/:productId", product.delete);

  // Delete all product
  app.delete("/products", product.deleteAll);

  app.get("/products/productsCategories/:customerId", product.getAllCatgories);

  app.get("/productsByType/:typeId", product.findAllByType);

  app.get("/product/categories", product.getProductCategories);

  app.post("/product/notifyMe", product.notifyMe);
  // Search product by productName
  app.get("/productsearch", product.search);

  app.get("/product/unitofmeasurement", product.getUnitOfMeasurement);

  app.get("/product/productStatus", product.getProductStatus);
};
