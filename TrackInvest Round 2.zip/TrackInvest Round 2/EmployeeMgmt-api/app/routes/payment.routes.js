module.exports = app => {
const payment = require("../controllers/payment.controller.js");

// Create a new order
app.post("/payment/makeOutStandingPayment", payment.makeOutStandingPayment);

};