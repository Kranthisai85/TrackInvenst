module.exports = app => {
  const users = require("../controllers/user.controller.js");

  // Create a new Users
  app.post("/users", users.create);

  // Retrieve all Users
  app.get("/users", users.findAll);

  // Retrieve a single Users with userId
  app.get("/users/:userId", users.findOne);

  // Update a Users with userId
  app.put("/users/:userId", users.update);

  // Delete a Users with customerId
  app.delete("/users/:customerId", users.delete);

  // Create a new Users
  app.delete("/users", users.deleteAll);
};
