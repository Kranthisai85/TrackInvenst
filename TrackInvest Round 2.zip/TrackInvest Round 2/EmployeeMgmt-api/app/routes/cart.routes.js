const Cart = require("../models/cart.model.js");

module.exports = app => {
  const cart = require("../controllers/cart.controller.js");

  // Create a new Cart
  app.post("/cart", cart.create);

  app.post("/cartItem", cart.edit);

  // Retrieve all Cart items
  app.get("/cart", cart.findAll);

  // Retrieve a single Cart with customerId
  app.get("/cart/:customerId", cart.findOne);

  // Update a cart with cartId
  app.put("/cart", cart.update);

  // Delete a Cart with cartId
  app.delete("/cart/:cartId", cart.delete);

  // Delete all cart
  app.delete("/cart", cart.deleteAll);

};
