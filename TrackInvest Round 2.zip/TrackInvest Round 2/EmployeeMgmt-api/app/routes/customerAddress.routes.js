module.exports = app => {
  const customerAddress = require("../controllers/customerAddress.controller.js");

  // Create a new CustomerAddress
  app.post("/customerAddress", customerAddress.create);

  // Retrieve all CustomerAddress
  app.get("/customerAddress", customerAddress.findAll);

  // Retrieve a single CustomerAddress with customerAddressId
  app.get("/customerAddress/:customerId", customerAddress.findOne);

  // Update a CustomerAddress with customerAddressId
  app.put("/customerAddress/:customerAddressId", customerAddress.update);

  // Delete a CustomerAddress with customerAddressId
  app.delete("/customerAddress/:customerAddressId", customerAddress.delete);

  // Create a new CustomerAddress
  app.delete("/customerAddress", customerAddress.deleteAll);

  app.post("/customerAddress/registerCustomer", customerAddress.registerCustomer);

  app.get("/address/cities", customerAddress.getAllCities);

  app.get("/address/checkPincode", customerAddress.checkPincode);
};
