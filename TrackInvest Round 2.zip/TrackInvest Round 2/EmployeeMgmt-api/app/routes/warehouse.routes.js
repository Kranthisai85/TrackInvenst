module.exports = app => {
    const warehouse = require("../controllers/warehouse.controllers.js");

//Create a new Warehouse
app.post("/warehouse", warehouse.create);

//Retrive all users
app.get("/warehouse", warehouse.findAll);

//Retrive a single warehouse with warehouseId
app.get("/warehouse/:warehouseId", warehouse.findOne);

//Update a warehouse with warehouseId
app.put("/warehouse/:warehouseId", warehouse.update);

//Delete a warehouse with warehouseId
app.delete("/warehouse/:warehouseId", warehouse.delete);

//Delete all the warehouses
app.delete("/warehouse", warehouse.deleteAll);

}