module.exports = app => {
    const order = require("../controllers/order.controller.js");

    // Create a new order
    app.post("/order/placeOrder", order.create);

    // Retrieve all product
    app.get("/order/getAllOrder", order.getOrdersByCustomer);

    app.get("/order/getOrderItems/:orderId", order.getOrderItems);

    app.post("/order/cancelOrder", order.cancelOrder);
};
