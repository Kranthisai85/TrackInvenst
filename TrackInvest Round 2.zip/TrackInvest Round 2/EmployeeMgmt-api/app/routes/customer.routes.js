module.exports = app => {
  const customers = require("../controllers/customer.controller.js");

  // Create a new Users
  app.post("/customers", customers.create);

  app.get("/customers/sendOtp", customers.checkMobileNumber);

  app.get("/customers/verifyOtp", customers.verifyOtp);
  // Retrieve all Users
  app.get("/customers", customers.findAll);

  // Retrieve a single Users with userId
  app.get("/customers/:userId", customers.findOne);

  // Update a Users with userId
  app.put("/customers/:userId", customers.update);

  // Delete a Users with customerId
  app.delete("/customers/:userId", customers.delete);

  // Create a new Users
  app.delete("/customers", customers.deleteAll);

  app.put("/customer/updateCustomer", customers.updateCustomer);

};
