module.exports = app => {
    const wallet = require("../controllers/wallet.controller.js");

    //Create a new Warehouse
    app.get("/wallet/getAllDetails", wallet.getAllDetails);


}