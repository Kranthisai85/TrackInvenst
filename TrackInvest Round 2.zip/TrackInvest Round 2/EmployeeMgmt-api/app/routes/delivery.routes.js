module.exports = app => {
    const delivery = require("../controllers/delivery.controller.js");
    app.get("/delivery/orderListForDeliveryPerson", delivery.orderListForDeliveryPerson);

    app.get("/delivery/getOrderItemByOrderId", delivery.getOrderItemByOrderId);

    app.get("/delivery/getCancelationReason", delivery.getCancelationReason);

    app.post("/delivery/onOrderDelivered", delivery.onOrderDelivered);



};
