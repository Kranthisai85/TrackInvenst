module.exports = app => {
    const admin = require("../controllers/admin.controller.js");

    app.get("/admin/getAllPendingOrders", admin.getAllPendingOrders);

    app.get("/admin/getAllDelieveryFilter", admin.getAllDelieveryFilter);

    app.post("/admin/getOrdersByFilter", admin.getOrdersByFilter);

    app.post("/admin/assignDeliveryPerson", admin.assignDeliveryPerson);

    app.post("/admin/adminEditOrder", admin.adminEditOrder);

};
