const Subscription = require("../models/subscription.model.js");

module.exports = app => {
  const subscription = require("../controllers/subscription.controller.js");

  // Create a new subscription
  app.post("/subscription", subscription.create);

  // Retrieve all subscriptions
  app.get("/subscription", subscription.findAll);

  // Retrieve a single subscription with subscriptionId
  app.get("/subscription/find/:customerId/:addressId/:subscriptionTypeId", subscription.findOne);

  // Update a subscription with subscriptionId
  app.put("/subscription/:subscriptionId", subscription.update);

  // Delete a subscription with subscriptionId
  app.delete("/subscription/:subscriptionId", subscription.delete);

  // Delete all subscription
  app.delete("/subscription", subscription.deleteAll);

  app.get("/subscription/getSubscriptionDetails/:subscriptionId", subscription.getSubscritionDetails);

  app.post("/subscription/cancelSubscription", subscription.cancelSubscription);

  app.post("/subscription/renewSubscription", subscription.renewSubscription);

  app.post("/subscription/editSubscription", subscription.editSubscription);

  app.get("/subscription/getSubscriptionBasket", subscription.getSubscriptionBasket);
};
