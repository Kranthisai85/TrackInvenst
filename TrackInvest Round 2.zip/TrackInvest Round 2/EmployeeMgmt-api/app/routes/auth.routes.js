module.exports = app => {
    const auth = require("../controllers/auth.controller.js");

    // User sign in and return user +  roles user is member of
    app.post("/signin", auth.signIn);
}