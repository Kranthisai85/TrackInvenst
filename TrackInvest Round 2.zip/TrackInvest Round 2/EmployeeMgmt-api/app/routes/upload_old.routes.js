module.exports = app => {
    const upload = require("../controllers/upload.controller.js");

    // Create a new product
    app.post("/upload/single", upload.single);

    // Retrieve all product
    app.post("/upload/multiple", upload.multiple);

};
