import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';

interface country {
  value: string;
  viewValue: string;
}
interface state {
  value: string;
  viewValue: string;
}
interface city {
  value: string;
  viewValue: string;
}

@Component({
  selector: "[app-file-upload],[app-wizard]",
  templateUrl: './employee.component.html'
//   styleUrls: ['./productMaster.component.css']
})

export class employeeComponent implements OnInit {
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
//   fourFormGroup: FormGroup;
  
  public uploader: FileUploader = new FileUploader({ url: 'https://evening-anchorage-315.herokuapp.com/api/',allowedFileType: ['.jpg','.png']});
  public hasBaseDropZoneOver: boolean = false;
  console = console;

  countries: country[] = [
    {value: 'india', viewValue: 'INDIA'},
    {value: 'nepal', viewValue: 'NEPAL'},
    {value: 'china', viewValue: 'CHINA'},
    {value: 'usa', viewValue: 'USA'},
  ];

  states: state[] = [
    {value: 'telangana', viewValue: 'Telangana'},
    {value: 'maharastra', viewValue: 'Maharastra'},
    {value: 'tamilnadu', viewValue: 'Tamil Nadu'},
    {value: 'kerala', viewValue: 'Kerala'},
  ];

  cities: city[] = [
    {value: 'mumbai', viewValue: 'Mumbai'},
    {value: 'pune', viewValue: 'Pune'},
    {value: 'hyderabad', viewValue: 'Hyderabad'},
    {value: 'delhi', viewValue: 'Delhi'},
  ];

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.firstFormGroup = this.fb.group({
      firstName: ['', Validators.required],
      middleName: ['', Validators.required],
      lastName: ['', Validators.required],
      dob: ['', Validators.required],
      mobile: ['', Validators.required],
      home: ['', Validators.required],
      work: ['', Validators.required],
      adate: ['', Validators.required]
      });
    this.secondFormGroup = this.fb.group({
      address1: ['', Validators.required],
      address2: ['', Validators.required],
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      // minSubcriptionQty: ['', Validators.required]
    });
    this.thirdFormGroup = this.fb.group({
      // maxWeight: ['', Validators.required],
      joindate: ['', Validators.required]
    });
    // this.fourFormGroup = this.fb.group({
    //   HRimage: ['', Validators.required]
    // });
     }
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }
  submit() {
    console.log(this.firstFormGroup.value);
    console.log(this.secondFormGroup.value);
    console.log(this.thirdFormGroup.value);
    // console.log(this.fourFormGroup.value);
   

  }
  
}

