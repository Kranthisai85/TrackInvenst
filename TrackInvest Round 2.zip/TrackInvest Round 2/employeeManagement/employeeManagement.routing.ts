import { Routes } from '@angular/router';

 import { employeeComponent } from './employee/employee.component';
 //import { ProductTypesComponent } from './productTypes/productTypes.component';
 //import { ProductCategoriesComponent } from './productCategories/productCategories.component';
// import { AppBlankComponent } from './app-blank/app-blank.component';

export const employeeRoutes: Routes = [
  {
    path: '',
    children: [{
      path: 'employee',
      component: employeeComponent,
      data: { title: 'employee', breadcrumb: 'EMPLOYEE' },
    //  },
    //  {
    //   path: 'productTypes',
    //   component: ProductTypesComponent,
    //   data: { title: 'productTypes', breadcrumb: 'PRODUCT TYPES' }
    // },
    // {
    //   path: 'productCategories',
    //   component: ProductCategoriesComponent,
    //   data: { title: 'productCategories', breadcrumb: 'PRODUCT CATEGORIES' }
    }]
     //{
    //   path: 'blank',
    //   component: AppBlankComponent,
    //   data: { title: 'Blank', breadcrumb: 'BLANK' }
    // 
  }
];
