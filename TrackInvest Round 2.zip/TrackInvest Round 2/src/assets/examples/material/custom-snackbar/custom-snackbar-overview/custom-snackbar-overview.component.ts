import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-snackbar-overview',
  templateUrl: './custom-snackbar-overview.component.html',
  styleUrls: ['./custom-snackbar-overview.component.scss']
})
export class CustomSnackbarOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
