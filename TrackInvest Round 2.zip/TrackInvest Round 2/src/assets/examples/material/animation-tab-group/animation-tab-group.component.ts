import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animation-tab-group',
  templateUrl: './animation-tab-group.component.html',
  styleUrls: ['./animation-tab-group.component.scss']
})
export class AnimationTabGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
