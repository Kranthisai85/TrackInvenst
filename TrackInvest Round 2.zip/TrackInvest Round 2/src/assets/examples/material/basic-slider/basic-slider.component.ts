import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-slider',
  templateUrl: './basic-slider.component.html',
  styleUrls: ['./basic-slider.component.scss']
})
export class BasicSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
