import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-paginator',
  templateUrl: './basic-paginator.component.html',
  styleUrls: ['./basic-paginator.component.scss']
})
export class BasicPaginatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
