import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-autoresize-sidenav',
  templateUrl: './autoresize-sidenav.component.html',
  styleUrls: ['./autoresize-sidenav.component.scss']
})
export class AutoresizeSidenavComponent implements OnInit {

  showFiller = false;
  
  constructor() { }

  ngOnInit() {
  }

}
