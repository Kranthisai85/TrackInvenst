import { Routes } from '@angular/router';
import { AdminLayoutComponent } from './shared/components/layouts/admin-layout/admin-layout.component';
import { AuthLayoutComponent } from './shared/components/layouts/auth-layout/auth-layout.component';
import { AuthGuard } from './shared/guards/auth.guard';

export const rootRouterConfig: Routes = [
  { 
    path: '', 
    redirectTo: 'others', 
    pathMatch: 'full' 
  },
  {
    path: '', 
    component: AuthLayoutComponent,
    children: [
      { 
        path: 'sessions', 
        loadChildren: () => import('./views/sessions/sessions.module').then(m => m.SessionsModule),
        data: { title: 'Session'} 
      }
    ]
  },
  {
    path: '', 
    component: AdminLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'others', 
        loadChildren: () => import('./views/others/others.module').then(m => m.OthersModule), 
        data: { title: 'Others', breadcrumb: 'OTHERS'}
      },
      {
        path: 'productManagement', 
        loadChildren: () => import('./views/productManagement/productManagement.module').then(m => m.productManagementModule), 
        data: { title: 'ProductManagement', breadcrumb: 'PRODUCTMANAGEMENT'}
      },
      // {
      //   path: 'forms', 
      //   loadChildren: () => import('./views/forms/forms.module').then(m => m.AppFormsModule), 
      //   data: { title: 'Forms', breadcrumb: 'FORMS'}
      // },
      {
        path: 'employeeManagement', 
        loadChildren: () => import('./views/employeeManagement/employeeManagement.module').then(m => m.employeeManagementModule),
        data: { title: 'employeeManagement', breadcrumb: 'EMPLOYEEMANAGEMENT'}

      },
      {
        path: 'reports', 
        loadChildren: () => import('./views/reports/reports.module').then(m => m.reportsModule),
        data: { title: 'reports', breadcrumb: 'REPORTS'}

      },
      {
        path: 'customerManagement', 
        loadChildren: () => import('./views/customerManagement/customerManagement.module').then(m => m.customerManagementModule), 
        data: { title: 'customerManagement', breadcrumb: 'CUSTOMERMANAGEMENT'}
      }
    ]
  },
  { 
    path: '**', 
    redirectTo: 'sessions/404'
  }
];

