import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { QuillModule } from 'ngx-quill';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatStepperModule } from '@angular/material/stepper';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule } from 'ng2-charts';
import { FileUploadModule } from 'ng2-file-upload';
 import { NgMatSearchBarModule } from 'ng-mat-search-bar';
 import { HttpClientModule } from '@angular/common/http';
 import {MatAutocompleteModule} from '@angular/material/autocomplete';
 import {MatPaginatorModule } from '@angular/material/paginator';

import { SharedModule } from '../../shared/shared.module';
import { MatTableModule } from '@angular/material/table';
import {customerComponent} from './customer/customer.component';
//  import { ProductCategoriesComponent } from './productCategories/productCategories.component';
//  import { ProductTypesComponent } from './productTypes/productTypes.component';
// import { AppUsersComponent } from './app-users/app-users.component';
// import { AppBlankComponent } from './app-blank/app-blank.component';
 import { customerRoutes } from './customerManagement.routing';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MatListModule,
    ReactiveFormsModule,
    MatIconModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatPaginatorModule,
    MatAutocompleteModule,
    MatMenuModule,
    MatSlideToggleModule,
    MatGridListModule,
    MatChipsModule,
    MatCheckboxModule,
    NgMatSearchBarModule,
    MatRadioModule,
    MatTabsModule,
    MatInputModule,
    MatProgressBarModule,
    MatStepperModule,
    HttpClientModule,
    FlexLayoutModule,
    NgxDatatableModule,
    ChartsModule,
    FileUploadModule,
    MatDatepickerModule, 
    MatNativeDateModule,
    QuillModule,
    SharedModule,
    MatTableModule,
    RouterModule.forChild(customerRoutes),
    
    

  ],
  declarations: [
    customerComponent
    // ProductCategoriesComponent,
    // ProductTypesComponent
    // AppUsersComponent,
    // AppBlankComponent
  ]
})
export class customerManagementModule { }
