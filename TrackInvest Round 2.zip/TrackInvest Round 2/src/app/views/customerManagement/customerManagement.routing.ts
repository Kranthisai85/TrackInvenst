import { Routes } from '@angular/router';

 import { customerComponent } from './customer/customer.component';
 //import { ProductTypesComponent } from './productTypes/productTypes.component';
 //import { ProductCategoriesComponent } from './productCategories/productCategories.component';
// import { AppBlankComponent } from './app-blank/app-blank.component';

export const customerRoutes: Routes = [
  {
    path: '',
    children: [{
      path: 'customer',
      component: customerComponent,
      data: { title: 'customer', breadcrumb: 'CUSTOMER' },
    }]

    //  },
    //  {
    //   path: 'productTypes',
    //   component: ProductTypesComponent,
    //   data: { title: 'productTypes', breadcrumb: 'PRODUCT TYPES' }
    // },
    // {
    //   path: 'productCategories',
    //   component: ProductCategoriesComponent,
    //   data: { title: 'productCategories', breadcrumb: 'PRODUCT CATEGORIES' }
     //{
    //   path: 'blank',
    //   component: AppBlankComponent,
    //   data: { title: 'Blank', breadcrumb: 'BLANK' }
    // 
  }
];
