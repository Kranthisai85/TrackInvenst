export interface address{
    CustomerAddressId: string;
    CotactName: string;
    ContactPhone: string;
    Address: string;
    Postcode: string;
    Action: symbol;
}

export interface customers{
    CustomerId: string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    ContactMobile: string;
    ContactEmail: string;
    Action: symbol;
}
// CustomerId, FirstName, MiddleName, LastName, ContactMobile, ContactEmail