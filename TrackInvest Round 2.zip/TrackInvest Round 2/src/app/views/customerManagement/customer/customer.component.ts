import { Component, OnInit, ViewChild } from '@angular/core';
import { environment } from "../../../../environments/environment";
import { HttpClient } from "@angular/common/http";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomvalidationService } from './customvalidation.service';
import { address } from './customer.model';
import { customers } from './customer.model';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';

interface addressType {
  value: string;
  viewValue: string;
}
interface country {
  value: string;
  viewValue: string;
}
interface state {
  value: string;
  viewValue: string;
}
interface city {
  value: string;
  viewValue: string;
}
 
@Component({
  selector: "[app-file-upload],[app-wizard]",
  templateUrl: './customer.component.html',
    styleUrls: ['./customer.component.css']
})


export class customerComponent implements OnInit {

 @ViewChild(MatPaginator) paginator: MatPaginator;

  submitted = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;

  private apiUrl = environment.apiURL;

  public Addresstype: any;


  addressTypes: addressType[] = [
    {value: 'billing address', viewValue: 'BILLING ADDRESS'},
    {value: 'shipping address', viewValue: 'SHIPPING ADDRESS'},
    {value: 'warehouse address', viewValue: 'WAREHOUSE ADDRESS'}
    ];
  countries: country[] = [
  {value: 'india', viewValue: 'INDIA'},
    {value: 'nepal', viewValue: 'NEPAL'},
    {value: 'china', viewValue: 'CHINA'},
    {value: 'usa', viewValue: 'USA'},
  ];

  states: state[] = [
    {value: 'telangana', viewValue: 'Telangana'},
    {value: 'maharastra', viewValue: 'Maharastra'},
    {value: 'tamilnadu', viewValue: 'Tamil Nadu'},
    {value: 'kerala', viewValue: 'Kerala'},
  ];

  cities: city[] = [
    {value: 'mumbai', viewValue: 'Mumbai'},
    {value: 'pune', viewValue: 'Pune'},
    {value: 'hyderabad', viewValue: 'Hyderabad'},
    {value: 'delhi', viewValue: 'Delhi'},
  ]  

  public displayedColumns = ['CustomerAddressId', 'CotactName', 'ContactPhone','Address', 'Postcode','Action'];

  public displayedColumns1 = ['CustomerId', 'FirstName', 'MiddleName','LastName', 'ContactMobile','ContactEmail','Action'];

  public dataSource = new MatTableDataSource<address>();
  public dataSource1 = new MatTableDataSource<customers>();
  sort: any;
  obj: any;

  constructor(private fb: FormBuilder, private http: HttpClient, private customValidator: CustomvalidationService) { }

  ngOnInit() {

    this.http.get(this.apiUrl + '/customer/addresses')
    .subscribe(res => {
      console.log(res);
      this.dataSource.data = res as address[];
    })

    this.http.get(this.apiUrl + '/customer')
    .subscribe(res => {
      console.log(res);
      this.dataSource1.data = res as customers[];
    })

    this.http.get(this.apiUrl + "/customer/addresstype").subscribe(
      (addresstype) => {
        this.Addresstype = addresstype;
        //this.unitOfMeasurement.push(units);
        console.log(this.Addresstype);
      },
      (error) => console.error(error)
    );


    this.firstFormGroup = this.fb.group({
      firstName: ['', Validators.required],
      middleName: [''],
      lastName: [''],
      phone: [''],
      mobile: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      userName: ['',Validators.required, this.customValidator.userNameValidator.bind(this.customValidator)],
      password: ['',Validators.compose([Validators.required, this.customValidator.patternValidator()])],
      confirmPassword: ['',Validators.required],
      UserType: ['11eb2992-5482-6bf3-bd6b-c49deda8deaf',{disabled:true}],
      },
      {
        validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
      });
    this.secondFormGroup = this.fb.group({
      address1: ['', Validators.required],
      address2: [''],
      landmark: [''],
      postcode: ['', Validators.required],
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      addressType: ['', Validators.required],
      CustomerId: ['']
     
    });
    this.thirdFormGroup = this.fb.group({
      joindate: ['', Validators.required]
    });
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  get registerFormControl() {
    return this.firstFormGroup.controls;
  }

  // removeAddress(i: number) {
  //   this.addresses.splice(i, 1);
  // }

  // logValue() {
  //   console.log(this.addresses);
  // }

  Save() {
    this.submitted = true;
    var body = {
      firstName: this.firstFormGroup.value.firstName,
      middleName: this.firstFormGroup.value.middleName,
      lastName: this.firstFormGroup.value.lastName,
      phone: this.firstFormGroup.value.phone,
      mobile: this.firstFormGroup.value.mobile,
      email:  this.firstFormGroup.value.email,
      userName: this.firstFormGroup.value.userName,
      password: this.firstFormGroup.value.password,
      UserType: this.firstFormGroup.value.UserType
    };
    console.log(this.firstFormGroup.value);

      this.http
        .post(this.apiUrl + "/customer", body)
        .toPromise()
        .then((data: any) => {
          console.log(data);
          this.secondFormGroup.patchValue({
            CustomerId: data.CustomerId
          });
        });
  }

  submit() {
    console.log(this.firstFormGroup.value);
    console.log(this.secondFormGroup.value);
    console.log(this.thirdFormGroup.value);   
    var body1 = {
      CustomerId: this.secondFormGroup.value.CustomerId,
      address1: this.secondFormGroup.value.address1,
      address2: this.secondFormGroup.value.address2,
      landmark: this.secondFormGroup.value.landmark,
      postcode: this.secondFormGroup.value.postcode,
      country: this.secondFormGroup.value.country,
      state:  this.secondFormGroup.value.state,
      city: this.secondFormGroup.value.city,
      addressType: this.secondFormGroup.value.addressType,
      // UserType: this.secondFormGroup.value.UserType
    };
    console.log(this.secondFormGroup.value);

      this.http
        .post(this.apiUrl + "/customerAddress", body1)
        .toPromise()
        .then((data: any) => {
          console.log(data);
        });
  }

openDialog(action, obj) {
  obj.action = action;
  console.log(action);
  console.log(obj);
  if (action == "Update") {
    this.firstFormGroup.get('firstName').setValue(obj.FirstName);
    this.firstFormGroup.get('middleName').setValue(obj.MiddleName);
    this.firstFormGroup.get('lastName').setValue(obj.LastName);
    this.firstFormGroup.get('phone').setValue(obj.ContactPhone);
    this.firstFormGroup.get('mobile').setValue(obj.ContactMobile);
    this.firstFormGroup.get('email').setValue(obj.ContactEmail);
    this.firstFormGroup.get('userName').setValue(obj.UserName);
    this.firstFormGroup.get('password').setValue(obj.UserPassword);
  }
  else if (action == "UpdateAddress") {
    
    // this.secondFormGroup.get('CustomerId').setValue(obj.CustomerId);
    this.secondFormGroup.get('address1').setValue(obj.Address);
    this.secondFormGroup.get('address2').setValue(obj.Address2);
    this.secondFormGroup.get('landmark').setValue(obj.Landmark);
    this.secondFormGroup.get('postcode').setValue(obj.Postcode);
    // this.secondFormGroup.get('country').setValue(obj.ContactEmail);
    this.secondFormGroup.get('addressType').setValue(obj.AddressType);
    this.secondFormGroup.get('city').setValue(obj.City);
    // this.secondFormGroup.get('addressType').setValue(obj.UserPassword);
  }
}

}


//Extra Code

//interface addressType {
  //   value: string;
  //   viewValue: string;
  // }
  // interface country {
  //   value: string;
  //   viewValue: string;
  // }
  // interface state {
  //   value: string;
  //   viewValue: string;
  // }
  // interface city {
  //   value: string;
  //   viewValue: string;
  // }
  // addressTypes: addressType[] = [
  //   {value: 'billing address', viewValue: 'BILLING ADDRESS'},
  //   {value: 'shipping address', viewValue: 'SHIPPING ADDRESS'},
  //   {value: 'warehouse address', viewValue: 'WAREHOUSE ADDRESS'}
  //   ];

  // countries: country[] = [
  //   {value: 'india', viewValue: 'INDIA'},
  //   {value: 'nepal', viewValue: 'NEPAL'},
  //   {value: 'china', viewValue: 'CHINA'},
  //   {value: 'usa', viewValue: 'USA'},
  // ];

  // states: state[] = [
  //   {value: 'telangana', viewValue: 'Telangana'},
  //   {value: 'maharastra', viewValue: 'Maharastra'},
  //   {value: 'tamilnadu', viewValue: 'Tamil Nadu'},
  //   {value: 'kerala', viewValue: 'Kerala'},
  // ];

  // cities: city[] = [
  //   {value: 'mumbai', viewValue: 'Mumbai'},
  //   {value: 'pune', viewValue: 'Pune'},
  //   {value: 'hyderabad', viewValue: 'Hyderabad'},
  //   {value: 'delhi', viewValue: 'Delhi'},
  // ]
  // if (!!this.editData) {
    //   this.http
    //     .put(this.apiUrl + "/products/" + this.editData.ProductId, body)
    //     .toPromise()
    //     .then((data: any) => {
    //       console.log(data);
    //     });
    // } else {
    //   console.log(this.firstFormGroup.value);
    //   console.log(this.secondFormGroup.value);

