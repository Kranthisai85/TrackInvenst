export interface productItemWiseProcurement {
  ProductId: string;
  ProductName: string;
  ProductNameHindi: string;
  StocKeepUnit: string;
  UnitOfMeasurementCode: string;
  UOMQty: string;
  }
  