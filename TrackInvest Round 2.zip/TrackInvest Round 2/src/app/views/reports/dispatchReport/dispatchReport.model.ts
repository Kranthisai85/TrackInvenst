export interface dispatchReport {
  ProductUnit: string;
  ProductName: string;
  ProductNameHindi: string;
  CustomerName: string;
  StocKeepUnit: string;
  DeliveryQtyw: string;
}
//ProductName, ProductNameHindi, CustomerName, ProductUnit, StocKeepUnit, DeliveryQtyw