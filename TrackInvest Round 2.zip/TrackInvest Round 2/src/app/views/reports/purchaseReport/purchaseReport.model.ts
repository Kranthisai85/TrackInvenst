export interface purchaseReport {
  ProductId: string;
  ProductName: string;
  ProductNameHindi: string;
  StocKeepUnit: string;
  UnitOfMeasurementCode: string;
  ProductType: string;
  UOMQty: string;
  }
//ProductId, ProductName, ProductNameHindi, ProductType, UnitOfMeasurementCode, StocKeepUnit, UOMQty