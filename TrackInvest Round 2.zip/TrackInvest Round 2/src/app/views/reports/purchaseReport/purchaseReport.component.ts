import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { purchaseReport } from "./purchaseReport.model";
import * as XLSX from 'xlsx';
import { Router, ActivatedRoute } from "@angular/router";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { environment } from "../../../../environments/environment";
import { HttpParams } from "@angular/common/http";

interface Dates {
    value: string;
    viewValue: string;
}

@Component({
selector: "app-root",
templateUrl: "./purchaseReport.component.html",
// styleUrls: ["./purchaseReport.component.css"],
// providers: [Product]
})

export class purchaseReportComponent implements OnInit {
@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
@ViewChild(MatSort, { static: false }) sort: MatSort;
@ViewChild("table", { static: false }) table: any;

public displayedColumns = [
    "ProductId",
    "ProductName",
    "ProductNameHindi",
    "StocKeepUnit",
    "UnitOfMeasurementCode",
    "ProductType",
    "UOMQty",
];

data = [];
value: string;
filterData = [];
public dataSource = new MatTableDataSource<purchaseReport>();
private apiUrl = environment.apiURL;
fileName= 'purchaseReport.xlsx';
constructor(private http: HttpClient, private router: Router) {
    console.log("this.data");
}

selectedValue: string;

dates: Dates[] = [
    {value: '-5', viewValue: '-5'},
    {value: '-4', viewValue: '-4'},
    {value: '-3', viewValue: '-3'},
    {value: '-2', viewValue: '-2'},
    {value: '-1', viewValue: '-1'},
    {value: '0', viewValue: '0'},
    {value: '1', viewValue: '1'},
    {value: '2', viewValue: '2'},
    {value: '3', viewValue: '3'},
    {value: '4', viewValue: '4'},
    {value: '5', viewValue: '5'},
    {value: '6', viewValue: '6'},
    {value: '7', viewValue: '7'}
];

exportexcel(): void 
    {
       /* table id is passed over here */   
       let element = document.getElementById('excel-table'); 
       const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);

       /* generate workbook and add the worksheet */
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

       /* save to file */
       XLSX.writeFile(wb, this.fileName);
			
    }

ngOnInit() {
    this.selectedValue = "Select Day";
    // this.http.get(this.apiUrl + "/products").subscribe(
    //     (data) => {
    //     this.data.push(data);
    //     this.onChangeDataSource(data);
    //     console.log(this.data);
    //     // const productID = productId[0][0].productId;
    //     },
    //     (error) => console.error(error)
    // );
    }

    doFilter = (day: string) => {
        let params = new HttpParams();
        params = params.append("day", day);
        console.log(day);
        this.http.get(this.apiUrl + "/reports/purchaseReport", { params: params }).subscribe(
        (data) => {
        this.data.push(data);
        this.onChangeDataSource(data);
        console.log(this.data);
        // const productID = productId[0][0].productId;
        },
        (error) => console.error(error)
        );
    };

    onChangeDataSource(value) {
    this.dataSource = new MatTableDataSource(value);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    }
}