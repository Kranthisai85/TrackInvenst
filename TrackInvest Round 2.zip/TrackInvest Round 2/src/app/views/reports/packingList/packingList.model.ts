export interface packingList {
  ProductUnit: string;
  ProductName: string;
  ProductNameHindi: string;
  QtyBySKUGroup: string;
  UnitOfMeasurementCode: string;
  StocKeepUnit: string;
}
//ProductName, ProductNameHindi, ProductUnit, UnitOfMeasurementCode, QtyBySKUGroup, StocKeepUnit