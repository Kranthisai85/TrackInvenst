import { Routes } from '@angular/router';

import {packingListComponent} from './packingList/packingList.component';
import { customerWiseProductComponent } from './customerWiseProduct/customerWiseProduct.component';
import { productItemWiseProcurementComponent } from './productItemWiseProcurement/productItemWiseProcurement.component';
import { purchaseReportComponent } from './purchaseReport/purchaseReport.component';
import { dispatchReportComponent } from './dispatchReport/dispatchReport.component';

export const reportsRoutes: Routes = 
[
  {
    path: '',
    children: 
    [
        {
            path: 'packingList',
            component: packingListComponent,
            data: { title: 'packingList', breadcrumb: 'PACKING LIST' },
        }, 
        {
            path: 'customerWiseProduct',
            component: customerWiseProductComponent,
            data: { title: 'customerWiseProduct', breadcrumb: 'CUSTOMER WISE PRODUCT' },
        },
        {
            path: 'productItemWiseProcurement',
            component: productItemWiseProcurementComponent,
            data: { title: 'productItemWiseProcurement', breadcrumb: 'PRODUCT ITEM WISE PROCUREMENT' },
        }, 
        {
            path: 'purchaseReport',
            component: purchaseReportComponent,
            data: { title: 'purchaseReport', breadcrumb: 'PURCHASE REPORT' },
        },
        {
            path: 'dispatchReport',
            component: dispatchReportComponent,
            data: { title: 'dispatchReport', breadcrumb: 'DISPATCH REPORT' },
        }
    ]
  }
]
     
// {
//   path: 'productCategories',
//   component: ProductCategoriesComponent,
//   data: { title: 'productCategories', breadcrumb: 'PRODUCT CATEGORIES' }
    //{
//   path: 'blank',
//   component: AppBlankComponent,
//   data: { title: 'Blank', breadcrumb: 'BLANK' }
// 

