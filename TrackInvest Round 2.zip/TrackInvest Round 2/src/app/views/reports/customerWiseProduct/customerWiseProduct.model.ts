export interface customerWiseProduct {
  CustomerName: string;
  ProductName: string;
  ProductNameHindi: string;
  OrderNumber: string;
  UnitOfMeasurement: string;
  TotalProcurement: string;
  }
  
//CustomerName, OrderNumber, ProductName, ProductNameHindi, sum(TotalProcurement), UnitOfMeasurement