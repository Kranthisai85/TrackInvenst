import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { QuillModule } from 'ngx-quill';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatChipsModule } from '@angular/material/chips';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatRadioModule } from '@angular/material/radio';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatStepperModule } from '@angular/material/stepper';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule } from 'ng2-charts';
import { FileUploadModule } from 'ng2-file-upload';
import { SharedModule } from '../../shared/shared.module';
import { MatTableModule } from '@angular/material/table';
import { NgMatSearchBarModule } from 'ng-mat-search-bar';
import { HttpClientModule } from '@angular/common/http';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatPaginatorModule } from '@angular/material/paginator';

import {packingListComponent} from './packingList/packingList.component';
import { customerWiseProductComponent } from './customerWiseProduct/customerWiseProduct.component';
import { productItemWiseProcurementComponent } from './productItemWiseProcurement/productItemWiseProcurement.component';
import { purchaseReportComponent } from './purchaseReport/purchaseReport.component';
import { dispatchReportComponent } from './dispatchReport/dispatchReport.component';

import { reportsRoutes } from './reports.routing';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MatListModule,
    ReactiveFormsModule,
    MatIconModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatSlideToggleModule,
    MatGridListModule,
    MatChipsModule,
    MatCheckboxModule,
    MatRadioModule,
    MatTabsModule,
    MatAutocompleteModule,
    MatInputModule,
    MatProgressBarModule,
    MatStepperModule,
    FlexLayoutModule,
    NgxDatatableModule,
    ChartsModule,
    FileUploadModule,
    MatDatepickerModule, 
    MatNativeDateModule,
    QuillModule,
    SharedModule,
    RouterModule.forChild(reportsRoutes),
    MatTableModule,
    NgMatSearchBarModule,
    MatPaginatorModule,
    HttpClientModule
    ],
  declarations: [
    packingListComponent,
    customerWiseProductComponent,
    productItemWiseProcurementComponent,
    purchaseReportComponent,
    dispatchReportComponent
  ]
})
export class reportsModule { }


 