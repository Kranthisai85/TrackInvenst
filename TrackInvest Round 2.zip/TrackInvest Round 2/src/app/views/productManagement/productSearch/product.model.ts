export interface Product {
  ProductId: string;
  ProductName: string;
  ProductNameHindi: string;
  Description: string;
  IsOrganic: Boolean;
  SeasonStartDate: Date;
  SeasonEndDate: Date;
  UnitOfMeasurementCode: string;
  ProductType: string;
  ProductCategory: string;
}
