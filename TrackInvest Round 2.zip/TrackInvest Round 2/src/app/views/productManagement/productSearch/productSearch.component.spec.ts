import { TestBed, waitForAsync } from '@angular/core/testing';
import { ProductSearchComponent } from './productSearch.component';

describe('ProductSearchComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        ProductSearchComponent
      ],
    });
    TestBed.compileComponents();
  });

  it('should create the ProductSearch', waitForAsync(() => {
    const fixture = TestBed.createComponent(ProductSearchComponent);
    const ProductSearch = fixture.debugElement.componentInstance;
    expect(ProductSearch).toBeTruthy();
  }));

  it(`should have as title 'ProductSearch works!'`, waitForAsync(() => {
    const fixture = TestBed.createComponent(ProductSearchComponent);
    const ProductSearch = fixture.debugElement.componentInstance;
    expect(ProductSearch.title).toEqual('ProductSearch works!');
  }));

  it('should render title in a h1 tag', waitForAsync(() => {
    const fixture = TestBed.createComponent(ProductSearchComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('ProductSearch works!');
  }));
});
