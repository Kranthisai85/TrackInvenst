import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Product } from "./product.model";
import { MatPaginator } from "@angular/material/paginator";

import { Router, ActivatedRoute } from "@angular/router";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { environment } from "../../../../environments/environment";
import { HttpParams } from "@angular/common/http";

@Component({
  selector: "app-root",
  templateUrl: "./productSearch.component.html",
  styleUrls: ["./productSearch.component.css"],
  // providers: [Product]
})
export class ProductSearchComponent implements OnInit {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild("table", { static: false }) table: any;

  public displayedColumns = [
    "ProductId",
    "ProductName",
    "ProductNameHindi",
    "Description",
    "IsOrganic",
    "SeasonStartDate",
    "SeasonEndDate",
    "UnitOfMeasurementCode",
    "ProductType",
    "ProductCategory",
    "Action",
  ];

  data = [];
  value: string;
  filterData = [];
  public dataSource = new MatTableDataSource<Product>();
  private apiUrl = environment.apiURL;

  constructor(private http: HttpClient, private router: Router) {
    console.log("this.data");
  }

  refreshPage() {
    window.location.reload();
  }

  ngOnInit() {
    this.http.get(this.apiUrl + "/products").subscribe(
      (data) => {
        this.data.push(data);
        this.onChangeDataSource(data);
        console.log(this.data);
        // const productID = productId[0][0].productId;
      },
      (error) => console.error(error)
    );
  }

  onChangeDataSource(value) {
    this.dataSource = new MatTableDataSource(value);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  doFilter = (productName: string) => {
    let params = new HttpParams();
    params = params.append("productName", productName);

    this.http.get(this.apiUrl + "/productsearch", { params: params }).subscribe(
      (data) => {
        this.data.push(data);
        this.onChangeDataSource(data);
        console.log(this.data);
        // const productID = productId[0][0].productId;
      },
      (error) => console.error(error)
    );
  };


  edit(mydata: any) {
    console.log(mydata);

    this.router.navigate(["/productManagement/productMaster"], {
      state: mydata,
    });
  }

  openDialog(action, obj) {
    obj.action = action;
    console.log(action);
    console.log(obj);
    if (action == "Update") {
      this.router.navigate(["/productManagement/productMaster"], {
        state: obj,
      });
    }
    else if (action == "Inventory")
    {
      this.router.navigate(["/productManagement/productInventory"], {
        state: obj,
      });
    }
    else (action == "Delete")
    {

    }

    
  }
}



//Extra Code
// const dialogRef = this.dialog.open(DialogBoxComponent, {
    //   width: '250px',
    //   data:obj
    // });

    // dialogRef.afterClosed().subscribe(result => {
    //   if(result.event == 'Add'){
    //     this.addRowData(result.data);
    //   }else if(result.event == 'Update'){
    //     this.updateRowData(result.data);
    //   }else if(result.event == 'Delete'){
    //     this.deleteRowData(result.data);
    //   }
    // });
    // this.router.navigate(['/productSearch']);
    // document.write("Product deleted with Name "+mydata.ProductName+" ID "+mydata.ProductId)

     //  debugger;
    //this.dataSource.filter = value.trim().toLocaleLowerCase();

    // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // }
