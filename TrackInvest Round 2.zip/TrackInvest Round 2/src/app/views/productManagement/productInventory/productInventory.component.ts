import {Component, OnInit, ViewChild} from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from "../../../../environments/environment";
import { MatTableDataSource } from '@angular/material/table';
import { inventory } from './_interface/inventoryTable.model';
import { MatPaginator } from '@angular/material/paginator';


@Component({
  selector: '[app-file-upload],[app-wizard]',
  templateUrl: 'productInventory.component.html',
})

export class ProductInventoryComponent implements OnInit 
{
 
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public firstFormGroup: FormGroup;

  public secondFormGroup: FormGroup;
  
  private apiUrl = environment.apiURL;

  public editData: any;

  public Inventory: any;

  public WarehouseId: any;

  public unitOfMeasurement: any;

  public InventoryId: any;

  public displayedColumns = ['ProductName', 'ProductNameHindi', 'ProductType','InventoryReceived', 'InventoryShipped', 'InventoryOnHand', 'InventoryRestockQty', 'ProductUnit', 'UnitOfMeasurementCode', 'ProductUnitPrice', 'Action'];

  public dataSource = new MatTableDataSource<inventory>();
  sort: any;
  obj: any;

  public GetProductById(productId: string) {
    return this.http.get(this.apiUrl + "/products/" + productId).toPromise();
  }

  constructor(private fb: FormBuilder,private http: HttpClient, private router: Router) 
  
  { 
  this.editData = this.router.getCurrentNavigation().extras.state;
  console.log("Editdata", this.editData);
  }



  ngOnInit() 

  {
    this.getAllinventory();

    this.http.get(this.apiUrl + "/product/warehouseId").subscribe(
      (warehouseId) => {
        this.WarehouseId = warehouseId;
        //this.unitOfMeasurement.push(units);
        console.log(this.WarehouseId);
      },
      (error) => console.error(error)
    );

    this.http.get(this.apiUrl + "/product/unitofmeasurement").subscribe(
      (units) => {
        this.unitOfMeasurement = units;
        //this.unitOfMeasurement.push(units);
        console.log(this.unitOfMeasurement);
      },
      (error) => console.error(error)
    );

    this.firstFormGroup = this.fb.group({
      ProductId: ['', Validators.required],
      PurchaseId: [{value: null, disabled:true}],
      WarehouseId: ['', Validators.required],
      OrderId: [{value: null, disabled:true}],
      InventoryReceived: ['', Validators.required],
      InventoryShipped: ['', Validators.required],
      InventoryOnHand: ['', Validators.required],
      InventoryRestockQty: ['', Validators.required],
      CustomerMaxOrder: ['', Validators.required],
      ProductPrice: ['', Validators.required],
    });
    this.secondFormGroup = this.fb.group({
      ProductInventoryId: [''],
      ProductId: [''],
      WarehouseId: [''],
      UnitOfMeasurement: [''],
      ProductUnit: [''],
      ProductUnitPrice: [''],
      StocKeepUnit: [''],
      MinPriceRange: [''],
      MaxPriceRange: [''],
      WeightRangeUpper: [''],
      WeightRangeLower: [''],
      MinSubscriptionQty: [''],
      MinOrderQty: [''],

    })
    
    if (!!this.editData) {
      //this.GetProductById(this.editData.ProductId);

      this.GetProductById(this.editData.ProductId)
        .then((data) => {
          this.Inventory = data;

          this.firstFormGroup.patchValue({
            ProductId: this.Inventory.ProductId
          });

          this.secondFormGroup.patchValue({
            ProductId: this.Inventory.ProductId
          });
          //console.log(JSON.stringify(data));
        })
        .catch((error) => {
          console.log("Promise rejected with " + JSON.stringify(error));
        });

      // console.log(this.Inventory);

      // console.log(this.InventoryId);
      
    }

  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  public getAllinventory = () => {
    this.http.get(this.apiUrl + '/product/inventoryTable/'+this.editData.ProductId)
    .subscribe(res => {
      this.dataSource.data = res as inventory[];
    })
  }

  public doFilter = (value: string) => {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }
  // value.trim().toLocaleLowerCase()
  Save(){
    var body = {
      ProductId: this.firstFormGroup.value.ProductId,
      PurchaseId: this.firstFormGroup.value.PurchaseId,
      WarehouseId: this.firstFormGroup.value.WarehouseId,
      OrderId: this.firstFormGroup.value.OrderId,
      InventoryReceived: this.firstFormGroup.value.InventoryReceived,
      InventoryShipped: this.firstFormGroup.value.InventoryShipped,
      InventoryRestockQty: this.firstFormGroup.value.InventoryRestockQty,
      CustomerMaxOrder: this.firstFormGroup.value.CustomerMaxOrder,
      ProductPrice: this.firstFormGroup.value.ProductPrice,
      
    };
    this.http
    .post(this.apiUrl + "/product/productInventory", body)
    .toPromise()
    .then((data: any) => {
      console.log(data);
      this.secondFormGroup.patchValue({
        ProductInventoryId: data.ProductInventoryId
      });
      // console.log(data.ProductInventoryId);
      
    });
  }

  submit(){

    var body1 = {
      ProductInventoryId: this.secondFormGroup.value.ProductInventoryId,
      UnitOfMeasurementId: this.secondFormGroup.value.UnitOfMeasurement,
      WarehouseId: this.secondFormGroup.value.WarehouseId,
      ProductId: this.secondFormGroup.value.ProductId,
      ProductUnit: this.secondFormGroup.value.ProductUnit,
      ProductUnitPrice: this.secondFormGroup.value.ProductUnitPrice,
      StocKeepUnit: this.secondFormGroup.value.StocKeepUnit,
      MinPriceRange: this.secondFormGroup.value.MinPriceRange,
      MaxPriceRange: this.secondFormGroup.value.MaxPriceRange,
      WeightRangeUpper: this.secondFormGroup.value.WeightRangeUpper,
      WeightRangeLower: this.secondFormGroup.value.WeightRangeLower,
      MinSubscriptionQty: this.secondFormGroup.value.MinSubscriptionQty,
      MinOrderQty: this.secondFormGroup.value.MinOrderQty,

    };
    this.http
    .post(this.apiUrl + "/product/warehousePricing", body1)
    .toPromise()
    .then((data: any) => {
      console.log(data);
      

    });
  }

  openDialog(action, obj) {
    obj.action = action;
    console.log(action);
    console.log(obj);
    this.firstFormGroup.get('InventoryReceived').setValue(obj.InventoryReceived);
    this.firstFormGroup.get('InventoryShipped').setValue(obj.InventoryShipped);
    this.firstFormGroup.get('InventoryOnHand').setValue(obj.InventoryOnHand);
    this.firstFormGroup.get('InventoryRestockQty').setValue(obj.InventoryRestockQty);
    this.firstFormGroup.get('CustomerMaxOrder').setValue(obj.CustomerMaxOrder);
    this.firstFormGroup.get('ProductPrice').setValue(obj.ProductPrice);
    this.firstFormGroup.get('WarehouseId').setValue(obj.WarehouseId);

    this.secondFormGroup.get('ProductUnit').setValue(obj.ProductUnit);
    this.secondFormGroup.get('ProductUnitPrice').setValue(obj.ProductUnitPrice);
    this.secondFormGroup.get('ProductInventoryId').setValue(obj.ProductInventoryId);
    this.secondFormGroup.get('WarehouseId').setValue(obj.WarehouseId);
    this.secondFormGroup.get('UnitOfMeasurement').setValue(obj.UnitOfMeasurementId);
    this.secondFormGroup.get('StocKeepUnit').setValue(obj.StocKeepUnit);
    

    
    // if (action == "Update") {
    //   this.router.navigate(["/productManagement/productInventory"], {
    //       state: obj,
    //     });
    //     if(!!this.obj){
    //     this.firstFormGroup.setValue({
    //       ProductUnit: obj.ProductUnit,
    //     });
    //   }
    // }

    
  }

}

// InventoryReceived: number;
// InventoryShipped: number;
// InventoryOnHand: number;
// InventoryRestockQty: number;
// ProductUnit: number;
// UnitOfMeasurementCode: string;
// ProductUnitPrice: number;
// this.router.navigate(["/productManagement/productInventory"], {
//   state: obj,
// });
// { 
//   this.editData = this.router.getCurrentNavigation().extras.state;
//   console.log("Editdata", this.editData);
//   }
// public GetInventoryId() {
//   return this.http.get(this.apiUrl + "/product/productInventory").toPromise();
// }
// this.GetInventoryId()
// .then((data1) => {
//   this.InventoryId = data1;
//   this.secondFormGroup.patchValue({
//     ProductInventoryId: this.InventoryId.ProductInventoryId
//   });
//   console.log(JSON.stringify(data1));
// })
// .catch((error) => {
//   console.log("Promise rejected with " + JSON.stringify(error));
// });
// ProductWarehousePricingId, ProductInventoryId, ProductId, WarehouseId, UnitOfMeasurementId, ProductUnit, ProductUnitPrice, StocKeepUnit, MinPriceRange, MaxPriceRange, WeightRangeUpper, WeightRangeLower, Length, Width, Height, CouponId, MinSubscriptionQty, MinOrderQty, IsLotItem, IsTaxable, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy

// <!-- ProductWarehousePricingId, ProductInventoryId, ProductId, WarehouseId, UnitOfMeasurementId, ProductUnit, ProductUnitPrice, StocKeepUnit, MinPriceRange, MaxPriceRange, WeightRangeUpper, WeightRangeLower, Length, Width, Height, CouponId, MinSubscriptionQty, MinOrderQty, IsLotItem, IsTaxable, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy -->
// <!-- ProductInventoryId, ProductId, PurchaseId, WarehouseId, OrderId, InventoryReceived, InventoryShipped, InventoryOnHand, InventoryRestockQty, CustomerMaxOrder, ProductOptionId, ProductPrice, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy -->
    // this.firstFormGroup = this.fb.group({
    //     myControl: ['', Validators.required]
    // });
     
    //   this.filteredProducts = this.myControl.valueChanges.pipe(
    //     startWith(''),
    //     map(value => this._filter(value))
    //   );
    // }

    // private _filter(value: string): string[] {
    //   const filterValue = value.toLowerCase();

    //   return this.options.filter((p: string) => p.toLowerCase().indexOf(filterValue) === 0);
    //}

//this.http.get(this.apiUrl + "/products").
  // options: string[] = ['One', 'Two', 'Three'];
  // filteredOptions: Observable<string[]>;
// .subscribe(
//   (data) => {
//     this.data.push(data);
//     console.log(this.data);
//   },
//   (error) => console.error(error)
// );