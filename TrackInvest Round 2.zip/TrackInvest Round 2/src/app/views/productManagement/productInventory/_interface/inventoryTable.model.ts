export interface inventory{
    ProductName: string;
    ProductNameHindi: string;
    ProductType: Date;
    InventoryReceived: number;
    InventoryShipped: number;
    InventoryOnHand: number;
    InventoryRestockQty: number;
    ProductUnit: number;
    UnitOfMeasurementCode: string;
    ProductUnitPrice: number;
    Action: symbol;
}

// ProductName, ProductNameHindi, ProductType, InventoryOnHand, ProductUnit, UnitOfMeasurementCode, ProductUnitPrice
// ProductInventoryId, ProductId, PurchaseId, WarehouseId, OrderId, InventoryReceived, InventoryShipped, InventoryOnHand, InventoryRestockQty, CustomerMaxOrder, ProductOptionId, ProductPrice, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy