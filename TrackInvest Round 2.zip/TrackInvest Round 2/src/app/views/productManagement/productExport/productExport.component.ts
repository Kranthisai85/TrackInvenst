import { Component, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ProductExport } from "./productExport.model";
import * as XLSX from 'xlsx';
import { Router, ActivatedRoute } from "@angular/router";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { MatPaginator } from "@angular/material/paginator";
import { environment } from "../../../../environments/environment";
import { HttpParams } from "@angular/common/http";

@Component({
selector: "app-root",
templateUrl: "./productExport.component.html",
styleUrls: ["./productExport.component.css"],
// providers: [Product]
})

export class ProductExportComponent implements OnInit {
@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
@ViewChild(MatSort, { static: false }) sort: MatSort;
@ViewChild("table", { static: false }) table: any;

public displayedColumns = [
    "ProductId",
    "ProductName",
    "ProductNameHindi",
    "Description",
    "IsOrganic",
    "SeasonStartDate",
    "SeasonEndDate",
    "UnitOfMeasurementCode",
    "ProductType",
    "ProductCategory",
];

data = [];
value: string;
filterData = [];
public dataSource = new MatTableDataSource<ProductExport>();
private apiUrl = environment.apiURL;
fileName= 'productExport.xlsx';
constructor(private http: HttpClient, private router: Router) {
    console.log("this.data");
}

exportexcel(): void 
    {
       /* table id is passed over here */   
       let element = document.getElementById('excel-table'); 
       const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);

       /* generate workbook and add the worksheet */
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

       /* save to file */
       XLSX.writeFile(wb, this.fileName);
			
    }

ngOnInit() {
    this.http.get(this.apiUrl + "/products").subscribe(
        (data) => {
        this.data.push(data);
        this.onChangeDataSource(data);
        console.log(this.data);
        // const productID = productId[0][0].productId;
        },
        (error) => console.error(error)
    );
    }

    onChangeDataSource(value) {
    this.dataSource = new MatTableDataSource(value);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    }
}