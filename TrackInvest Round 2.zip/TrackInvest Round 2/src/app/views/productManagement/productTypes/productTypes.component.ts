import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';


@Component({
  selector: "[app-file-upload],[app-wizard]",
  templateUrl: './productTypes.component.html'
//   styleUrls: ['./productTypes.component.css']
})

export class ProductTypesComponent implements OnInit {
  firstFormGroup: FormGroup;
 
  
  
  public uploader: FileUploader = new FileUploader({ url: 'https://evening-anchorage-315.herokuapp.com/api/',allowedFileType: ['.jpg','.png']});
  public hasBaseDropZoneOver: boolean = false;
  console = console;


  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.firstFormGroup = this.fb.group({
      productType: ['', Validators.required],
      productTypeImage: ['', Validators.required]

      });
     }
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }
  submit() {
    console.log(this.firstFormGroup.value);   
  }
  
}

