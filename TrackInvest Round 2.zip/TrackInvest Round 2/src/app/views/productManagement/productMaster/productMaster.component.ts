import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { FileUploader } from "ng2-file-upload";
import { HttpClient } from "@angular/common/http";
import { Router, ActivatedRoute } from "@angular/router";
import { Binary } from "@angular/compiler";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
import { DateAdapter, MAT_DATE_FORMATS } from "@angular/material/core";
import {
  AppDateAdapter,
  APP_DATE_FORMATS,
} from "../../../../../src/app/shared/helpers/format-datepicker";
import * as moment from "moment";

@Component({
  selector: "[app-file-upload],[app-wizard]",
  templateUrl: "./productMaster.component.html",
  styleUrls: ["./productMaster.component.css"],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
  ],
})
export class ProductMasterComponent implements OnInit {
  public firstFormGroup: FormGroup;
  public secondFormGroup: FormGroup;
  // public thirdFormGroup: FormGroup;
  // public fourthFormGroup: FormGroup;

  imageHRURL: string;
  imageLRURL: string;
  imageThumbNailURL: string;
  imageToShow: any;

  //"https://evening-anchorage-315.herokuapp.com/api/"
  public uploader: FileUploader = new FileUploader({
    url: environment.apiURL + "",
    allowedFileType: [".jpg", ".png"],
  });
  public hasBaseDropZoneOver: boolean = false;
  console = console;
  private apiUrl = environment.apiURL;

  productCategories: any;
  unitOfMeasurement: any;
  productStatus: any;
  productTypes: any;

  public editData: any;
  public Product: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {
    //history.state.data
    this.editData = this.router.getCurrentNavigation().extras.state;
    console.log(this.editData);
    if (!!this.editData) {
    }
  }

  ngOnInit() {
    this.http.get(this.apiUrl + "/product/categories").subscribe(
      (categories) => {
        this.productCategories = categories;
        //this.productCategories.push(categories);
        console.log(this.productCategories);
      },
      (error) => console.error(error)
    );

    this.http.get(this.apiUrl + "/product/unitofmeasurement").subscribe(
      (units) => {
        this.unitOfMeasurement = units;
        //this.unitOfMeasurement.push(units);
        console.log(this.unitOfMeasurement);
      },
      (error) => console.error(error)
    );

    this.http.get(this.apiUrl + "/product/productStatus").subscribe(
      (status) => {
        this.productStatus = status;
        //this.productStatus.push(status);
        console.log(this.productStatus);
      },
      (error) => console.error(error)
    );

    this.http.get(this.apiUrl + "/product/productTypes").subscribe(
      (types) => {
        this.productTypes = types;
        //this.unitOfMeasurement.push(units);
        console.log(this.productTypes);
      },
      (error) => console.error(error)
    );

    this.firstFormGroup = this.fb.group({
      productName: ["", Validators.required],
      productNameHindi: [""],
      productDescription: ["", Validators.required],
      productCategory: ["", Validators.required],
      productType: ["",Validators.required],
      productStatusId: ["",Validators.required],
      IsOrganic: [0],
      seasonStartDate: [""],
      seasonEndDate: [""],
      // productType: ['', Validators.required],
      // skuNumber: ['', Validators.required],
    });
    this.secondFormGroup = this.fb.group({
      imageHRPath: ["", Validators.required],
      imageLRPath: [""],
      imageThumbNailPath: [""],
      IsDeleted: [0],

    });
    

    if (!!this.editData) {
      console.log("Editdata", this.editData);
      //this.GetProductById(this.editData.ProductId);

      this.GetProductById(this.editData.ProductId)
        .then((data) => {
          this.Product = data;

          this.firstFormGroup.patchValue({
            productName: this.Product.ProductName,
            productNameHindi: this.Product.ProductNameHindi,
            productDescription: this.Product.Description,
            productCategory: this.Product.ProductCategoryId,
            productStatusId:  this.Product.productStatusId,
            productType: this.Product.productTypeId,
            IsOrganic: this.Product.IsOrganic,
            seasonStartDate: this.Product.SeasonStartDate,
            seasonEndDate: this.Product.SeasonEndDate,
          });

          this.secondFormGroup.patchValue({
            imageHRPath: this.apiUrl + "/" + this.Product.ImageHRPath,
            imageLRPath: this.apiUrl + "/" + this.Product.ImageLRPath,
            imageThumbNailPath: this.apiUrl + "/" + this.Product.ImageThumbNailPath,
            IsDeleted: this.Product.IsDeleted,
          });

         
          this.imageHRURL = this.apiUrl + "/" + this.Product.ImageHRPath;
          this.getImageFromService(this.imageHRURL);
          //console.log(JSON.stringify(data));
        })
        .catch((error) => {
          console.log("Promise rejected with " + JSON.stringify(error));
        });

      console.log(this.Product);

      
    }
  }

  getImage(imageUrl: string): Observable<Blob> {
    return this.http.get(imageUrl, { responseType: "blob" });
  }

  getImageFromService(imageURL: string) {
    //this.isImageLoading = true;
    this.getImage(imageURL).subscribe(
      (data) => {
        this.createImageFromBlob(data);
        //this.isImageLoading = false;
      },
      (error) => {
        //this.isImageLoading = false;
        console.log(error);
      }
    );
  }

  createImageFromBlob(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener(
      "load",
      () => {
        this.imageToShow = reader.result;
      },
      false
    );

    if (image) {
      reader.readAsDataURL(image);
    }
  }

  public GetProductById(productId: string) {
    return this.http.get(this.apiUrl + "/products/" + productId).toPromise();

   
  }

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }
  submit() {
   
    var body = {
      productName: this.firstFormGroup.value.productName,
      productNameHindi: this.firstFormGroup.value.productNameHindi,
      IsOrganic: this.firstFormGroup.value.IsOrganic,
      description: this.firstFormGroup.value.productDescription,
      productCategoryId: this.firstFormGroup.value.productCategory,
      productStatusId:  this.firstFormGroup.value.productStatusId,
      productTypeId: this.firstFormGroup.value.productType,
      seasonStartDate:
        this.firstFormGroup.value.seasonStartDate === null
          ? null
          : moment(this.firstFormGroup.value.seasonStartDate).format(
              "YYYY-MM-DD"
            ), // "2020-08-10",
      seasonEndDate:
        this.firstFormGroup.value.seasonEndDate === null
          ? null
          : moment(this.firstFormGroup.value.seasonEndDate).format(
              "YYYY-MM-DD"
            ), //"2020-10-10",
      IsDeleted: this.secondFormGroup.value.IsDeleted,
      
      imageHRPath: this.secondFormGroup.value.HRimage,

    };

    if (!!this.editData) {
      this.http
        .put(this.apiUrl + "/products/" + this.editData.ProductId, body)
        .toPromise()
        .then((data: any) => {
          console.log(data);
        });
    } else {
      console.log(this.firstFormGroup.value);
      console.log(this.secondFormGroup.value);


      //"http://localhost:8080/
      this.http
        .post(this.apiUrl + "/products", body)
        .toPromise()
        .then((data: any) => {
          console.log(data);
        });
      // this.router.navigate(['./productSearch']);
    }
  }
}












//Extra Code
 // productPrice: ["", Validators.required],
      // minOrderQty: ["", Validators.required],
      // minSubcriptionQty: ["", Validators.required],
      // minPrice: ["", Validators.required],
      // maxPrice: ["", Validators.required],
      // couponId: [""],
      // productStatusId: ["", Validators.required],
      // this.thirdFormGroup = this.fb.group({
    //   maxWeight: [""],
    //   minWeight: [""],
    //   length: [""],
    //   width: [""],
    //   height: [""],
    //   UnitOfMeasurement: ["", Validators.required],
    // });
    // this.fourthFormGroup = this.fb.group({
    //   imageHRPath: ["", Validators.required],
    //   imageLRPath: [""],
    //   imageThumbNailPath: [""]
    // });
      // productPrice: this.Product.ProductPrice,
            // minOrderQty: this.Product.MinOrderQty,
            // minSubcriptionQty: this.Product.MinSubscriptionQty,
            // minPrice: this.Product.MinPriceRange,
            // maxPrice: this.Product.MaxPriceRange,
            // couponId: this.Product.CouponId,
            // productStatusId: this.Product.ProductStatusId,
             // this.thirdFormGroup = this.fb.group({
          //   maxWeight: this.Product.WeightRangeUpper,
          //   minWeight: this.Product.WeightRangeLower,
          //   length: this.Product.Length,
          //   width: this.Product.Width,
          //   height: this.Product.Height,
          //   UnitOfMeasurement: this.Product.UnitOfMeasurementId,
          // });

          // this.fourthFormGroup = this.fb.group({
          //   imageHRPath: this.apiUrl + "/" + this.Product.ImageHRPath,
          //   imageLRPath: this.apiUrl + "/" + this.Product.ImageLRPath,
          //   imageThumbNailPath:
          //     this.apiUrl + "/" + this.Product.ImageThumbNailPath,
          // });
          //this.fourthFormGroup.value.imageHRPath.setValidator(null);
          // this.fourFormGroup.get("HRimage").setValue(this.editData.ImageHRPath);

           // return this.http.get(this.apiUrl + "/products/" + productId).subscribe(
    //   (product) => {
    //     this.Product = product;
    //   },
    //   (error) => console.error(error)
    // );

    // productPrice: this.secondFormGroup.value.productPrice,
      // minPriceRange: this.secondFormGroup.value.minPrice,
      // maxPriceRange: this.secondFormGroup.value.maxPrice,
      // couponId: this.secondFormGroup.value.couponId,
      // minSubscriptionQty: this.secondFormGroup.value.minSubcriptionQty,
      // minOrderQty: this.secondFormGroup.value.minOrderQty,
      // productStatusId: this.secondFormGroup.value.productStatusId,
      // isTaxable: 1,

      // weightRangeUpper: this.thirdFormGroup.value.maxWeight,
      // weightRangeLower: this.thirdFormGroup.value.minWeight,
      // length: this.thirdFormGroup.value.length,
      // width: this.thirdFormGroup.value.width,
      // height: this.thirdFormGroup.value.height,
      // unitOfMeasurementId: this.thirdFormGroup.value.UnitOfMeasurement,


      // ProductTypeId:this.firstFormGroup.value.productType,
      // taxIncludedAmount:this.secondFormGroup.value.taxIncludedAmount,