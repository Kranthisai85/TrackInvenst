import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';


@Component({
  selector: "[app-file-upload],[app-wizard]",
  templateUrl: './productCategories.component.html'
//   styleUrls: ['./productTypes.component.css']
})

export class ProductCategoriesComponent implements OnInit {
  firstFormGroup: FormGroup;  
  
  public uploader: FileUploader = new FileUploader({ url: 'https://evening-anchorage-315.herokuapp.com/api/',allowedFileType: ['.jpg','.png']});
  public hasBaseDropZoneOver: boolean = false;
  console = console;


  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.firstFormGroup = this.fb.group({
        productCategory: ['', Validators.required],
       productCategoryImage: ['', Validators.required]

      });
     }
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }
  submit() {
    console.log(this.firstFormGroup.value);   
  }
  
}

