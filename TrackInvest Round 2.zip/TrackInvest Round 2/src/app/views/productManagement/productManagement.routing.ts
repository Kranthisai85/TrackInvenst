import { Routes } from '@angular/router';

 import { ProductMasterComponent } from './productMaster/productMaster.component';
 import { ProductInventoryComponent } from './productInventory/productInventory.component';
 import { ProductCategoriesComponent } from './productCategories/productCategories.component';
 import { ProductSearchComponent } from './productSearch/productSearch.component';
 import { ProductExportComponent } from './productExport/productExport.component';

export const productRoutes: Routes = [
  {
    path: '',
    children: [{
      path: 'productMaster',
      component: ProductMasterComponent,
      data: { title: 'productMaster', breadcrumb: 'PRODUCTMASTER' },
     },
     {
      path: 'productInventory',
      component: ProductInventoryComponent,
      data: { title: 'productInventory', breadcrumb: 'PRODUCT INVENTORY' }
    },
    {
      path: 'productCategories',
      component: ProductCategoriesComponent,
      data: { title: 'productCategories', breadcrumb: 'PRODUCT CATEGORIES' }
    },
     {
      path: 'productSearch',
      component: ProductSearchComponent,
      data: { title: 'productSearch', breadcrumb: 'PRODUCT SEARCH' }
    },
    {
      path: 'productExport',
      component: ProductExportComponent,
      data: { title: 'productExport', breadcrumb: 'PRODUCT EXPORT' }
    },
  ]
}];
